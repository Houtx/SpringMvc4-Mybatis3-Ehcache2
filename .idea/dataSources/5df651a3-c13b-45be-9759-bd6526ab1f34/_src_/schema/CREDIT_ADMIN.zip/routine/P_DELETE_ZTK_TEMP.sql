CREATE procedure P_DELETE_ZTK_TEMP  Authid current_user is
begin
  
delete from T_ZTK_TYPE  t where t.domainid='017';
delete  from t_Ztk_Meta_Table t where t.domainid='017';
delete  from t_Ztk_Meta_Column t where t.domainid='017';
delete  from t_Ztk_Mapping t where t.domainid='017';
delete  from t_Ztk_File t where t.domainid='017';
update T_ZTK_DATABASEUSER t set t.isattached='N' where t.dbuserid='1c20b39dfb184102b7c4e38e21ca9152';
commit;
EXECUTE immediate 'drop table ldcj.t_ldjg_qsqj purge';
end P_DELETE_ZTK_TEMP;
/
