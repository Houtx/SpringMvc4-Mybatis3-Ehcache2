CREATE procedure              prc_serv_ylh_dishui_end_qyid is
       v_sql_ylh_dishui_history        varchar2(5000) := '';
begin
    dbms_output.put_line('Schema: credit_product,  信用信息应用——遗漏户提示——地税（最终）');

    execute immediate 'truncate table SERV_YLH_DISHUI_HISTORY';

    v_sql_ylh_dishui_history := '
          INSERT INTO SERV_YLH_DISHUI_HISTORY
                select *
                      from SERV_YLH_DISHUI_CURRENT
                where qyid in (
                     (select qyid
                              from SERV_YLH_DISHUI_CURRENT
                     )
                     MINUS
                     (select qyid
                             from credit_product.t_dishui_djxx
                             where ( substr(qylxdm, 1, 3) != ' || '''' || '600' || '''' ||
                                    'or qylxdm is null )
                     )
                )
                and qylxmc not like' || '''' || '%个体工商户%' || '''';

    --dbms_output.put_line(v_sql_ylh_dishui_history);
    execute immediate v_sql_ylh_dishui_history;
    dbms_output.put_line('*****************');


      commit;
      exception
    when others then
      rollback;
      raise;

end prc_serv_ylh_dishui_end_qyid;
/
