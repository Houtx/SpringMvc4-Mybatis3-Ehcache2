CREATE PROCEDURE P_ZTK_QYSXJLTJ(CMDID IN INTEGER) AUTHID CURRENT_USER AS
  V_DATASETID  VARCHAR2(50);
  V_INSALLSQL  VARCHAR2(500);
  V_INSFILESQL VARCHAR2(500);
  V_STARTTIME  DATE;
  V_MESSAGEID  VARCHAR2(50) := '22B7D315F96A4B788DA639DF537FDA1B';
  V_MAPPINGID  VARCHAR2(50) := 'QYSXTJ_abf8c0c475794d4d8240378a1c18e514';
  CURSOR C_ALLZTKTAB IS
    select messageid,messagename,'credit_hecha.'||tablename tablename
    from t_ztk_meta_table t where t.domainid='010' and t.infotypecode like '4%' and t.isuse='Y'
    order by t.orderid;
  V_COUNT INTEGER;
  V_UPDATERESULT BOOLEAN;
BEGIN
  --判断是否存在这个CMDID
  DECLARE
    V_TMP VARCHAR2(1);
  BEGIN
    SELECT '1'
      INTO V_TMP
      FROM T_SYS_PROCESSCOMMAND2 T
     WHERE T.CMDID = CMDID
       AND DOMAINID = '022'
       and rownum = 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('命令无效');
      V_UPDATERESULT := F_UPDATECMDSTATE(CMDID, '2','N');
      IF NOT V_UPDATERESULT THEN
        --更新状态失败，对后台有影响
        P_WRITELOG(CMDID, '命令执行状态更新失败。');
      END IF;
      RETURN;
    WHEN OTHERS THEN
      V_UPDATERESULT := F_UPDATECMDSTATE(CMDID, '2','N');
      IF NOT V_UPDATERESULT THEN
        --更新状态失败，对后台有影响
        P_WRITELOG(CMDID, '命令执行状态更新失败。');
      END IF;
      P_WRITELOG(CMDID, '查询命令发生错误：' || SQLERRM);
      RETURN;
  END;
  
  V_STARTTIME := SYSDATE;
  P_WRITELOG(CMDID, '开始企业失信记录统计数据生成');
  P_WRITELOG(CMDID, '清空无效数据');
  EXECUTE IMMEDIATE 'truncate table credit_qysxtj.t_qysxtj_qysxjlhztj';
  EXECUTE IMMEDIATE 'truncate table credit_qysxtj.t_qysxtj_qysxjltj';
  COMMIT;
  P_WRITELOG(CMDID, '清空无效数据完成');
  
  --更新T_ZTK_FILE中数据已删除部分标识
  UPDATE T_ZTK_FILE T
     SET T.ISDELETED = 'Y', T.DELTIME = SYSDATE
   WHERE T.DOMAINID = '022'
     AND T.ISDELETED IS NULL;
  P_WRITELOG(CMDID, '插入新数据');
  SELECT SYS_GUID() INTO V_DATASETID FROM DUAL;
  FOR R_TAB IN C_ALLZTKTAB LOOP
    --插入记录
    V_INSALLSQL := 'insert into credit_qysxtj.t_qysxtj_qysxjlhztj(qyid,messageid,sxjls) select qyid,'''||R_TAB.MESSAGEID||''',count(*) from ' || R_TAB.Tablename || ' group by qyid';
    EXECUTE IMMEDIATE V_INSALLSQL;
    COMMIT;
    --插入进度日志
    P_WRITELOG(CMDID, '已生成' || R_TAB.MESSAGENAME || '的失信记录信息');
  END LOOP;
  
  V_INSALLSQL := 'insert into credit_qysxtj.t_qysxtj_qysxjltj(datasetid,qyid,irecid,createtime,' ||
                 'isincreased,verified,qymc,qyzch,zzjgdm,tyshxydm,isvalid,sxjls) ' ||
                 'select ''' || V_DATASETID ||
                 ''' datasetid,t1.qyid,sys_guid(),sysdate,''Y'',''Y'',t1.qymc,' ||
                 't1.qyzch,t1.zzjgdm,t1.tyshxydm,''Y'' isvalid,sum(t2.sxjls) sxjls from credit_qyjbxx.t_qyjbxx t1,credit_qysxtj.t_qysxtj_qysxjlhztj t2' ||
                 ' where t1.qyid = t2.qyid group by t1.qyid,t1.qymc,t1.qyzch,t1.zzjgdm,t1.tyshxydm';
  EXECUTE IMMEDIATE V_INSALLSQL;
  COMMIT; 
  
  V_INSALLSQL := 'update credit_qysxtj.t_qysxtj_qysxjltj t set t.ishmd=''Y'' where exists(select 1 from credit_hecha.t_xxhc_frhmd b where t.qyid=b.qyid)';
  EXECUTE IMMEDIATE V_INSALLSQL;
  commit;                             
  P_WRITELOG(CMDID, '插入新数据完成');
  
  SELECT count(*)
      INTO V_COUNT
      FROM credit_qysxtj.t_qysxtj_qysxjltj ;
  P_WRITELOG(CMDID, '数据生成完毕，共生成' || V_COUNT || '条记录。');
  
  BEGIN
    SELECT MESSAGEID,MAPPINGID
      INTO V_MESSAGEID,V_MAPPINGID
      FROM T_ZTK_MAPPING
     WHERE DOMAINID = '022'
       AND ROWNUM = 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_WRITELOG(CMDID, '警告：没有找到信息类ID');
  END;
  V_INSFILESQL := 'INSERT INTO T_ZTK_FILE(CMDID,DATASETID,MAPPINGID,DOMAINID,MESSAGEID,STARTTIME,ENDTIME,RECCOUNT,ISQUANJI,CORPCOUNT,RECCOUNT_QYID) VALUES(' ||
                  ':1,:2,:3,''022'',:4,:5,SYSDATE,:6,''Y'',:7,:8)';
  BEGIN
    EXECUTE IMMEDIATE V_INSFILESQL
      USING CMDID, V_DATASETID,V_MAPPINGID,V_MESSAGEID, V_STARTTIME, V_COUNT,V_COUNT,V_COUNT;
  EXCEPTION
    WHEN OTHERS THEN
      P_WRITELOG(CMDID, '插入数据生成表记录时发生错误。' || SQLERRM);
  END;
  P_WRITELOG(CMDID, '更新完毕。存储过程执行完毕。');
  V_UPDATERESULT := F_UPDATECMDSTATE(CMDID, '2','Y');
  IF NOT V_UPDATERESULT THEN
    --更新状态失败，对后台有影响
    P_WRITELOG(CMDID, '命令执行状态更新失败。');
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    IF C_ALLZTKTAB%ISOPEN THEN
      CLOSE C_ALLZTKTAB;
    END IF;
    V_UPDATERESULT := F_UPDATECMDSTATE(CMDID, '2','N');
    IF NOT V_UPDATERESULT THEN
      --更新状态失败，对后台有影响
      P_WRITELOG(CMDID, '命令执行状态更新失败。');
    END IF;
    P_WRITELOG(CMDID, '数据生成失败，发生错误：' || SQLERRM);
END;
/
