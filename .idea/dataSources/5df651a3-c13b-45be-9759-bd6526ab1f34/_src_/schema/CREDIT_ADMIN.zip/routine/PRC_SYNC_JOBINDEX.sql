CREATE procedure              PRC_SYNC_JOBINDEX is
begin
  ctx_ddl.sync_index('JOBINDEX');
  ctx_ddl.sync_index('JOBINDEX_QY');
  ctx_ddl.sync_index('JOBINDEX_GT');

  ctx_ddl.optimize_index('JOBINDEX', 'full');
  ctx_ddl.optimize_index('JOBINDEX_QY', 'full');
  ctx_ddl.optimize_index('JOBINDEX_GT', 'full');

end PRC_SYNC_JOBINDEX;

/
