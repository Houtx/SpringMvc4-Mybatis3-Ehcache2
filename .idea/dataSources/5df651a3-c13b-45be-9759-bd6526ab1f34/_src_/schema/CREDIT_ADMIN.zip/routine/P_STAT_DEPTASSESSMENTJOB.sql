CREATE procedure              P_STAT_DEPTASSESSMENTJOB(V_ISDELWHENEXIST VARCHAR2,RESULT OUT VARCHAR2)
IS


----V_JOBID T_META_PROCEDURE.JOBID%TYPE;--创建JOB时指定的JOBID
V_JOBID varchar(100);
V_SQL VARCHAR2(1000);

BEGIN

         V_SQL:='begin
         sys.dbms_job.submit(:jobid,
                        what => ''begin P_STAT_DEPTASSESSMENTEXECUTE('''''||V_ISDELWHENEXIST||'''''); end;'',
                        next_date =>SYSDATE
                       );
         commit;
         end;';
         EXECUTE IMMEDIATE V_SQL USING OUT V_JOBID;
        COMMIT;
       RESULT:=V_JOBID;
EXCEPTION
 When others then
        RESULT:=sqlerrm(SqlCode);
end P_STAT_DEPTASSESSMENTJOB;

/
