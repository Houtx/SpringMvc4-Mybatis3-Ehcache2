CREATE procedure P_WAITFEEDBACKFILE_INSERT(v_filegroupid in varchar2,v_userid in varchar2) is

v_fileid varchar2(100);--数据文件的ID
v_MessageId varchar2(100);--采集信息类ID

v_RuleDocId varchar2(500);--规则文档的ID

v_RuleDocVersion varchar2(500);--规则文档的版本
v_RuleDocFileName varchar2(500);--规则文档的文件名称

--关联策略
v_ConnType t_meta_assopara.assstrategy%type;

--是否推送关联疑问数据
--Y:表示推送
--N,表示不推送
v_IsPushConnQuestionData varchar2(500);


integrity_error exception; -- 声明异常变量
v_count integer;

 errno integer; -- 异常行号

 errmsg varchar2(1000); -- 异常消息
begin

--获取数据文件ID
select fileid ,MESSAGEID into v_fileid, v_MessageId from T_SYS_DATAFILEGROUPS where FILEGROUPID=v_filegroupid;



--检查是否推送关联疑问数据
select count(*) into v_count from t_meta_assopara where MESSAGEID=v_MessageId;
if(v_count=0) then

              v_IsPushConnQuestionData:='N';
else
--获取关联策略
        select assstrategy into v_ConnType from t_meta_assopara where MESSAGEID=v_MessageId;
           ---修改为可以推送_chenhua,主要是由于可能未设置关联策略，但未关联存在记录
          /*
          if(v_ConnType='N/A') then
              v_IsPushConnQuestionData:='N';
          else
              v_IsPushConnQuestionData:='Y';
          end if;
          */
          
          v_IsPushConnQuestionData:='Y';

end if;




select nvl(count(*),0) into v_count from T_META_RULEDOCUMENTHIS where MESSAGEID=v_MessageId AND DOCSTATE='Y';

if(v_count=0) then
    begin
     v_RuleDocId:=null;
     v_RuleDocVersion:=null;
     v_RuleDocFileName:=null;
    end;
 else
 --规则文档相关
select DOCID,DOCRULEVERSION,DOCFILENAME into v_RuleDocId,v_RuleDocVersion,v_RuleDocFileName from T_META_RULEDOCUMENTHIS where MESSAGEID=v_MessageId AND DOCSTATE='Y';
end if;


insert into T_RPT_STATICSQFILESENDRECORDS (FILEID,RECORDFILEID,MESSAGEID,SDEPTID,AUTHOR,AUTHORID
  ,RAWRECORDFILENAME,RAWRECORDFILERECORDCOUNT,XMLRECORDFILENAME,XMLRECORDFILERECORDCOUNT,DUPLICATERECORDCOUNT
  ,DATACHECKQUESTIONRECORDCOUNT ,CONNECTQUESTIONRECORDCOUNT,RULEDOCID,RULEVERSION,RULEFILENAME,CONNECTRULE
  ,ISINCLUDEDR,ISINCLUDEDCQR,ISINCLUDECQR,SENDSTATE,CREATETIME)select
--该文件的ID
 sys_GUID(),
 --记录所属文件ID
v_fileid,
 --所属采集信息ID
 T_SYS_DATAFILEINFO.MESSAGEID,
 --所属部门ID
 T_SYS_DATAFILEINFO.DEPTID,
 --生成该文件的用户
v_userid,
 --生成该文件的用户Id
v_userid,
--原始文件名称
 T_SYS_DATAFILEINFO.RAWRECORDFILENAME,
 --原始文件记录数
 T_SYS_DATAFILEINFO.RAWRECORDFILERECORDCOUNTS,
 --增量Xml文件名称
 T_SYS_DATAFILEINFO.RECORDFILENAME,
 --增量Xml文件中的记录数
 T_SYS_DATAFILEINFO.RECORDFILERECORDCOUNTS,
 ---下面是统计重复的记录数量
 (SELECT SUM(nvl(NOTINCREMENTRECORDCOUNTS, 0) +
             nvl(CENTERNOTINCREMENTRECORDCOUNTS, 0))
    FROM T_RPT_CINCREMENTDATACHECK
   WHERE T_SYS_DATAFILEINFO.FILEID = T_RPT_CINCREMENTDATACHECK.RECORDFILEID),
 ---下面是格式疑问的文件记录数
 (SELECT SUM(nvl(INVALIDRECORDCOUNTS, 0))
    FROM T_RPT_CDATACHECK
   WHERE T_SYS_DATAFILEINFO.FILEID = T_RPT_CDATACHECK.FILEID),
 ---下面是未关联的疑问记录数
((select nvl(T_RPT_CDATACHECK.VALIDRECORDCOUNTS, 0)
           FROM T_RPT_CDATACHECK
          where T_RPT_CDATACHECK.FILEID = v_fileid) -
       (select nvl(t_rpt_associatestatistics.connectcount, 0)
           FROM t_rpt_associatestatistics
          WHERE t_rpt_associatestatistics.RECORDFILEID = v_fileid)),
 --规则文件相关内容
 v_RuleDocId,
 v_RuleDocVersion,
v_RuleDocFileName,
 ---下面的是关联策略
 (SELECT CRULETYPE
    FROM T_RPT_ASSOCIATESTATISTICS
   WHERE T_SYS_DATAFILEINFO.FILEID = T_RPT_ASSOCIATESTATISTICS.RECORDFILEID),
 --文件中是否包括重复的记录
 'Y',
 --文件中是否包括数据清洗疑问的记录
 'Y',
 --文件中是否包括关联疑问的记录
 v_IsPushConnQuestionData,
 --发送状态
 'WAITING',
 --该记录的创建时间
 sysdate  from T_SYS_DATAFILEINFO where T_SYS_DATAFILEINFO.FILEID = v_fileid;



 update T_SYS_DATAFILEGROUPS SET ISFEEDBACK='Y',FEEDBACKUSERID=userid,FEEDBACKTIME=sysdate where FILEGROUPID=v_filegroupid;

 commit;
 exception -- 捕获异常
      when integrity_error then
           --p_reten := 0; --异常返回 0
           raise_application_error(errno,errmsg);
end P_WAITFEEDBACKFILE_INSERT;

/
