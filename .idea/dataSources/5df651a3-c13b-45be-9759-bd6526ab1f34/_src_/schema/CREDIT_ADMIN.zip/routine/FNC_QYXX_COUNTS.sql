CREATE function              fnc_qyxx_counts(f_i_qyid in varchar2,f_i_tablename in varchar2,f_i_tabletype in varchar2)
RETURN varchar2 IS
  --Project:江苏征信
  --Author：毛锋
  --Create Date：2010-09-01
  --Last Modified： 2010-09-01
  --Description：用于生成企业关联信息数量
  --Module：WEB服务端企业关联信息数量
var_count    varchar2(4000):='';
var_sql     varchar2(4000);
begin

  var_sql:='select /*+choose*/ count(*) as mycounts  from '|| f_i_tablename ||' tt
                     where  tt.recid not in (select  recid from t_datapause) and qyid='||f_i_qyid||'AND EXISTS (SELECT TTT.RECID FROM T_DATAPROCESS TTT
                 WHERE TTT.RECID = TT.RECID
                   AND TTT.ISVALID = ''Y'')';

  IF '4' = SUBSTR(f_i_tabletype,1,1)
     THEN
         var_sql := var_sql || ' AND EXISTS(                SELECT TTT.CREDITVALIDDATE
                  FROM T_DATAPROCESS TTT
                 WHERE TTT.RECID = TT.RECID
                   AND (TTT.CREDITVALIDDATE IS NULL OR TTT.CREDITVALIDDATE >= SYSDATE)
                  )';
  END IF;
  dbms_output.put_line(var_sql);
  execute immediate var_sql into var_count;
     return var_count;
end fnc_qyxx_counts;

/
