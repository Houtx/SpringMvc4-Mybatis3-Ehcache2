CREATE procedure p_stat_sgstj AUTHID CURRENT_USER AS

  v_sql VARCHAR2(500);
  v_yxjls NUMBER:=0;
  v_gljls NUMBER:=0;


  --查询出需要统计的双公示信息类信息
  CURSOR CUR_TAB IS
    SELECT s.type,s.messageid,t.messagename,t.tablename||'_FMT' tablename,d.deptid,d.deptname,d.orderid orderid1,t.orderid orderid2
    FROM t_dict_sgsmessage s,t_meta_table t,t_sys_department d
    WHERE s.messageid = t.messageid AND t.deptid = d.deptabbr;


  BEGIN
    --删除原来的统计结果
    execute immediate 'truncate table t_stat_sgstj';
    FOR tab IN CUR_TAB LOOP
      BEGIN
        EXIT WHEN CUR_TAB%NOTFOUND;
        --有效记录数
        v_sql := 'select count(*) from ' || tab.tablename;
        execute immediate v_sql INTO v_yxjls;
        --关联比对记录数
        v_sql := 'select count(*) from ' || tab.tablename || ' t1,t_dataprocess t2'
              || ' WHERE t1.recid = t2.recid and t2.messageid=''' || tab.messageid || ''' AND (t2.qyid>0 OR t2.grid>0)';
        execute immediate v_sql INTO v_gljls;
        --生成统计信息
        v_sql:='insert into t_stat_sgstj(deptid,deptname,messageid,messagename,yxjls,gljls,orderid1,orderid2,type)'
             || ' values ('''||tab.deptid||''','''||tab.deptname||''','''||tab.messageid||''','''||tab.messagename||'''
             ,'||v_yxjls||','||v_gljls||','||tab.orderid1||','||tab.orderid2||','''||tab.type||''')';
        execute immediate v_sql;
        commit;
        
        EXCEPTION
         when others then
          rollback;
          raise;
      END;
    END LOOP;

end p_stat_sgstj;
/
