CREATE PROCEDURE P_Assopara is

  Cursor curmessage is select messageid,T.Tablename,t.histablename  from t_meta_table t where t.deptid!='SX';

BEGIN
 FOR rd IN curmessage LOOP
    update t_Meta_Assopara t set t.tablename=rd.tablename,t.fmttable=rd.tablename||'_FMT',
    t.rttable=rd.tablename,
     t.histable=rd.histablename
     where t.messageid=rd.messageid;
     commit;
   END LOOP;

END;
/
