CREATE function IsDate (p_date in varchar2) Return Boolean
 is
   v_flag          boolean;
        v_year          number;
        v_month         number;
        v_day           number;
        v_isLeapYear    boolean;
        
begin
  --[初始化]--
        v_flag := True;
         
        --[获取信息]--
        v_year  := to_number(substr(p_date,1,4));
        v_month := to_number(substr(p_date,5,2));
        v_day   := to_number(substr(p_date,7,2));
         
        --[判断是否为闰年]--
        if (mod(v_year,400) = 0) Or (mod(v_year,100) <> 0 And mod(v_year,4) = 0) then
            v_isLeapYear := True;
        else
            v_isLeapYear := False;
        end if;
          --[判断月份]--
        if v_month < 1 Or v_month > 12 then
            v_flag := False;
            Return v_flag;
        end if;
         
        --[判断日期]--
        if v_month in (1,3,5,7,8,10,12) and (v_day < 1 or v_day > 31) then
            v_flag := False;
        end if;
        if v_month in (4,6,9,11) and (v_day < 1 or v_day > 30) then
            v_flag := False;
        end if;
        if v_month in (2) then
            if (v_isLeapYear) then
                --[闰年]--
                if (v_day < 1 or v_day > 29) then
                    v_flag := False;
                end if;
            else
                --[非闰年]--
                if (v_day < 1 or v_day > 28) then
                    v_flag := False;
                end if;
            end if;
        end if;
         
        --[返回结果]--
        Return v_flag;
end IsDate;
/
