CREATE procedure              P_resetEntCreditInfoExportSeq() IS
begin
     update t_sys_dict t set t.value=0 where mark='creditRepoetSequence';
     COMMIT;
end P_resetEntCreditInfoExportSeq;

/
