CREATE procedure              prc_update_hisorders_5 is
      -- 根据T_META_TABLE
      Cursor cur_main Is
        select s.tablename, s.columnname from (
             select b.deptid, b.deptname, a.tablename, a.messagename,
              c.columnname, c.dataitemname, c.datatype, c.isuse
              from T_META_TABLE a, T_SYS_DEPARTMENT b, T_META_COLUMN c
              where
                   a.deptid = b.deptabbr and a.messageid = c.messageid
                   and (c.datatype = 'D' and c.isuse = 'Y')
             ) s, (
             select * from (
              select tablename, count(*) as date_num from (
                     select b.deptid, b.deptname, a.tablename, a.messagename,
                            c.columnname, c.dataitemname
                            from T_META_TABLE a, T_SYS_DEPARTMENT b, T_META_COLUMN c
                            where
                                 a.deptid = b.deptabbr and a.messageid = c.messageid
                                 and (c.datatype = 'D' and c.isuse = 'Y')
                     )
                     group by tablename
              )
              where date_num = 5
             ) t
             where s.tablename = t.tablename
                 and (s.datatype = 'D' and s.isuse = 'Y')
                 and (length(s.deptid) = 3
                       and s.columnname in ('SPRQ')
                 )
             order by s.deptid, s.tablename;

       row_main              cur_main%Rowtype;
       v_tablename           varchar2(100) := '';
       v_columnname         varchar2(100) := '';

       v_sql_update          varchar2(300) := '';

begin
    open cur_main;
     Loop
         Fetch cur_main
          Into row_main;

      Exit When cur_main%Notfound;
           v_tablename := row_main.tablename;
           v_columnname := row_main.columnname;

           v_sql_update := 'update T_META_TABLE set hisorders = ' || ''''  || v_columnname || ' DESC''' ||
                           ' where tablename = ' || ''''  || v_tablename || '''';
           execute immediate v_sql_update;

      end Loop;
      commit;
      exception
    when others then
      rollback;
      raise;

end prc_update_hisorders_5;

/
