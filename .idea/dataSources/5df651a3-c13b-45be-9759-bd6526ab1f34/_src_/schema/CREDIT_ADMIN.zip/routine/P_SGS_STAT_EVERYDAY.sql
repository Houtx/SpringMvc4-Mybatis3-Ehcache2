CREATE procedure P_SGS_STAT_EVERYDAY is
begin
  BEGIN
    INSERT INTO T_SGS_STAT_EVERYDAY(DEPTNAME,ORDERID,TJRQ) 
    SELECT DEPTNAME,ORDERID,TRUNC(SYSDATE) FROM T_SGS_STAT_EVERYDAY WHERE TJRQ=TO_DATE('2017-06-01','YYYY-MM-DD');
    COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('ERROR');
  END;
  --最新决定日期--市级部门
  update t_sgs_stat_everyday t set (t.xkrq_max,t.cfrq_max)=(
select nvl(xkrq1,decode(sign(xkrq1-xkrq2),1,xkrq1,xkrq2)) xkrq,nvl(cfrq1,decode(sign(cfrq1-cfrq2),1,cfrq1,cfrq2)) cfrq from 
(select DEPTNAME,
       (SELECT MAX(XKRQ) FROM T_NJ_SGK_XZXK F WHERE F.DEPTID = T.DEPTABBR) XKRQ1,
       (SELECT MAX(XKRQ) FROM T_NJ_SGK_GRXZXK F WHERE F.DEPTID = T.DEPTABBR) XKRQ2,
       (SELECT MAX(cfRQ) FROM T_NJ_SGK_cfxx F WHERE F.DEPTID = T.DEPTABBR) cfRQ1,
       (SELECT MAX(cfRQ) FROM T_NJ_SGK_GRcfxx F WHERE F.DEPTID = T.DEPTABBR) cfRQ2
  from t_sys_department t
 where t.dep_parentid = 'NJ'
   and deptid not IN ('SX', 'XINXI')
   AND (ORDERID < 54)
 order by orderid) f where f.deptname=t.deptname) WHERE T.ORDERID<54 AND TJRQ=TRUNC(SYSDATE);
 COMMIT;
  --最新决定日期--区
  update t_sgs_stat_everyday t set (t.xkrq_max,t.cfrq_max)=(
select nvl(xkrq1,decode(sign(xkrq1-xkrq2),1,xkrq1,xkrq2)) xkrq,nvl(cfrq1,decode(sign(cfrq1-cfrq2),1,cfrq1,cfrq2)) cfrq from 
(select DEPTNAME,
       (SELECT MAX(XKRQ) FROM T_NJ_SGK_XZXK F WHERE F.DEPTID in (select deptabbr from t_sys_department m where m.dep_parentid=t.deptid) or f.deptid= T.DEPTABBR) XKRQ1,
       (SELECT MAX(XKRQ) FROM T_NJ_SGK_GRXZXK F WHERE F.DEPTID in (select deptabbr from t_sys_department m where m.dep_parentid=t.deptid) or f.deptid= T.DEPTABBR) XKRQ2,
       (SELECT MAX(cfRQ) FROM T_NJ_SGK_cfxx F WHERE F.DEPTID in (select deptabbr from t_sys_department m where m.dep_parentid=t.deptid) or f.deptid= T.DEPTABBR) cfRQ1,
       (SELECT MAX(cfRQ) FROM T_NJ_SGK_GRcfxx F WHERE F.DEPTID in (select deptabbr from t_sys_department m where m.dep_parentid=t.deptid) or f.deptid= T.DEPTABBR) cfRQ2
  from t_sys_department t
 where t.dep_parentid = 'NJ'
   and deptid not IN ('SX', 'XINXI')
   AND (ORDERID > 99)
 order by orderid) f where f.deptname=t.deptname) where t.orderid>99 and tjrq=trunc(sysdate);
 COMMIT;
 --最新报送日期 --市级部门
 update t_sgs_stat_everyday f set (f.Bsrq_Xk_Max,f.Bsrq_Cf_Max)=(
SELECT (select trunc(max(f.createtime))
          from t_sys_datafileinfo f
         where f.deptid = t.deptabbr
           and f.messageid in
               (select messageid
                  from t_meta_table
                 where messagename in ('社会法人行政许可信息', '个人行政许可信息'))) xkrq,
                 (select trunc(max(f.createtime))
          from t_sys_datafileinfo f
         where f.deptid = t.deptabbr
           and f.messageid in
               (select messageid
                  from t_meta_table
                 where messagename in ('社会法人行政处罚信息', '个人行政处罚信息'))) cfrq
  from t_sys_department t
 where t.dep_parentid = 'NJ'
   and t.deptid not IN ('SX', 'XINXI')
   AND t.ORDERID <54  and f.deptname=t.deptname) where f.ORDERID<54 AND f.TJRQ=TRUNC(SYSDATE);
   commit;
   --最新报送日期 --区
   update t_sgs_stat_everyday f set (f.Bsrq_Xk_Max,f.Bsrq_Cf_Max)=(
select (select trunc(max(f.createtime))
          from t_sys_datafileinfo f
         where f.deptid = t.deptabbr or F.DEPTID in (select deptabbr from t_sys_department m where m.dep_parentid=t.deptid)
           and f.messageid in
               (select messageid
                  from t_meta_table
                 where messagename in ('社会法人行政许可信息', '个人行政许可信息'))) xkrq,
                 (select trunc(max(f.createtime))
          from t_sys_datafileinfo f
         where f.deptid = t.deptabbr or F.DEPTID in (select deptabbr from t_sys_department m where m.dep_parentid=t.deptid)
           and f.messageid in
               (select messageid
                  from t_meta_table
                 where messagename in ('社会法人行政处罚信息', '个人行政处罚信息'))) cfrq
  from t_sys_department t
 where t.dep_parentid = 'NJ'
   and t.deptid not IN ('SX', 'XINXI')
   AND t.ORDERID >99  and f.deptname=t.deptname) where f.ORDERID>99 AND f.TJRQ=TRUNC(SYSDATE);
   commit;
   
   --法人许可超期，5月以来的  市级部门
   update t_sgs_stat_everyday m set m.cq_frxk=(
select nvl(xkcs1,0) from t_sys_department f ,(select deptid, count(*) xkcs1
  from t_nj_sgk_xzxk2 t
 where t.xkrq > to_date('2017-05-01', 'yyyy-mm-dd')
   and t.wscode = '00'
   and wstime > xkrq + 8
 group by deptid) m where f.deptabbr=m.deptid(+) and f.deptid not IN ('NJ','SX', 'XINXI')
   AND f.ORDERID < 54 and f.deptname=m.deptname) where m.ORDERID<54 AND m.TJRQ=TRUNC(SYSDATE);
   commit;
   
   --个人许可超期，5月以来的 市级部门
   update t_sgs_stat_everyday m set m.cq_grxk=(
select nvl(xkcs1,0) from t_sys_department f ,(select deptid, count(*) xkcs1
  from t_nj_sgk_grxzxk2 t
 where t.xkrq > to_date('2017-05-01', 'yyyy-mm-dd')
   and t.wscode = '00'
   and wstime > xkrq + 8
 group by deptid) m where f.deptabbr=m.deptid(+) and f.deptid not IN ('NJ','SX', 'XINXI')
   AND f.ORDERID < 54 and f.deptname=m.deptname) where m.ORDERID<54 AND m.TJRQ=TRUNC(SYSDATE);
   commit;
   
   --法人处罚超期 5月以来的 市级部门
   update t_sgs_stat_everyday m set m.cq_frcf=(
select nvl(xkcs1,0) from t_sys_department f ,(select deptid, count(*) xkcs1
  from t_nj_sgk_cfxx2 t
 where t.cfrq > to_date('2017-05-01', 'yyyy-mm-dd')
   and t.wscode = '00'
   and wstime > cfrq + 8
 group by deptid) m where f.deptabbr=m.deptid(+) and f.deptid not IN ('NJ','SX', 'XINXI')
   AND f.ORDERID < 54 and f.deptname=m.deptname) where m.ORDERID<54 AND m.TJRQ=TRUNC(SYSDATE);
   commit;
   
   --个人处罚超期 5月以来的 市级部门
   update t_sgs_stat_everyday m set m.cq_grcf=(
select nvl(xkcs1,0) from t_sys_department f ,(select deptid, count(*) xkcs1
  from t_nj_sgk_grcfxx2 t
 where t.cfrq > to_date('2017-05-01', 'yyyy-mm-dd')
   and t.wscode = '00'
   and wstime > cfrq + 8
 group by deptid) m where f.deptabbr=m.deptid(+) and f.deptid not IN ('NJ','SX', 'XINXI')
   AND f.ORDERID < 54 and f.deptname=m.deptname) where m.ORDERID<54 AND m.TJRQ=TRUNC(SYSDATE);
   commit;
   
   --法人许可超期 5月以来的 区
   update t_sgs_stat_everyday m set m.cq_frxk=(
select nvl(cs,0) cs from t_sys_department p,(select f.deptid, nvl(xkcs1, 0) cs
  from t_sys_department f,
       (select deptid, count(*) xkcs1
          from t_nj_sgk_xzxk2 t
         where t.xkrq > to_date('2017-05-01', 'yyyy-mm-dd')
           and t.wscode = '00'
           and wstime > xkrq + 8
         group by deptid) m
 where (f.deptabbr = m.deptid or
       m.deptid in (select deptid
                       from t_sys_department n
                      where n.dep_parentid = f.deptabbr))
   and f.dep_parentid = 'NJ'
   and f.deptid not IN ('NJ', 'SX', 'XINXI')
   AND (f.ORDERID > 99)
   ) q where p.deptid=q.deptid(+) and p.dep_parentid = 'NJ'
   and p.deptid not IN ('NJ', 'SX', 'XINXI')
   AND (p.ORDERID > 99) and p.deptname=m.deptname) where m.ORDERID>99 AND m.TJRQ=TRUNC(SYSDATE);
   commit;
   
   --个人许可超期 5月以来的 区
   update t_sgs_stat_everyday m set m.cq_grxk=(
select nvl(cs,0) cs from t_sys_department p,(select f.deptid, nvl(xkcs1, 0) cs
  from t_sys_department f,
       (select deptid, count(*) xkcs1
          from t_nj_sgk_grxzxk2 t
         where t.xkrq > to_date('2017-05-01', 'yyyy-mm-dd')
           and t.wscode = '00'
           and wstime > xkrq + 8
         group by deptid) m
 where (f.deptabbr = m.deptid or
       m.deptid in (select deptid
                       from t_sys_department n
                      where n.dep_parentid = f.deptabbr))
   and f.dep_parentid = 'NJ'
   and f.deptid not IN ('NJ', 'SX', 'XINXI')
   AND (f.ORDERID > 99)
   ) q where p.deptid=q.deptid(+) and p.dep_parentid = 'NJ'
   and p.deptid not IN ('NJ', 'SX', 'XINXI')
   AND (p.ORDERID > 99) and p.deptname=m.deptname) where m.ORDERID>99 AND m.TJRQ=TRUNC(SYSDATE);
   commit;
   
   --法人处罚超期 5月以来的 区
   update t_sgs_stat_everyday m set m.cq_frcf=(
select nvl(cs,0) cs from t_sys_department p,(select f.deptid, nvl(xkcs1, 0) cs
  from t_sys_department f,
       (select deptid, count(*) xkcs1
          from t_nj_sgk_cfxx2 t
         where t.cfrq > to_date('2017-05-01', 'yyyy-mm-dd')
           and t.wscode = '00'
           and wstime > cfrq + 8
         group by deptid) m
 where (f.deptabbr = m.deptid or
       m.deptid in (select deptid
                       from t_sys_department n
                      where n.dep_parentid = f.deptabbr))
   and f.dep_parentid = 'NJ'
   and f.deptid not IN ('NJ', 'SX', 'XINXI')
   AND (f.ORDERID > 99)
   ) q where p.deptid=q.deptid(+) and p.dep_parentid = 'NJ'
   and p.deptid not IN ('NJ', 'SX', 'XINXI')
   AND (p.ORDERID > 99) and p.deptname=m.deptname) where m.ORDERID>99 AND m.TJRQ=TRUNC(SYSDATE);
   commit;
   
   --个人处罚超期 5月以来 区
   update t_sgs_stat_everyday m set m.cq_grcf=(
select nvl(cs,0) cs from t_sys_department p,(select f.deptid, nvl(xkcs1, 0) cs
  from t_sys_department f,
       (select deptid, count(*) xkcs1
          from t_nj_sgk_grcfxx2 t
         where t.cfrq > to_date('2017-05-01', 'yyyy-mm-dd')
           and t.wscode = '00'
           and wstime > cfrq + 8
         group by deptid) m
 where (f.deptabbr = m.deptid or
       m.deptid in (select deptid
                       from t_sys_department n
                      where n.dep_parentid = f.deptabbr))
   and f.dep_parentid = 'NJ'
   and f.deptid not IN ('NJ', 'SX', 'XINXI')
   AND (f.ORDERID > 99)
   ) q where p.deptid=q.deptid(+) and p.dep_parentid = 'NJ'
   and p.deptid not IN ('NJ', 'SX', 'XINXI')
   AND (p.ORDERID > 99) and p.deptname=m.deptname) where m.ORDERID>99 AND m.TJRQ=TRUNC(SYSDATE);
   commit;
   
end P_SGS_STAT_EVERYDAY;
/
