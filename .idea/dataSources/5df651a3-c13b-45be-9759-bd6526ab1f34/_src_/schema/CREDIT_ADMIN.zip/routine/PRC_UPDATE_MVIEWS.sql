CREATE procedure              prc_update_mviews is
begin
  prc_add_joblog('prc_update_mviews', '1.1.0 开始刷新 MV_QYZTBS_SJLY_QYZT');
  commit;
  dbms_mview.refresh('MV_QYZTBS_SJLY_QYZT');
  prc_add_joblog('prc_update_mviews', '1.1.1 刷新 MV_QYZTBS_SJLY_QYZT 完成');
  commit;

  prc_add_joblog('prc_update_mviews', '1.1.2 开始刷新 MV_TJ_XXL_SJX_JLS');
  commit;
  dbms_mview.refresh('MV_TJ_XXL_SJX_JLS');
  insert into MV_TJ_XXL_SJX_JLS_HIS SELECT * FROM MV_TJ_XXL_SJX_JLS;

  dbms_mview.refresh('MV_TJ_XXL_SJX_JLS2');
  insert into MV_TJ_XXL_SJX_JLS_HIS2
  SELECT *
    FROM MV_TJ_XXL_SJX_JLS2 v
   where not exists
   (select * from MV_TJ_XXL_SJX_JLS_HIS2 h where v.dt = h.dt);

  prc_add_joblog('prc_update_mviews', '1.1.3 刷新 MV_TJ_XXL_SJX_JLS 完成');
  commit;


  prc_add_joblog('prc_update_mviews', '2.1.0 开始刷新 MV_GONGSHANG_SLDJBG_QY_SSQY');
  commit;
  dbms_mview.refresh('MV_GONGSHANG_SLDJBG_QY_SSQY');
  prc_add_joblog('prc_update_mviews', '2.1.0.1 MV_GONGSHANG_SLDJBG_QY_SSQY OK');
  commit;
  dbms_mview.refresh('MV_GONGSHANG_QY_HHSYML');
  prc_add_joblog('prc_update_mviews', '2.1.0.2 MV_GONGSHANG_QY_HHSYML OK');
  commit;
  dbms_mview.refresh('MV_GONGSHANG_QY_SLNF');  --设立年份
  prc_add_joblog('prc_update_mviews', '2.1.0.3 MV_GONGSHANG_QY_SLNF OK');
  commit;
  dbms_mview.refresh('MV_GONGSHANG_QY_SLYF');  --设立月份
  prc_add_joblog('prc_update_mviews', '2.1.0.4 MV_GONGSHANG_QY_SLYF OK');
  commit;
  dbms_mview.refresh('MV_GONGSHANG_QY_SLYF_HY');  --设立月份 - 行业
  prc_add_joblog('prc_update_mviews', '2.1.0.5 MV_GONGSHANG_QY_SLYF_HY OK');
  commit;
  dbms_mview.refresh('MV_GONGSHANG_QY_SLYF_DQHY');  --设立月份 - 地区 - 行业
  prc_add_joblog('prc_update_mviews', '2.1.0.6 MV_GONGSHANG_QY_SLYF_DQHY OK');
  commit;
  ctx_ddl.sync_index('JOBINDEX_QY');
  ctx_ddl.optimize_index('JOBINDEX_QY', 'full');
  prc_add_joblog('prc_update_mviews', '2.1.0.7 JOBINDEX_QY OK');
  commit;

  prc_add_joblog('prc_update_mviews', '2.1.1 刷新 MV_GONGSHANG_SLDJBG_QY_SSQY 完成');
  commit;


  prc_add_joblog('prc_update_mviews', '2.3.0 开始刷新 MV_GONGSHANG_QYLHXW_SSQY');
  commit;
  dbms_mview.refresh('MV_GONGSHANG_QYLHXW_SSQY');  --良好
  dbms_mview.refresh('MV_GONGSHANG_QYBLXW_SSQY');  --不良
  prc_add_joblog('prc_update_mviews', '2.3.1 刷新 MV_GONGSHANG_QYLHXW_SSQY 完成');
  commit;



  prc_add_joblog('prc_update_mviews', '3.5.0 开始刷新 MV_GONGSHANG_NJXX');
  commit;
  dbms_mview.refresh('MV_GONGSHANG_NJXX');       --年检
  dbms_mview.refresh('MV_GONGSHANG_NJXX_LAST');  --年检
  prc_add_joblog('prc_update_mviews', '3.5.1 刷新 MV_GONGSHANG_NJXX 完成');
  commit;



  prc_add_joblog('prc_update_mviews', '2.2.0 开始刷新 MV_GONGSHANG_SLDJBG_GT_SSQY');
  commit;
  dbms_mview.refresh('MV_GONGSHANG_SLDJBG_GT_SSQY');
  prc_add_joblog('prc_update_mviews', '2.2.0.1 MV_GONGSHANG_SLDJBG_GT_SSQY OK');
  commit;
  dbms_mview.refresh('MV_GONGSHANG_GT_SLNF');  --设立年份
  prc_add_joblog('prc_update_mviews', '2.2.0.2 MV_GONGSHANG_GT_SLNF OK');
  commit;
  dbms_mview.refresh('MV_GONGSHANG_GT_SLYF');  --设立月份
  prc_add_joblog('prc_update_mviews', '2.2.0.3 MV_GONGSHANG_GT_SLYF OK');
  commit;
  dbms_mview.refresh('MV_GONGSHANG_GT_SLYF_HY');  --设立月份 - 行业
  prc_add_joblog('prc_update_mviews', '2.2.0.4 MV_GONGSHANG_GT_SLYF_HY OK');
  commit;
  dbms_mview.refresh('MV_GONGSHANG_GT_SLYF_DQHY');  --设立月份 - 地区 - 行业
  prc_add_joblog('prc_update_mviews', '2.2.0.5 MV_GONGSHANG_GT_SLYF_DQHY OK');
  commit;
  ctx_ddl.sync_index('JOBINDEX_GT');
  ctx_ddl.optimize_index('JOBINDEX_GT', 'full');
  prc_add_joblog('prc_update_mviews', '2.2.0.6 JOBINDEX_GT OK');
  commit;
  prc_add_joblog('prc_update_mviews', '2.2.1 刷新 MV_GONGSHANG_SLDJBG_GT_SSQY 完成');
  commit;



  prc_add_joblog('prc_update_mviews', '2.4.0 开始刷新 MV_ZZJGDM');
  commit;
  dbms_mview.refresh('MV_ZHIJIAN_ZZJGDM');
  dbms_mview.refresh('MV_NANJING_ZZJGDMDJXX');
  prc_add_joblog('prc_update_mviews', '2.4.1 刷新 MV_ZZJGDM 完成');
  commit;




  --HCXX
  prc_add_joblog('prc_update_mviews', '3.1.0 开始刷新 MV_XXHC_CFXX');
  commit;
  dbms_mview.refresh('MV_XXHC_CFXX');
  prc_add_joblog('prc_update_mviews', '3.1.1 刷新 MV_XXHC_CFXX 完成');
  commit;

  prc_add_joblog('prc_update_mviews', '3.2.0 开始刷新 MV_XXHC_FYAJ');
  commit;
  dbms_mview.refresh('MV_XXHC_FYAJ');
  prc_add_joblog('prc_update_mviews', '3.2.1 刷新 MV_XXHC_FYAJ 完成');
  commit;

  prc_add_joblog('prc_update_mviews', '3.3.0 开始刷新 MV_XXHC_FYAJ_FRBZX');
  commit;
  dbms_mview.refresh('MV_XXHC_FYAJ_FRBZX');
  prc_add_joblog('prc_update_mviews', '3.3.1 刷新 MV_XXHC_FYAJ_FRBZX 完成');
  commit;

  prc_add_joblog('prc_update_mviews', '3.4.0 开始刷新 MV_XXHC_QSFXX');
  commit;
  dbms_mview.refresh('MV_XXHC_QSFXX');
  prc_add_joblog('prc_update_mviews', '3.4.1 刷新 MV_XXHC_QSFXX 完成');
  commit;

end prc_update_mviews;

/
