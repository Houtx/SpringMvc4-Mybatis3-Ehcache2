CREATE procedure P_BATCH_ZTKMAPPING_SGS is

  -----------批量添加主题库生成配置，目前仅支持添加双公示主题库
  V_SQL_XK VARCHAR(4000) := 'select a0.qyid,
       a0.XK_BM XK_BM,
       a0.XK_XDR_SWDJ XK_XDR_SWDJ,
       a0.XK_WSH XK_WSH,
       a0.XK_FR XK_FR,
       a0.XK_XDR_ZDM XK_XDR_ZDM,
       a0.XK_SYFW XK_SYFW,
       a0.XK_XZJG XK_XZJG,
       a0.RECID RECID,
       a0.XK_ZT XK_ZT,
       a0.XK_SXQ XK_SXQ,
       a0.XK_SPLB XK_SPLB,
       a0.XK_XDR_GSDJ XK_XDR_GSDJ,
       a0.BZ BZ,
       a0.XK_XDR_SFZ XK_XDR_SFZ,
       a0.XK_JZQ XK_JZQ,
       a0.XK_XDR_SHXYM XK_XDR_SHXYM,
       a1.CREATETIME_DEPT SJC,
       a0.XK_XMMC XK_XMMC,
       a0.XK_NR XK_NR,
       a0.DFBM DFBM,
       a1.DEPTID DEPTID,
       a0.XK_XDR XK_XDR,
       a1.MESSAGEID MESSAGEID
  from credit_product.{0} a0, T_DATAPROCESS a1
 where 1 = 1
   and a0.RECID = a1.RECID
   and a0.XK_ZT = ''0''';

  V_SQL_CF           VARCHAR(4000) := 'select a0.CF_WSH,
       a0.CF_AJMC,
       a0.CF_SY,
       a0.CF_ZL,
       a0.CF_YJ,
       a0.CF_XDR,
       a0.CF_XDR_SHXYM,
       a0.CF_XDR_ZDM,
       a0.CF_XDR_GSDJ,
       a0.CF_XDR_SWDJ,
       a0.CF_XDR_SFZ,
       a0.CF_FR,
       a0.CF_JG,
       a0.CF_SXQ,
       a0.CF_JZQ,
       a0.CF_XZJG,
       a0.CF_ZT,
       a0.DFBM,
       a1.CREATETIME_DEPT SJC,
       a0.BZ,
       a0.CF_BM,
       a0.CF_SYFW,
       a0.CF_SXYZCD,
       a0.CF_GSJZQ,
       a1.RECID,
       a1.DEPTID,
       a1.MESSAGEID,
       a1.QYID
  from T_HA_SHIYAOJIAN_SGSCF a0, T_DATAPROCESS a1
 where 1 = 1
   and a0.recid = a1.recid
   and a0.CF_ZT = ''0''';
  V_ZTK_DOMAINID     VARCHAR2(50) := '016';
  V_ZTK_FLAG         T_ZTK_TYPE.DOMAINFLAG%TYPE;
  V_ZTK_MESSAGEID_XK T_ZTK_META_TABLE.MESSAGEID%TYPE;
  V_ZTK_MESSAGEID_CF T_ZTK_META_TABLE.MESSAGEID%TYPE;
  cursor cur is
    select t.*, ts.deptabbr, ts.deptname
      from T_META_TABLE t, T_SYS_DEPARTMENT ts
     where t.messageid not in (select messageid from T_ZTK_MAPPING t)
       and t.messagename in ('行政处罚公示信息', '行政许可公示信息')
       and ts.deptabbr = t.deptid;
  V_SQL_TEMP VARCHAR2(4000) := '';
begin
  SELECT DOMAINFLAG
    INTO V_ZTK_FLAG
    FROM T_ZTK_TYPE
   where DOMAINID = V_ZTK_DOMAINID;
  SELECT MESSAGEID
    INTO V_ZTK_MESSAGEID_XK
    FROM T_ZTK_META_TABLE
   where DOMAINID = V_ZTK_DOMAINID
     AND MESSAGENAME = '行政许可公示信息';
  SELECT MESSAGEID
    INTO V_ZTK_MESSAGEID_CF
    FROM T_ZTK_META_TABLE
   where DOMAINID = V_ZTK_DOMAINID
     AND MESSAGENAME = '行政处罚公示信息';

  for rd in cur loop
    IF (rd.messagename = '行政处罚公示信息') THEN
      insert into T_ZTK_MAPPING
        (MAPPINGID,
         DOMAINID,
         MESSAGEID,
         MAPPINGTYPE,
         DEPTID,
         DEPTNAME,
         MESSAGEID_SRC,
         MESSAGENAME_SRC,
         TABLENAME_SRC,
         TABLEJOIN,
         DATASQL,
         USERCONDITION,
         SQLDESC,
         PNAME,
         ISUSE,
         ORDERID,
         CREATETIME,
         UPDATETIME,
         ISMODIFIED,
         ISVERIFIED,
         VERIFYTIME,
         VERIFYCOMMENT,
         VERIFYUSER)
      values
        (V_ZTK_FLAG || SYS_GUID(),
         V_ZTK_DOMAINID,
         V_ZTK_MESSAGEID_CF,
         '1',
         rd.deptid || ',NTERNAL',
         rd.deptname || ',内部处理',
         rd.messageid || ',C2CAB2561287B6EEE040002005173A96',
         rd.messagename || ',数据处理标识表',
         rd.tablename || ',T_DATAPROCESS',
         ' a0.RECID = a1.RECID',
         replace(V_SQL_CF, '{0}', rd.tablename),
         'a0.CF_ZT=''0''',
         rd.deptname || rd.messagename,
         '',
         'Y',
         1,
         sysdate,
         sysdate,
         'N',
         'Y',
         sysdate,
         '自动生成配置审核通过',
         'admin');
    ELSE
    
      --    V_SQL_TEMP:=replace(V_SQL_XK,'{0}',rd.tablename);
      insert into T_ZTK_MAPPING
        (MAPPINGID,
         DOMAINID,
         MESSAGEID,
         MAPPINGTYPE,
         DEPTID,
         DEPTNAME,
         MESSAGEID_SRC,
         MESSAGENAME_SRC,
         TABLENAME_SRC,
         TABLEJOIN,
         DATASQL,
         USERCONDITION,
         SQLDESC,
         PNAME,
         ISUSE,
         ORDERID,
         CREATETIME,
         UPDATETIME,
         ISMODIFIED,
         ISVERIFIED,
         VERIFYTIME,
         VERIFYCOMMENT,
         VERIFYUSER)
      values
        (V_ZTK_FLAG || SYS_GUID(),
         V_ZTK_DOMAINID,
         V_ZTK_MESSAGEID_XK,
         '1',
         rd.deptid || ',NTERNAL',
         rd.deptname || ',内部处理',
         rd.messageid || ',C2CAB2561287B6EEE040002005173A96',
         rd.messagename || ',数据处理标识表',
         rd.tablename || ',T_DATAPROCESS',
         ' a0.RECID = a1.RECID',
         replace(V_SQL_XK, '{0}', rd.tablename),
         'a0.XK_ZT=''0''',
         rd.deptname || rd.messagename,
         '',
         'Y',
         1,
         sysdate,
         sysdate,
         'N',
         'Y',
         sysdate,
         '自动生成配置审核通过',
         'admin');
    
    END IF;
    commit;
  end loop;

end P_BATCH_ZTKMAPPING_SGS;
/
