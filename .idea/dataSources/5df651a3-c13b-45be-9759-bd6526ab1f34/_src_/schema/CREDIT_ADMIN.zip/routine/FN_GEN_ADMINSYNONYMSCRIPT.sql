CREATE function FN_GEN_ADMINSYNONYMSCRIPT(v_messageid in varchar2)
RETURN varchar2 IS
--根据T_META_TABLE产生credit_admin用户中表的同义词
   var_sql    varchar2(4000):='';
   var_deptId  t_Meta_Table.DEPTID%TYPE;
   var_shortName  t_Meta_Table.MESSAGEABBR%TYPE;
   var_columnsql  varchar2(4000):='';
   var_isNull varchar2(200):='';
   CURSOR cur_columns IS SELECT * FROM T_META_COLUMN WHERE MESSAGEID=v_messageid order by orderid asc;
   var_table varchar2(200):='';
   var_nopostfixtable varchar2(200):='';
   row_column cur_columns%ROWTYPE;
begin

    var_sql:='---请在credit_admin用户下执行'||chr(9)||chr(13);
    select TABLENAME,DEPTID,MESSAGEABBR INTO  var_table,var_deptId,var_shortName from t_Meta_Table  t where t.MESSAGEID=v_messageid;
    --原始库
    var_nopostfixtable:=var_table;
    var_table:=var_nopostfixtable||'_RAW';
    var_sql :=var_sql||'create or replace synonym '||var_table||' FOR CREDIT_GATHER.'||var_nopostfixtable ||';'||chr(9)||chr(13);
    --CENTER库
    var_table:=var_nopostfixtable||'_FMT';
    var_sql :=var_sql||'create or replace synonym '||var_table||' FOR CREDIT_CENTER.'||var_table ||';'||chr(9)||chr(13);
    --PRODUCT

    var_table:=var_nopostfixtable||'';
    var_sql :=var_sql||'create or replace synonym '||var_table||' FOR CREDIT_PRODUCT.'||var_table ||';'||chr(9)||chr(13);

    var_table:=var_nopostfixtable||'_HIS';
    var_sql :=var_sql||'create or replace synonym '||var_table||' FOR CREDIT_PRODUCT.'||var_table ||';'||chr(9)||chr(13);

return var_sql;
end FN_GEN_ADMINSYNONYMSCRIPT;

/
