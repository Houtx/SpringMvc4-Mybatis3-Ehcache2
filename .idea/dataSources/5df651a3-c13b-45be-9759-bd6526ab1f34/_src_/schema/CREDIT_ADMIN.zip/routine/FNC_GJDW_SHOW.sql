CREATE function              fnc_gjdw_show(f_i_deptid in varchar2)
RETURN varchar2 IS
  --Project:江苏征信
  --Author：毛锋
  --Create Date：2009-04-01
  --Last Modified： 2009-04-01
  --Description：用于动态生成共建单位列表
  --Module：WEB服务端首页共建单位
var_note    varchar2(4000):='';
var_count   number := 1;
var_sql     varchar2(4000);
begin
    for cur_main in (select messagename from T_META_TABLE tt
                     where deptid=f_i_deptid and isuse='Y'
                     order by deptid) loop
        var_note := to_char(var_note||var_count||'.'||cur_main.messagename||'<br>');
        var_count := var_count+1;
    end loop;
    return var_note;
end fnc_gjdw_show;

/
