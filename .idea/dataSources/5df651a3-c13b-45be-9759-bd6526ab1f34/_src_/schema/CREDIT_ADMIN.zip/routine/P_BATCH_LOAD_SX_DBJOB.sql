CREATE procedure P_BATCH_LOAD_SX_DBJOB AUTHID CURRENT_USER is
CURSOR C_ALLDATA IS
  select 'analyze table '||dbusername||'.'||tablename||' compute statistics' SQLSTR from t_meta_table_db t where t.dbusername in ('MID_SX','MID_XINXI');

begin
  --全部执行一次计算统计  
  FOR R_SQLDATA IN C_ALLDATA LOOP
    BEGIN
      EXECUTE IMMEDIATE R_SQLDATA.SQLSTR;
    EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.put_line(SQLERRM);
    END;
  END LOOP;  
  --直接插入对接表启动
  insert into credit_gather.t_filepreview(
  deptid,uploadbatch,fileid,messageid,sourcename,uploadtime,userid,fileflag,sourcetype)
  select m.deptid,sys_guid(),sys_guid(),t.messageid,'DB:'||f.deptname||m.messageshortname||to_char(sysdate,'yyyymmdd'),
  sysdate,'后台对接程序','2','ORACLE' from t_meta_table_db t,t_meta_table m,t_sys_department f where t.messageid=m.messageid and m.deptid=f.deptabbr and t.dbusername in ('MID_SX') and (t.dbusername,t.tablename) in 
  (select owner,table_name from dba_tables  where num_rows>0 and owner like 'MID%');
  COMMIT;
end P_BATCH_LOAD_SX_DBJOB;
/
