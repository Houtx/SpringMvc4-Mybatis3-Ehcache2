CREATE function FN_ISTYJJR(p_date in date)
RETURN varchar2 IS
--是通用的节假日
   var_result    varchar2(1):='N';
   var_md    varchar2(10);---传递月日
   var_jjr    varchar2(1000);---传递月日
   var_jjrs            ty_str_split;
   V_LENGTH INTEGER;
   V_J integer;

begin
   select value into var_jjr from t_sys_dict t where mark='JJR';
   if var_jjr is not null
     then 
     var_jjrs:=FN_SPLIT(var_jjr, ',');     
     select  ltrim(to_char(p_date, 'mm'),0)||'.'||ltrim(to_char(p_date, 'dd'),0)  into var_md from dual;
     V_LENGTH:=var_jjrs.COUNT;
          V_J:=1;
          WHILE V_J<=V_LENGTH
          LOOP
              IF(var_jjrs(V_J)=var_md) THEN 
                 var_result:='Y';
                 EXIT;
              END IF;
               V_J:=V_J+1;   
         END LOOP;

    end if;
return var_result;
end FN_ISTYJJR;
/
