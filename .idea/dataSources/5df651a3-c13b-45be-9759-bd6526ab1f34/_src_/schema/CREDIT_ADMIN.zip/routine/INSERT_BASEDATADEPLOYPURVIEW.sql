CREATE procedure              insert_BASEDATADEPLOYPURVIEW is
 sqlstr varchar(4000);
 v_roleid varchar2(100) := '';
 Cursor cur_main Is
      select deptid from t_sys_department    order by orderid;
        row_main            cur_main%Rowtype;
        v_deptid           varchar2(100) := '';
  Cursor cur_main2 Is
              select messageid from t_cms_deptbasedatadeploy  order by deptid;
               row_main2            cur_main2%Rowtype;
                v_messageid           varchar2(100) := '';

begin
 delete from  T_CMS_BASEDATADEPLOY_PURVIEW  ;
     open cur_main;

     Loop
          Fetch cur_main
          Into row_main;
      Exit When cur_main%Notfound;

           v_deptid := row_main.deptid;
              begin
               open cur_main2;

              loop
                Fetch cur_main2
                Into row_main2;
                Exit When cur_main2%Notfound;

                  v_messageid := row_main2.messageid;
                   sqlstr:='insert into T_CMS_BASEDATADEPLOY_PURVIEW(deptid,messageid,roleid) values ('''||v_deptid||''','''||v_messageid||''','''||v_roleid||''')';
               begin
                execute immediate sqlstr;
                commit;
                end;

              end loop;
              close cur_main2;
              end;

     end Loop;
     close cur_main;
end insert_BASEDATADEPLOYPURVIEW;

/
