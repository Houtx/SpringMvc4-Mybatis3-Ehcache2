CREATE function              fnc_splitvalue2name(f_i_value in varchar2,f_i_sql in varchar2,f_i_split in varchar2)
RETURN varchar2 IS
  --Project:江苏征信
  --Author：杜炼
  --Create Date：2010-01-28
  --Last Modified： 2010-01-28
  --Description：用于显示用,号隔开的字段表示的名称
  --Module：公用
var_note    varchar2(1000):='';
var_count   number := 0;
   r_emp varchar2(1000); --声明一个行类型变量
   p_salary NUMBER; --声明一个标量变量
   CURSOR c IS SELECT * FROM TABLE (CAST (fn_split (f_i_value, f_i_split) AS ty_str_split));
   r c%ROWTYPE;
var_sql  varchar2(1000):='';
begin
    OPEN c ;
   LOOP
     FETCH c
           INTO r;
     EXIT WHEN c%NOTFOUND;
      var_sql:=f_i_sql||'='''||r.column_value||'''';
      execute immediate var_sql into r_emp;
      var_note := to_char(var_note||r_emp||',');
        var_count := var_count+1;
   END LOOP;
   CLOSE c; --关闭游标

    if var_count>0 then
       var_note:=SUBSTR(var_note,0,LENGTH(var_note)-1);
    end if;
    return var_note;
end fnc_splitvalue2name;

/
