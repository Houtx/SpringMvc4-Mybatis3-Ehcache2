CREATE procedure P_DELETE_ZERO is
CURSOR C IS SELECT FILEID from t_sys_datafileinfo t where t.rawrecordfilerecordcounts=0;
V_FILEID VARCHAR2(50);
begin
  FOR RC IN C LOOP
      V_FILEID := RC.FILEID;
      p_delefilebyfileid(V_FILEID);
  END LOOP;
  CLOSE C;
end P_DELETE_ZERO;
/
