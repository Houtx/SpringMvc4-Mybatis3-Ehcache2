CREATE procedure P_BATCH_REASSOCIATEALL is
begin
  insert into t_sys_processcommand(cmdid,filegroupid,userid,cmdcode,cmd,cmdtime,runstate)
  select seq_cmdid_key.nextval,filegroupid,'admin','CXGL','重新关联',sysdate,'0' from t_sys_datafilegroups;
  COMMIT;
end P_BATCH_REASSOCIATEALL;
/
