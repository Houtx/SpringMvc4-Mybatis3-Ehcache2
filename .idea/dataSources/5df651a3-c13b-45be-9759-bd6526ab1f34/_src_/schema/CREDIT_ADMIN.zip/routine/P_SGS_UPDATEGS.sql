CREATE procedure P_SGS_UPDATEGS is
begin
  --先更新一下有效状态
  P_SGS_UPDATECFQX;
  --更新到同步诚信南京的表里去
  INSERT INTO T_NJ_SGK_CFXX3(recid, cfwh, ajmc, cfsy, cfzl, cfyj, qymc, shxydm, zzjgdm, cfjg, cfrq, cfjgmc, bz, xzqh, cfcx,
  fddbrxm, dbrsfzhm, qlbm, syfw, sxyzcd, gsjzq, bmmc, sjc)
  SELECT recid, cfwh, ajmc, cfsy, CFLB1, cfyj, qymc, NVL(SHXYDM,QYZCH), zzjgdm, cfjg, CFRQ, cfjgmc, bz, xzqh, cfcx,
  fddbrxm, dbrsfzhm, qlbm, syfw, sxyzcd, GSJZQ, 'DEPT_'||DEPTID, TRUNC(sjc) FROM T_NJ_SGK_CFXX2 T
  WHERE VALID='Y' AND NOT EXISTS (SELECT 1 FROM T_NJ_SGK_CFXX3 F WHERE F.RECID=T.RECID) AND T.WSCODE='00' AND (T.SYFW IS NULL OR T.SYFW='0') AND (T.GSJZQ > T.CFRQ OR T.GSJZQ IS NULL)
  AND T.DEPTID NOT IN ('NJ_DITIE');
  COMMIT;
  
  DELETE FROM T_NJ_SGK_CFXX3 T WHERE T.RECID IN (SELECT RECID FROM T_NJ_SGK_CFXX2 F WHERE F.VALID='N');
  COMMIT;

/* 个人处罚暂不公示
  INSERT INTO T_NJ_SGK_GRCFXX3(recid, cfwh, ajmc, cfsy, cfzl, cfyj, xm, sfzjhm, cfjg, cfrq, cfjgmc, bz, xzqh, 
cfcx, qlbm, syfw, sxyzcd, gsjzq, bmmc, sjc)
  SELECT recid, cfwh, ajmc, cfsy, cflb1, cfyj, xm, sfzjhm, cfjg, CFRQ, cfjgmc, bz, xzqh, 
cfcx, qlbm, syfw, sxyzcd, GSJZQ, 'DEPT_'||DEPTID, TRUNC(sjc) FROM T_NJ_SGK_GRCFXX2 T
  WHERE NOT EXISTS (SELECT 1 FROM T_NJ_SGK_GRCFXX3 F WHERE F.RECID=T.RECID) AND T.WSCODE='00' AND (T.SYFW IS NULL OR T.SYFW='0') AND (T.GSJZQ > T.CFRQ OR T.GSJZQ IS NULL)
  AND T.DEPTID NOT IN ('NJ_DITIE');
  COMMIT;
  
  DELETE FROM T_NJ_SGK_GRCFXX3 T WHERE T.RECID IN (SELECT RECID FROM T_NJ_SGK_GRCFXX2 F WHERE F.GSJZQ<SYSDATE);
  COMMIT;
  */
  
  INSERT INTO T_NJ_SGK_GRXZXK3(recid,xkwh, xmmc, splb, xknr, xm, sfzjhm, xkrq, xkyxq, xkjg, bz, xzqh, qlbm, syfw, 
bmmc, sjc)
  SELECT recid,xkwh, xmmc, splb, xknr, xm, sfzjhm, xkrq, xkyxq, xkjg, bz, xzqh, qlbm, syfw, 'DEPT_'||DEPTID, TRUNC(sjc) FROM T_NJ_SGK_GRXZXK2 T
  WHERE NOT EXISTS (SELECT 1 FROM T_NJ_SGK_GRXZXK3 F WHERE F.RECID=T.RECID) AND T.WSCODE='00' AND (T.SYFW IS NULL OR T.SYFW='0') AND T.XKRQ<SYSDATE AND (T.XKRQ<=T.XKYXQ OR T.XKYXQ IS NULL);
  COMMIT; 
  
  INSERT INTO T_NJ_SGK_XZXK3(recid,xkwh, xmmc, splb, xknr, qymc, shxydm, zzjgdm, xkrq, xkyxq, xkjg, bz, xzqh, fddbrxm, 
dbrsfzhm,qlbm, syfw, bmmc, sjc)
  SELECT recid,xkwh, xmmc, splb, xknr, qymc, NVL(SHXYDM,QYZCH), zzjgdm, xkrq, xkyxq, xkjg, bz, xzqh, fddbrxm, 
dbrsfzhm,qlbm, syfw, 'DEPT_'||DEPTID, TRUNC(sjc) FROM T_NJ_SGK_XZXK2 T
  WHERE NOT EXISTS (SELECT 1 FROM T_NJ_SGK_XZXK3 F WHERE F.RECID=T.RECID) AND T.WSCODE='00' AND (T.SYFW IS NULL OR T.SYFW='0') AND T.XKRQ<SYSDATE AND (T.XKRQ<=T.XKYXQ OR T.XKYXQ IS NULL);
  COMMIT;
  
  UPDATE T_NJ_SGK_CFXX3 T SET T.BMMC=(SELECT DEP_PARENTID FROM V_QJBM F WHERE F.DEPTID=T.BMMC) WHERE T.BMMC IN (SELECT DEPTID FROM V_QJBM);
  COMMIT;
  UPDATE T_NJ_SGK_GRCFXX3 T SET T.BMMC=(SELECT DEP_PARENTID FROM V_QJBM F WHERE F.DEPTID=T.BMMC) WHERE T.BMMC IN (SELECT DEPTID FROM V_QJBM);
  COMMIT;
  UPDATE T_NJ_SGK_XZXK3 T SET T.BMMC=(SELECT DEP_PARENTID FROM V_QJBM F WHERE F.DEPTID=T.BMMC) WHERE T.BMMC IN (SELECT DEPTID FROM V_QJBM);
  COMMIT;
  UPDATE T_NJ_SGK_GRXZXK3 T SET T.BMMC=(SELECT DEP_PARENTID FROM V_QJBM F WHERE F.DEPTID=T.BMMC) WHERE T.BMMC IN (SELECT DEPTID FROM V_QJBM);
  COMMIT;
end P_SGS_UPDATEGS;
/
