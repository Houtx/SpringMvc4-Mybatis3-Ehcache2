CREATE procedure P_SGS_TRANSFERDATA is
begin
  --XZCF
  INSERT INTO MID_NANJING.L_NANJING_XZCF@JSDB(cf_wsh,cf_cfmc, cf_bm, cf_cflb1,cf_cflb2, cf_sy, cf_yj, cf_xdr_mc, cf_xdr_shxym,cf_xdr_gsdj, cf_xdr_zdm, cf_xdr_sfz, cf_fr, cf_jg, cf_jdrq, cf_xzjg, cf_zt, dfbm, sjc, bz, cf_syfw, cf_sxyzcd, cf_gsjzq)
  SELECT cfwh, ajmc,qlbm, cfLB1,cflb2, cfsy, cfyj, qymc, shxydm,qyzch, zzjgdm,dbrsfzhm, fddbrxm,cfjg, cfrq,cfjgmc,ZT,xzqh, SJC,bz,syfw, sxyzcd, gsjzq FROM T_NJ_SGK_CFXX2 T WHERE T.CLSJ IS NULL;
  COMMIT;
  UPDATE T_NJ_SGK_CFXX2 T SET T.CLSJ=SYSDATE WHERE T.CLSJ IS NULL;
  COMMIT;
  INSERT INTO MID_NANJING.L_NANJING_XZCF@JSDB(cf_wsh,cf_cfmc, cf_bm, cf_cflb1,cf_cflb2 ,cf_sy, cf_yj, cf_xdr_mc, cf_xdr_sfz, cf_jg, cf_jdrq, cf_xzjg, cf_zt, dfbm, sjc, bz, cf_syfw, cf_sxyzcd, cf_gsjzq)
  SELECT cfwh, ajmc,qlbm, cfLB1,cflb2, cfsy, cfyj, XM, SFZJHM, cfjg, cfrq,cfjgmc,ZT,xzqh, SJC,bz,syfw, sxyzcd, gsjzq FROM T_NJ_SGK_GRCFXX2 T WHERE T.CLSJ IS NULL;
  COMMIT;
  UPDATE T_NJ_SGK_GRCFXX2 T SET T.CLSJ=SYSDATE WHERE T.CLSJ IS NULL;
  COMMIT;
  --XZXK
  INSERT INTO MID_NANJING.L_NANJING_XZXK@JSDB(xk_wsh,xk_xmmc, xk_bm, xk_splb, xk_nr, xk_xdr, xk_xdr_shxym,xk_xdr_gsdj, xk_xdr_zdm, xk_xdr_sfz, xk_fr, xk_jdrq, xk_jzq, xk_xzjg, xk_zt, dfbm, sjc, bz, xk_syfw)
  SELECT xkwh, xmmc, qlbm, splb, xknr, qymc, shxydm,qyzch, zzjgdm,dbrsfzhm,fddbrxm,  xkrq, xkyxq, xkjg,zt,xzqh,sjc,bz,syfw from T_NJ_SGK_XZXK2 T WHERE T.CLSJ IS NULL;
  COMMIT;
  UPDATE T_NJ_SGK_XZXK2 T SET T.CLSJ=SYSDATE WHERE T.CLSJ IS NULL;
  COMMIT;
  INSERT INTO MID_NANJING.L_NANJING_XZXK@JSDB(xk_wsh,xk_xmmc, xk_bm, xk_splb, xk_nr, xk_xdr, xk_xdr_sfz, xk_jdrq, xk_jzq, xk_xzjg, xk_zt, dfbm, sjc, bz, xk_syfw)
  SELECT xkwh, xmmc, qlbm, splb, xknr, XM, SFZJHM,  xkrq, xkyxq, xkjg,zt,xzqh,sjc,bz,syfw from T_NJ_SGK_GRXZXK2 T WHERE T.CLSJ IS NULL;
  COMMIT;
  UPDATE T_NJ_SGK_GRXZXK2 T SET T.CLSJ=SYSDATE WHERE T.CLSJ IS NULL;
  COMMIT;
end P_SGS_TRANSFERDATA;
/
