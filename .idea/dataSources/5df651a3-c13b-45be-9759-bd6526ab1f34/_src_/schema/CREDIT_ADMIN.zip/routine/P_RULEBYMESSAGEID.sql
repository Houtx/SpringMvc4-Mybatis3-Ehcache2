CREATE procedure              p_ruleByMessageId(p_messageid in varchar2) is

       Cursor cur_messageid is   --定义游标
             select T.MESSAGEID,T.FILEID from t_sys_datafileinfo t where t.MESSAGEID=p_messageid AND t.cleaned='Y';

       row_messageid  cur_messageid%Rowtype; --声明行变量
       v_fileid varchar2(1000) :='';
       v_messageid varchar2(1000) :='';
       p_reten integer:=-1;
begin

      --delete t_rpt_ruledatacheckstatics ; -- 执行存储过程之前清空 t_rpt_ruledatacheckstatics 表
      --commit;

      open cur_messageid;
          Loop
             Fetch cur_messageid
                Into row_messageid;
             exit when cur_messageid%notfound;
                 v_fileid :=row_messageid.fileid;
                 v_messageid := row_messageid.messageid;

       p_rule_statistics(v_fileid,v_messageid,p_reten); --调用存储过程

       end loop;
       close cur_messageid; --关闭游标


end ;

/
