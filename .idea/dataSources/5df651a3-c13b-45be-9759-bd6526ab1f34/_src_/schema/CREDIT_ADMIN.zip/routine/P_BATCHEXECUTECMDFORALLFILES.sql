CREATE procedure              p_BatchExecuteCMDForAllFiles(p_commandType in VARCHAR2,result out integer ) is
/**
批量添加处理命令,相同的命令
需要说明的是，该过程不会对数据文件的处理状态进行检查，使用的时候要注意
* p_commandType 命令类型:
* 解析入库 JXRK
* 增量检查 ZLJC
* 规则检查 GZJC
* 关联比对 GLBD
* 数据同步 SJTB
* 解析入库回退 JXRKHT
* 增量检查回退 ZLJCHT
* 规则检查回退 GZJCHT
* 关联比对回退 GLBDHT
* 数据同步回退 SJTBHT
* 重新关联 CXGL
* 推送处理结果到前置机 TSCLJG
*
*
**/
       Cursor cur_datafilegroups is   --定义游标
            SELECT *  FROM t_sys_datafilegroups tsd  WHERE tsd.grouptype = 'DATA'
            AND tsd.isparsed <> 'D'
            and tsd.finished='Y'
            ORDER BY tsd.recvtime ASC;
       v_cmdname VARCHAR2(100);---命令名称
       --p_reten integer:=-1;
begin
    begin
    IF(p_commandType='JXRK') THEN
    	v_cmdname:='解析入库';
    ELSIF(p_commandType='ZLJC') THEN
    	v_cmdname:='增量检查';
    ELSIF (p_commandType='GZJC') THEN
    			v_cmdname:='规则检查';
    ELSIF (p_commandType='GLBD') THEN
    			v_cmdname:='关联比对';
    ELSIF (p_commandType='SJTB') THEN
    			v_cmdname:='数据同步';
    ELSIF (p_commandType='JXRKHT') THEN
    			v_cmdname:='解析入库回退';
    ELSIF (p_commandType='ZLJCHT') THEN
    			v_cmdname:='增量检查回退';
    ELSIF (p_commandType='GZJCHT') THEN
    			v_cmdname:='规则检查回退';
    ELSIF (p_commandType='GLBDHT') THEN
    			v_cmdname:='关联比对回退';
    ELSIF (p_commandType='SJTBHT') THEN
    			v_cmdname:='数据同步回退';
    ELSIF(p_commandType='CXGL') THEN
    			v_cmdname:='重新关联';
    ELSIF(p_commandType='TSCLJG') THEN

    			v_cmdname:='推送处理结果到前置机';
    ELSE
    	 RAISE_APPLICATION_ERROR(-20001,'命令类型不正确');
    end if;

    FOR rd IN cur_datafilegroups LOOP
    	BEGIN


    		insert into T_SYS_PROCESSCOMMAND
          (
             CMDID
            ,FILEGROUPID
            ,USERID
            ,CMDCODE
            ,CMD
            ,CMDTIME
            ,RUNSTATE
          )
          values
          (
            S_CENTER_DATAPROCESS.NEXTVAL
            ,rd.filegroupid
            ,'admin'
            ,p_commandType
            ,v_cmdname
            ,SYSDATE
            ,'0'
          );
          COMMIT;

       exception
        when no_data_found then
             result := 1;

         when others then
          --dbms_output.put_line(SQLERRM);
          --Raise SQLERRM;
          raise_application_error(-20000,SQLERRM);
           result :=-1;
          end;
    END LOOP;
    result := 1;
    end;
 exception
 when others then
    result := -1;
end;

/
