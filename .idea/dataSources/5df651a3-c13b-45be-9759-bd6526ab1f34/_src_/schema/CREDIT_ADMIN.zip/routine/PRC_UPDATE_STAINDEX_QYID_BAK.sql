CREATE procedure              prc_update_staindex_qyid_bak(v_qyid number) is
  temptabtype      varchar(50);
  tempparentid     varchar(50);
  tempdept         varchar(50);
  tempdeptname     varchar(50);
  temptablename    varchar(50);
  tablemessagename varchar(255);
  temporderid      varchar2(10);
  tempmessageid    varchar2(50);
  tempdeptabbr     varchar2(200);
  sqlstr           varchar(4000);

  CURSOR cur is
    select b.deptid,
           b.deptabbr,
           b.deptname,
           a.tablename,
           a.tabletype,
           c.parentid,
           a.messagename,
           a.messageid,
           b.pageorder
      from t_meta_table a, t_sys_department b, t_dict_tabletype c
     where a.isuse = 'Y'
       and a.tabletype = c.code
       and a.domainid like '001%'
       and a.deptid = b.deptabbr
       and a.isuse = 'Y'
     group by b.deptid,
              b.deptabbr,
              b.deptname,
              a.tablename,
              a.tabletype,
              c.parentid,
              a.messagename,
              a.messageid,
              b.pageorder
     order by b.pageorder, a.tabletype;
begin
  delete from T_STA_TABLEINDEX where qyid = v_qyid;
  dbms_output.put_line('delete from T_STA_TABLEINDEX where qyid = ' ||
                       v_qyid);
  open cur;
  loop
    fetch cur
      into tempdept,
           tempdeptabbr,
           tempdeptname,
           temptablename,
           temptabtype,
           tempparentid,
           tablemessagename,
           tempmessageid,
           temporderid;

    sqlstr := 'insert into T_STA_TABLEINDEX(orderid,deptid,deptabbr,deptname,tablename,tabletype,parentid,tablemessagename,tablemessageid,counts,qyid,recid)' ||
              ' select ''' || temporderid || ''',''' || tempdept || ''',''' ||
              tempdeptabbr || ''',''' || tempdeptname || ''',''' ||
              temptablename || ''',''' || temptabtype || ''',''' ||
              tempparentid || ''',''' || tablemessagename || ''',''' ||
              tempmessageid || ''',1, qyid,recid  from ' || temptablename ||
              ' where qyid = ' || v_qyid;

    --dbms_output.put_line(temptablename);
    --dbms_output.put_line(sqlstr);
    execute immediate sqlstr;
  end loop;
  dbms_output.put_line('OK');
end prc_update_staindex_qyid_bak;

/
