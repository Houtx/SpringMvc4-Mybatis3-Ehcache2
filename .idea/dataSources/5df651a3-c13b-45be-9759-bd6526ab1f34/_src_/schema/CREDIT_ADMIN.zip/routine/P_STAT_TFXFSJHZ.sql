CREATE procedure              P_STAT_TFXFSJHZ IS
  /**
  停发或修复数据提示统计函数
  pPushDeptid:要推送的部门
  pMessageid:要统计的信息类
  **/
  --推送的数据汇总
  CURSOR cur_pushDataSum IS
    SELECT DEPTID_FRONT,
           DEPTID,
           MESSAGEID,
           TABLENAME_CENTER,
           SUM(累次推送记录数) AS PushCounts
      FROM CREDIT_PUSH.V_RPT_FILE T
     WHERE 累次推送记录数 > 0
     GROUP BY DEPTID_FRONT, DEPTID, MESSAGEID, TABLENAME_CENTER;
  CURSOR cur_xyxxxf(p_messageid varchar2) IS
    select tr.recid,
           td.deptabbr,
           td.deptname,
           tt.messageid,
           tt.messagename,
           tr.fileid,
           decode(tr.optype, 'TZ', 'XYXF', 'TF', 'XYTF') optype
      from T_DATA_REPAIR        tr,
           T_SYS_DATAFILEGROUPS tsd,
           t_sys_department     td,
           t_meta_table         tt
where tr.fileid = tsd.fileid
       and tsd.uploaddeptid = td.deptabbr
       and tsd.messageid = tt.messageid
       and tt.messageid = p_messageid;

  CURSOR cur_yyxx(p_messageid varchar2) IS
    select *
      from t_datapause td
     where td.messageid = p_messageid
       and td.mark != 'XYTF';

   CURSOR cur_yyxf(p_messageid varchar2) IS
    select * from t_cms_demurral_updatelog  td
     where td.messageid = p_messageid;


  V_XYTF_COUNTS T_RPT_TFXFSJHZ.XYTF_COUNTS%TYPE := 0; --信用停发记录数
  V_YYTF_COUNTS T_RPT_TFXFSJHZ.YYTF_COUNTS%TYPE := 0; --异议停发记录数
  V_XYXF_COUNTS T_RPT_TFXFSJHZ.XYXF_COUNTS%TYPE := 0; --信用修复记录数
  V_YYXF_COUNTS T_RPT_TFXFSJHZ.XYTF_COUNTS%TYPE := 0; --异议修复记录数
  V_PUSHTIME T_DATA_TFXFSJHZ.PUSHTIME% TYPE:='';----推送时间

  V_DEPTID    T_RPT_TFXFSJHZ.DEPTID%TYPE; ---推送部门
  V_SRCDEPTID T_RPT_TFXFSJHZ.SRCDEPTID%TYPE; ---来源部门
  V_MESSGEID  T_RPT_TFXFSJHZ.MESSAGEID%TYPE; ---信息类
  V_TS_COUNTS T_RPT_TFXFSJHZ.TS_COUNTS%TYPE; ---推送记录数

  V_RECID          T_DATA_TFXFSJHZ.RECID%TYPE; --记录数ID
  V_FILEID         T_DATA_TFXFSJHZ.FILEID%TYPE; --记录文件ID
  V_QYMC           T_DATA_TFXFSJHZ.QYMC%TYPE := '';
  V_QYZCH          T_DATA_TFXFSJHZ.QYZCH%TYPE := '';
  V_ZZJGDM         T_DATA_TFXFSJHZ.ZZJGDM%TYPE := '';
  V_LINENUMBER     T_DATA_TFXFSJHZ.LINENUMBER%TYPE;
  V_RECTYPE        T_DATA_TFXFSJHZ.RECTYPE%TYPE;
  V_DATA_TS_COUNTS T_DATA_TFXFSJHZ.TS_COUNTS%TYPE;
  V_PUSHDATE       T_DATA_TFXFSJHZ.PUSHTIME%TYPE;
  V_CENTERTABLE    varchar2(50);
  V_ISPUSH         integer;
  V_SQL            varchar2(4000);
  V_USE_QYMC       varchar2(50):=1;
  V_USE_QYZCH      varchar2(50):=1;
  V_USE_ZZJGDM     varchar2(50):=1;
  V_EXIST INTEGER:=0;

BEGIN
  delete from T_DATA_TFXFSJHZ;
  commit;
  delete from T_RPT_TFXFSJHZ;
  commit;
  for rd IN cur_pushDataSum LOOP
    V_DEPTID    := rd.DEPTID_FRONT;
    V_SRCDEPTID := rd.DEPTID;
    V_MESSGEID  := rd.MESSAGEID;
    V_TS_COUNTS := rd.PushCounts;
    select t.tablename_center
      into V_CENTERTABLE
      from credit_push.r_meta_table t
     where t.deptid_front = V_DEPTID
       and t.messageid = V_MESSGEID;
     ----
     /* V_SQL := 'select count(*) from credit_push.r_meta_column where DEPTID_FRONT=:DEPTID_FRONT and MESSAGEID=:MESSAGEID AND COLUMNNAME=:COLUMNNAME';
      execute immediate V_SQL
        into V_USE_QYMC
        using V_DEPTID, V_MESSGEID, 'QYMC';
      execute immediate V_SQL
        into V_USE_QYZCH
        using V_DEPTID, V_MESSGEID, 'QYZCH';
      execute immediate V_SQL
        into V_USE_ZZJGDM
        using V_DEPTID, V_MESSGEID, 'ZZJGDM';*/
    for rd IN cur_xyxxxf(V_MESSGEID) LOOP
      V_RECID := rd.recid;
      V_SQL   := 'select count(*) from credit_push.' || V_CENTERTABLE ||
                 ' where recid=:recid ';
      execute immediate V_SQL
        into V_ISPUSH
        using V_RECID;


      if (V_ISPUSH > 0) then
        V_FILEID  := rd.fileid;
        V_RECTYPE := rd.optype;
        if (V_USE_QYMC > 0) then
          V_SQL := 'select qymc from credit_push.' || V_CENTERTABLE ||
                   ' where recid=:recid ';
          execute immediate V_SQL
            into V_QYMC
            using V_RECID;
        end if;
        if (V_USE_QYZCH > 0) then
          V_SQL := 'select qyzch from credit_push.' || V_CENTERTABLE ||
                   ' where recid=:recid ';
          execute immediate V_SQL
            into V_QYZCH
            using V_RECID;
        end if;
        if (V_USE_ZZJGDM > 0) then
          V_SQL := 'select zzjgdm from credit_push.' || V_CENTERTABLE ||
                   ' where recid=:recid ';
          execute immediate V_SQL
            into V_ZZJGDM
            using V_RECID;
        end if;
        select td.linenum
          into V_LINENUMBER
          from t_dataprocess td
         where td.recid = V_RECID;

         select count(*) into V_EXIST  from credit_push.r_sys_file t where t.datasetid=V_RECID;
         if V_EXIST>0 then
         select t.sendtime into V_PUSHTIME from credit_push.r_sys_file t where t.datasetid=V_RECID;
         end if;
        insert into T_DATA_TFXFSJHZ
        values
          (V_DEPTID,
           V_SRCDEPTID,
           V_MESSGEID,
           V_FILEID,
           V_RECID,
           V_QYMC,
           V_QYZCH,
           V_ZZJGDM,
           V_LINENUMBER,
           V_RECTYPE,
           V_ISPUSH,
           sysdate,
           'Y',
           V_PUSHTIME);
        commit;
      end if;
    end loop;

    for rd IN cur_yyxx(V_MESSGEID) LOOP
      V_RECID := rd.recid;
      V_SQL   := 'select count(*) from credit_push.' || V_CENTERTABLE ||
                 ' where recid=:recid ';
      execute immediate V_SQL
        into V_ISPUSH
        using V_RECID;
      if (V_ISPUSH > 0) then
        V_RECTYPE := rd.mark;
        if (V_USE_QYMC > 0) then
          V_SQL := 'select qymc from credit_push.' || V_CENTERTABLE ||
                   ' where recid=:recid ';
          execute immediate V_SQL
            into V_QYMC
            using V_RECID;
        end if;
        if (V_USE_QYZCH > 0) then
          V_SQL := 'select qyzch from credit_push.' || V_CENTERTABLE ||
                   ' where recid=:recid ';
          execute immediate V_SQL
            into V_QYZCH
            using V_RECID;
        end if;
        if (V_USE_ZZJGDM > 0) then
          V_SQL := 'select zzjgdm from credit_push.' || V_CENTERTABLE ||
                   ' where recid=:recid ';
          execute immediate V_SQL
            into V_ZZJGDM
            using V_RECID;
        end if;
        select td.fileid
          into V_FILEID
          from t_dataprocess td
         where td.recid = V_RECID;
        select td.linenum
          into V_LINENUMBER
          from t_dataprocess td
         where td.recid = V_RECID;
          select count(*) into V_EXIST  from credit_push.r_sys_file t where t.datasetid=V_RECID;
         if V_EXIST>0 then
         select t.sendtime into V_PUSHTIME from credit_push.r_sys_file t where t.datasetid=V_RECID;
         end if;
        insert into T_DATA_TFXFSJHZ
        values
          (V_DEPTID,
           V_SRCDEPTID,
           V_MESSGEID,
           V_FILEID,
           V_RECID,
           V_QYMC,
           V_QYZCH,
           V_ZZJGDM,
           V_LINENUMBER,
           V_RECTYPE,
           V_ISPUSH,
           sysdate,
           'Y',
           V_PUSHTIME);
        commit;
      end if;
    end loop;

--异议修复

 for rd IN cur_yyxf(V_MESSGEID) LOOP
      V_RECID := rd.recid;
      V_SQL   := 'select count(*) from credit_push.' || V_CENTERTABLE ||
                 ' where recid=:recid ';
      execute immediate V_SQL
        into V_ISPUSH
        using V_RECID;
      if (V_ISPUSH > 0) then
        V_RECTYPE :='YYXF';
        if (V_USE_QYMC > 0) then
          V_SQL := 'select qymc from credit_push.' || V_CENTERTABLE ||
                   ' where recid=:recid ';
          execute immediate V_SQL
            into V_QYMC
            using V_RECID;
        end if;
        if (V_USE_QYZCH > 0) then
          V_SQL := 'select qyzch from credit_push.' || V_CENTERTABLE ||
                   ' where recid=:recid ';
          execute immediate V_SQL
            into V_QYZCH
            using V_RECID;
        end if;
        if (V_USE_ZZJGDM > 0) then
          V_SQL := 'select zzjgdm from credit_push.' || V_CENTERTABLE ||
                   ' where recid=:recid ';
          execute immediate V_SQL
            into V_ZZJGDM
            using V_RECID;
        end if;
        select td.fileid
          into V_FILEID
          from t_dataprocess td
         where td.recid = V_RECID;
        select td.linenum
          into V_LINENUMBER
          from t_dataprocess td
         where td.recid = V_RECID;
          select count(*) into V_EXIST  from credit_push.r_sys_file t where t.datasetid=V_RECID;
         if V_EXIST>0 then
         select t.sendtime into V_PUSHTIME from credit_push.r_sys_file t where t.datasetid=V_RECID;
         end if;
        insert into T_DATA_TFXFSJHZ
        values
          (V_DEPTID,
           V_SRCDEPTID,
           V_MESSGEID,
           V_FILEID,
           V_RECID,
           V_QYMC,
           V_QYZCH,
           V_ZZJGDM,
           V_LINENUMBER,
           V_RECTYPE,
           V_ISPUSH,
           sysdate,
           'Y',
           V_PUSHTIME);
        commit;
      end if;
    end loop;

    select count(*)
      into V_XYTF_COUNTS
      from T_DATA_TFXFSJHZ t
     where t.rectype = 'XYTF'
       and t.messageid = V_MESSGEID
       and t.deptid = V_DEPTID;
    select count(*)
      into V_XYXF_COUNTS
      from T_DATA_TFXFSJHZ t
     where t.rectype = 'XYXF'
       and t.messageid = V_MESSGEID
       and t.deptid = V_DEPTID;
    select count(*)
      into V_YYTF_COUNTS
      from T_DATA_TFXFSJHZ t
     where T.rectype = 'YYTF'
       and t.messageid = V_MESSGEID
       and t.deptid = V_DEPTID;
    select count(*)
      into V_YYXF_COUNTS
      from T_DATA_TFXFSJHZ t
     where T.rectype = 'YYXF'
       and t.messageid = V_MESSGEID
       and t.deptid = V_DEPTID;
    if (V_XYTF_COUNTS > 0 or V_XYXF_COUNTS > 0 or V_YYTF_COUNTS > 0 or
       V_YYXF_COUNTS > 0) then
      INSERT INTO T_RPT_TFXFSJHZ
      values
        (V_DEPTID,
         V_MESSGEID,
         V_SRCDEPTID,
         V_TS_COUNTS,
         V_XYTF_COUNTS,
         V_YYTF_COUNTS,
         V_XYXF_COUNTS,
         V_YYXF_COUNTS,
         'N',
         SYSDATE);
      commit;

      INSERT INTO T_LOG_TFXFSJRZ
      values
        (sys_guid(),
         V_DEPTID,
         V_MESSGEID,
         V_SRCDEPTID,
         V_TS_COUNTS,
         '',
         'Y',
         SYSDATE,
         SYSDATE);
      commit;
    end if;
  end loop;

  update T_RPT_TFXFSJHZ t set t.ISCREATE = 'N';
  commit;
  update T_DATA_TFXFSJHZ t set t.ISPUSH = 'N';
  commit;

end P_STAT_TFXFSJHZ;

/
