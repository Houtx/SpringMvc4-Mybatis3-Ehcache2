CREATE procedure PRC_YWGL_ADDASSOPARA is
begin
  insert into t_meta_assopara
    select messageid,
           tablename,
           2,
           null,
           'CREATETIME_DEPT',
           tablename || '_FMT',
           tablename,
           tablename || '_HIS',
           'Y',
           9999,
           case
             when (select count(*)
                     from t_meta_column c
                    where c.messageid = t.messageid
                      and c.columnname in ('ZZJGDM', 'QYMC', 'QYZCH')) = 3 then
              '111;110;011;010'
             else
              (case
             when exists (select *
                     from t_meta_column c
                    where c.messageid = t.messageid
                      and c.columnname = 'QYMC') then
              '010'
             else
              'N/A'
           end) end,
           999,
           sysdate,
           null
      from t_meta_table t
     where messageid not in (select messageid from t_meta_assopara)
       and isuse = 'Y';

  commit;
end PRC_YWGL_ADDASSOPARA;

/
