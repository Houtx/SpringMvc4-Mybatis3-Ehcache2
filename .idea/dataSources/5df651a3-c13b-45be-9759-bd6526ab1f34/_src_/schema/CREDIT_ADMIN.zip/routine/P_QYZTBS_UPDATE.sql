CREATE procedure P_QYZTBS_UPDATE is
begin
  --更新主体标识表中相关工商来源的数据
  --更新个体的主体标识信息
  update t_qyztbs t
   set (t.qymc, t.qyzch, t.zchrecid,t.fddbr,t.hymc,t.updatetime) = (select qymc, qyzch, recid,fddbrxm,TRADE_NAME,sysdate
                                          from t_sx_jgdjxx f
                                         where f.qyid = t.qyid
                                           and f.hzrq =
                                               (select max(hzrq)
                                                  from t_sx_jgdjxx m
                                                 where m.qyid = f.qyid)
                                         and rownum = 1)
 where t.sjly='2';
 commit;
 --更新企业的主体标识信息
 update t_qyztbs t
   set (t.qymc, t.qyzch, t.zchrecid,t.fddbr,t.hymc,t.updatetime) = (select qymc, qyzch, recid,fddbrxm,TRADE_NAME,sysdate
                                          from t_sx_jgdjxx f
                                         where f.qyid = t.qyid
                                           and f.hzrq =
                                               (select max(hzrq)
                                                  from t_sx_jgdjxx m
                                                 where m.qyid = f.qyid)
                                         and rownum = 1)
 where t.sjly='1';
 commit;
 --根据行业名称回填相关行业代码、大类、种类、小类
 
 --TODO:从南京市工商提供的行政许可中提取相关数据
 
end P_QYZTBS_UPDATE;
/
