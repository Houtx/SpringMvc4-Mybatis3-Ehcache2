CREATE procedure              prc_add_joblog(pname VARCHAR2, pdesc VARCHAR2) is
begin
  insert into t_log_joblog (LOGPROG, LOGDESC, LOGID) values (pname, pdesc, SEQ_LOGID_KEY.NEXTVAL);
end prc_add_joblog;

/
