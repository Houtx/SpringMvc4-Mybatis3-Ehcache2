CREATE procedure              PRC_TEST_CREATEMV is
begin
  execute immediate 'create materialized view MV_QYZTBS_ZZJGDM_SJLY_QYZT as select sjly,  decode(sjly, ''1'', ''企业'', ''2'', ''个体'', ''3'', ''民办非企业'', ''4'', ''社团'', NULL) sjlymc, qyzt, tablename "ZZJGDM来源", decode(qyzt, ''01'', ''在业'', ''03'', ''注销'', ''04'', ''吊销'', NULL) qyztmc, cnt from (select sjly, tablename, qyzt, count(*) cnt from t_meta_table t, t_dataprocess dp, t_qyztbs q where t.messageid = dp.messageid and dp.recid = q.zzjgdmrecid and q.zzjgdm is not null group by sjly, tablename, qyzt) d';
end PRC_TEST_CREATEMV;

/
