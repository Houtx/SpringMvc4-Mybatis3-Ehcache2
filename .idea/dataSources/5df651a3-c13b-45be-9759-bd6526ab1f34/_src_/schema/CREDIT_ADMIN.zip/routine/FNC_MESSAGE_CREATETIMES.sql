CREATE function              fnc_message_createtimes(f_i_messageid in varchar2)
RETURN varchar2 IS
  --Project:江苏征信
  --Author：毛锋
  --Create Date：2010-09-03
  --Last Modified： 2010-09-03
  --Description：用于生成信息类最后更新时间
  --Module：WEB服务端部门归集数据信息类最后更新时间
var_createtime   varchar2(4000):='';
var_sql     varchar2(4000);
begin
  var_sql:='select to_date(max(createtime)) from t_sys_datafileinfo a where   a.messageid='''||f_i_messageid||''' ';
  execute immediate var_sql into var_createtime;
     return var_createtime;
end fnc_message_createtimes;

/
