CREATE procedure              P_DEL_ERRDATA_FROMZX(p_fileid in varchar2,p_messageid in varchar2) is
       p_tablename  varchar2(50);
       t_sql  varchar2(1000):= '';
       --type p_recid is table of varchar2(50) index by binary_integer;
       --var_recid p_recid;

begin

      select t.tablename into p_tablename from t_meta_table t where t.messageid= p_messageid and rownum=1 ;

      --t_sql := ('select t.recid  from CREDIT_GATHER.t_dataprocess t,CREDIT_GATHER.' || p_tablename || ' a where t.messageid = '''|| p_messageid||''' and t.fileid = '''|| p_fileid ||''' and a.recid = t.recid');
      --execute immediate t_sql bulk collect into var_recid;

      delete credit_center.T_RPT_CDATACHECK where FILEID = p_fileid AND MESSAGEID = p_messageid;
      delete credit_center.T_RPT_CDATACHECKQRECORD where FILEID = p_fileid AND MESSAGEID = p_messageid;
      delete credit_center.t_rpt_cincrementdatacheck where recordfileid = p_fileid AND MESSAGEID = p_messageid;

      delete credit_center.T_SYS_DATAFILEINFO where FILEID = p_fileid AND MESSAGEID = p_messageid;
      delete credit_center.t_rpt_associateqrecord where recordfileid = p_fileid ;
      delete credit_center.t_rpt_associatestatistics where recordfileid = p_fileid ;

      delete t_filesarchive t where t.filecode = p_fileid;

      delete credit_center.t_rpt_frontprocess t where t.processid = p_fileid and t.messageid = p_messageid;

      if p_tablename is not null then
         t_sql := ('delete credit_product.'|| p_tablename ||' t where t.recid in (select t.recid  from CREDIT_center.t_dataprocess t,CREDIT_product.' || p_tablename || ' a where t.messageid = '''|| p_messageid||''' and t.fileid = '''|| p_fileid ||''' and a.recid = t.recid)');
         execute immediate t_sql;
         t_sql :=('delete credit_product.'|| p_tablename||'_HIS  t where t.recid in (select t.recid  from CREDIT_center.t_dataprocess t,CREDIT_product.' || p_tablename || '_his a where t.messageid = '''|| p_messageid||''' and t.fileid = '''|| p_fileid ||''' and a.recid = t.recid)');
         execute immediate t_sql;
         t_sql := ('delete credit_gather.'|| p_tablename ||' t where t.recid in (select t.recid  from CREDIT_center.t_dataprocess t,CREDIT_GATHER.' || p_tablename || ' a where t.messageid = '''|| p_messageid||''' and t.fileid = '''|| p_fileid ||''' and a.recid = t.recid)');
         execute immediate t_sql;
         t_sql :=('delete credit_center.'|| p_tablename||'_FMT  t where t.recid in  (select t.recid  from CREDIT_center.t_dataprocess t,CREDIT_center.' || p_tablename || '_fmt a where t.messageid = '''|| p_messageid||''' and t.fileid = '''|| p_fileid ||''' and a.recid = t.recid)');
         execute immediate t_sql;

      end if;
       -- t_sql :='delete from credit_gather.t_dataprocess t where t.messageid = '''||p_messageid||''' and exists (select recid from credit_gather.'||p_tablename||' a where t.recid=a.recid and t.fileid = '''||p_fileid ||''')';
       t_sql :='delete from credit_gather.t_dataprocess t where T.MESSAGEID = '''||p_messageid||''' and t.fileid = '''||p_fileid || '''';
       execute immediate t_sql;
       commit;

end ;

/
