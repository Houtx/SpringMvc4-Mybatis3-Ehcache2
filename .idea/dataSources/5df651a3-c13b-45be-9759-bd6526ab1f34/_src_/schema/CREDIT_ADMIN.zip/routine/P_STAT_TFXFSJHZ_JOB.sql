CREATE procedure              p_stat_tfxfsjhz_job(RESULT OUT VARCHAR2) IS

  /**定时执行数据项处理情况统计
  **/
  V_JOBID T_META_PROCEDURE.JOBID%TYPE; --创建JOB时指定的JOBID
  V_SQL   VARCHAR2(1000);

BEGIN
  V_SQL := 'begin
         sys.dbms_job.submit(:jobid,
                        what => ''begin p_stat_tfxfsjhz; end;'',
                       next_date =>SYSDATE
                       );
         commit;
         end;';
  EXECUTE IMMEDIATE V_SQL
    USING OUT V_JOBID;
  COMMIT;
    RESULT:=V_JOBID;
end p_stat_tfxfsjhz_job;

/
