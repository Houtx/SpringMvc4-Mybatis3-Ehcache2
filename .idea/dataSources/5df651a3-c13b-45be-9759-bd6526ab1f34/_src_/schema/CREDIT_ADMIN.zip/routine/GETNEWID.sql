CREATE function GetNewID(p_OldID varchar2) return varchar2 is
  -- Author  : XJG(xjg@netsky-tech.com)
  -- Created : 2003-11-03 18:38:56
  -- Purpose : 从原有的15位身份证号转换成新的18位（附PASCAL代码）
  type TIArray is table of integer;
  type TCArray is table of char(1);
  Result varchar2(18);
  W      TIArray;
  A      TCArray;
  S      integer;
begin
  if Length(p_OldID) <> 15 then
    --raise_application_error(-20999, '不是旧15位身份证号');
    result:=null;
  end if;
  W      := TIArray(7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2, 1);
  A      := TCArray('1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2');
  Result := SubStr(p_OldID, 1, 6) || '19' || SubStr(p_OldID, 7, 9);

  S := 0;
  begin
    for i in 1 .. 17 loop
      S := S + to_number(SubStr(Result, i, 1)) * W(i);
    end loop;
  exception
    when others then
      return '';
  end;
  S      := S mod 11;
  Result := Result || A(s + 1);

  return(Result);
end GetNewID;
/
