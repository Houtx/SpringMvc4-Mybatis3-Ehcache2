CREATE procedure              prc_all_gather_num is
      -- 根据T_META_TABLE
      Cursor cur_main Is
        select b.deptid, b.deptname, b.deptabbr, a.tablename, a.messagename from T_META_TABLE a,T_SYS_DEPARTMENT b
              where a.deptid = b.deptabbr
              order by b.deptid, a.tablename;

       row_main            cur_main%Rowtype;
       v_deptid           varchar2(100) := '';
       v_deptname         varchar2(100) := '';
       v_deptabbr         varchar2(100) := '';
       v_deptabbr_old     varchar2(100) := '';
       v_tablename         varchar2(100) := '';
       v_messagename       varchar2(100) := '';

       v_countnum_gather       number := 0;
       v_countnum_cur         number := 0;
       i                       number := 1;
       j                       number := 0;
       table_num              number := 0;
       record_dept_num        number := 0;
       record_all_num          number := 0;

       v_sql_gather        varchar2(100) := '';
       v_sql_cur           varchar2(100) := '';
begin
    dbms_output.put_line('Schema: credit_gather');

    open cur_main;
     Loop
         Fetch cur_main
          Into row_main;

      Exit When cur_main%Notfound;
           v_deptid := row_main.deptid;
           v_deptabbr := row_main.deptabbr;
           v_deptname := row_main.deptname;

           --dbms_output.put_line(v_deptabbr);
           --dbms_output.put_line(v_deptabbr_old);
           if ( isequal(v_deptabbr_old , v_deptabbr) = 0) then
               v_sql_gather := 'select count(1) from T_META_TABLE where deptid =' || '''' || v_deptabbr || '''';
                 execute immediate v_sql_gather
                 into v_countnum_gather;

               dbms_output.put_line(i || '*****' || v_deptname || '(' || v_deptid || ')' || '********** 归集信息类数目：' || v_countnum_gather);
               v_deptabbr_old := v_deptabbr;
               i := i + 1;
           end if;

           v_tablename:= row_main.tablename;
           v_messagename := row_main.messagename;

           dbms_output.put_line('     -----' || v_tablename || '(' || v_messagename || ')' );

           v_sql_cur  := 'select count(1) from credit_gather.' || v_tablename;
               execute immediate v_sql_cur
               into v_countnum_cur;
           if v_countnum_cur > 0 then
               dbms_output.put_line('          -----' || v_tablename || '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~记录数:' || v_countnum_cur );
           else
               dbms_output.put_line('          -----' || v_tablename || '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~' || v_countnum_cur);
           end if;
            record_dept_num := record_dept_num + v_countnum_cur ;

           j := j + 1 ;
           table_num := table_num + 1 ;
           if ( v_countnum_gather = j) then
                dbms_output.put_line('     $$$$$' || v_deptname || '(' || v_deptid || ')' || '~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~部门总记录数:' || record_dept_num);
                record_all_num := record_all_num + record_dept_num;
                record_dept_num := 0;
                j := 0;
           end if;
      end Loop;

      dbms_output.put_line('credit_gather涉及数据表的总数为：' || table_num || '~~~~~~~~~~~~~~~~~~credit_gather总记录数:' || record_all_num);

      commit;
      exception
    when others then
      rollback;
      raise;

end prc_all_gather_num;

/
