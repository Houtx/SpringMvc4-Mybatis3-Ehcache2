CREATE procedure P_UPDATEQYJBXX(QYID IN INTEGER) is
  V_QYID      CREDIT_QYJBXX.T_QYJBXX.QYID%TYPE;
  V_QYLXMC         CREDIT_QYJBXX.T_QYJBXX.QYLXMC%TYPE;
  V_QYLXMC_SRC     CREDIT_QYJBXX.T_QYJBXX.QYLXMC_SRC%TYPE;
  V_FDDBRXM        CREDIT_QYJBXX.T_QYJBXX.FDDBRXM%TYPE;
  V_FDDBRZW        CREDIT_QYJBXX.T_QYJBXX.FDDBRZW%TYPE;
  V_ZCZJ           CREDIT_QYJBXX.T_QYJBXX.ZCZJ%TYPE;
  V_ZCBZ           CREDIT_QYJBXX.T_QYJBXX.ZCBZ%TYPE;
  V_ZCZJ_RMB       CREDIT_QYJBXX.T_QYJBXX.ZCZJ_RMB%TYPE;
  V_ZCBZ_SRC       CREDIT_QYJBXX.T_QYJBXX.ZCBZ_SRC%TYPE;
  V_JYFW           CREDIT_QYJBXX.T_QYJBXX.JYFW%TYPE;
  V_JYFW_SRC       CREDIT_QYJBXX.T_QYJBXX.JYFW_SRC%TYPE;
  V_ZS             CREDIT_QYJBXX.T_QYJBXX.ZS%TYPE;
  V_LXDH           CREDIT_QYJBXX.T_QYJBXX.LXDH%TYPE;
  V_DJJGMC         CREDIT_QYJBXX.T_QYJBXX.DJJGMC%TYPE;
  V_DJJGMC_SRC     CREDIT_QYJBXX.T_QYJBXX.DJJGMC_SRC%TYPE;
  V_SLRQ           CREDIT_QYJBXX.T_QYJBXX.SLRQ%TYPE;
  V_GSDJRECID      CREDIT_QYJBXX.T_QYJBXX.GSDJRECID%TYPE;
  V_QYLXDM         CREDIT_QYJBXX.T_QYJBXX.QYLXDM%TYPE;
  V_DJJGDM         CREDIT_QYJBXX.T_QYJBXX.DJJGDM%TYPE;
  V_ISQYLXTRANS    CREDIT_QYJBXX.T_QYJBXX.ISQYLXTRANS%TYPE;
  V_ISDJJGTRANS    CREDIT_QYJBXX.T_QYJBXX.ISDJJGTRANS%TYPE;
  V_ISZCBZTRANS    CREDIT_QYJBXX.T_QYJBXX.ISZCBZTRANS%TYPE;
  V_NJZT           CREDIT_QYJBXX.T_QYJBXX.NJZT%TYPE;
  V_NJRQ           CREDIT_QYJBXX.T_QYJBXX.NJRQ%TYPE;
  V_GSNJRECID      CREDIT_QYJBXX.T_QYJBXX.GSNJRECID%TYPE;
  V_ISDISHUIJYFW   CREDIT_QYJBXX.T_QYJBXX.ISDISHUIJYFW%TYPE;
  V_DSNSRSBH       CREDIT_QYJBXX.T_QYJBXX.DSNSRSBH%TYPE;
  V_DSDJRQ         CREDIT_QYJBXX.T_QYJBXX.DSDJRQ%TYPE;
  V_DISDJRECID     CREDIT_QYJBXX.T_QYJBXX.DISDJRECID%TYPE;
  V_ISDISHUIMULTI  CREDIT_QYJBXX.T_QYJBXX.ISDISHUIMULTI%TYPE;
  V_GSNSRSBH       CREDIT_QYJBXX.T_QYJBXX.GSNSRSBH%TYPE;
  V_GSDJRQ         CREDIT_QYJBXX.T_QYJBXX.GSDJRQ%TYPE;
  V_GUOSDJRECID    CREDIT_QYJBXX.T_QYJBXX.GUOSDJRECID%TYPE;
  V_ISGUOSHUIMULTI CREDIT_QYJBXX.T_QYJBXX.ISGUOSHUIMULTI%TYPE;
  V_HGZCH          CREDIT_QYJBXX.T_QYJBXX.HGZCH%TYPE;
  V_HGDJRQ         CREDIT_QYJBXX.T_QYJBXX.HGDJRQ%TYPE;
  V_HAIGDJRECID    CREDIT_QYJBXX.T_QYJBXX.HAIGDJRECID%TYPE;
  V_ISHAIGUANMULTI CREDIT_QYJBXX.T_QYJBXX.ISHAIGUANMULTI%TYPE;
  V_ISDISHUIZX     CREDIT_QYJBXX.T_QYJBXX.ISDISHUIZX%TYPE;
  V_ISGUOSHUIZX    CREDIT_QYJBXX.T_QYJBXX.ISGUOSHUIZX%TYPE;
  V_ISHAIGUANZX    CREDIT_QYJBXX.T_QYJBXX.ISHAIGUANZX%TYPE;
  V_XZQH           CREDIT_QYJBXX.T_QYJBXX.XZQH%TYPE;
  V_XZQH_NAME      CREDIT_QYJBXX.T_QYJBXX.XZQH_NAME%TYPE;
  V_ZJDJ           CREDIT_QYJBXX.T_QYJBXX.ZJDJ%TYPE;
  V_SSHY           CREDIT_QYJBXX.T_QYJBXX.SSHY%TYPE;
  V_SSHYCODE       CREDIT_QYJBXX.T_QYJBXX.SSHY_CODE%TYPE;
  V_ML             CREDIT_QYJBXX.T_QYJBXX.ML%TYPE;
  V_GSDJJGMC       CREDIT_QYJBXX.T_QYJBXX.GSDJJGMC%TYPE;
  V_FLAG           VARCHAR2(1);  
  V_QYZCH          VARCHAR2(50);
  V_SHBXBM         CREDIT_QYJBXX.T_QYJBXX.SHBXBM%TYPE;
  V_SBDJRQ         CREDIT_QYJBXX.T_QYJBXX.SHBXDJRQ%TYPE;
  V_SHXYDM         CREDIT_QYJBXX.T_QYJBXX.TYSHXYDM%TYPE;
  V_QYZT           CREDIT_QYJBXX.T_QYJBXX.QYZT%TYPE;
  V_QYMC           CREDIT_QYJBXX.T_QYJBXX.QYMC%TYPE;
  V_DICTVALUE      CREDIT_ADMIN.T_DICT_DEPT.VALUE%TYPE;
  V_RECID          VARCHAR2(50);
begin
  V_QYID := QYID;
  IF V_QYID IS NOT NULL THEN
     --先更新主体标识
     P_UPDATEQYZTBS(V_QYID);
     V_QYMC := NULL;
     V_QYZCH := NULL;
     V_QYZT := NULL;
     V_XZQH := '320100';
     V_RECID := NULL;
     BEGIN
       SELECT QYMC,QYZCH,QYZT,ZCHRECID INTO V_QYMC,V_QYZCH,V_QYZT,V_RECID FROM T_QYZTBS T WHERE T.QYID=V_QYID AND ROWNUM=1;
     EXCEPTION
       WHEN OTHERS THEN
         DBMS_OUTPUT.PUT_LINE('QYID未找到工商登记信息！');       
     END;
     IF V_QYMC IS NOT NULL THEN
      P_MOVEJGDJXX(V_QYID,V_RECID);
      V_SHXYDM := NULL;
      IF LENGTH(V_QYZCH)=18 THEN
         V_XZQH := SUBSTR(V_QYZCH,3,6);
         V_SHXYDM := V_QYZCH;
      ELSIF LENGTH(V_QYZCH)=15 THEN
         V_XZQH := SUBSTR(V_QYZCH,1,6);
      END IF;
      V_XZQH_NAME := F_GETXZQHNAME(V_XZQH);
      V_ZJDJ      := 0; --资金等级
      V_QYZT := '01';
      IF (V_SHXYDM IS NOT NULL) THEN
        --有统一社会信用代码，则把工商注册号置为空
        V_QYZCH := NULL;
      END IF;    
    BEGIN
        SELECT QYLXMC,
               FDDBRXM,
               FDDBRZW,
               ZCZJ,
               ZJBZ,
               ZCZJ_RMB,
               JYFW,
               ZS,
               DJJGMC,
               SLRQ,
               RECID,
               QYLXDM,
               DJJGDM,
               TRADE_CODE,
               TRADE_NAME 
               INTO V_QYLXMC,
               V_FDDBRXM,
               V_FDDBRZW,
               V_ZCZJ,
               V_ZCBZ,
               V_ZCZJ_RMB,
               V_JYFW,
               V_ZS,
               --V_LXDH,
               V_DJJGMC,
               V_SLRQ,
               V_GSDJRECID,
               V_QYLXDM,
               V_DJJGDM,
               V_SSHYCODE,
               V_SSHY FROM 
       (SELECT QYLXMC,
               FDDBRXM,
               FDDBRZW,
               ZCZJ,
               ZJBZ,
               ZCZJ_RMB,
               JYFW,
               ZS,
               --LXDH,
               DJJGMC,
               SLRQ,
               HZRQ,
               RECID,
               QYLXDM,
               DJJGDM,
               TRADE_CODE,
               TRADE_NAME,
               LENGTH(QYZCH) LEN        
           from T_SX_JGDJXX
         where qyid = V_QYID 
         union
         SELECT QYLXMC,
               FDDBRXM,
               FDDBRZW,
               ZCZJ,
               ZJBZ,
               ZCZJ_RMB,
               JYFW,
               ZS,
               --LXDH,
               DJJGMC,
               SLRQ,
               HZRQ,
               RECID,
               QYLXDM,
               DJJGDM,
               TRADE_CODE,
               TRADE_NAME,
               LENGTH(QYZCH) LEN          
           from T_SX_JGDJXX_HIS
         where qyid = V_QYID
          order by hzrq desc nulls last,LEN DESC) WHERE ROWNUM=1;     
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          DBMS_OUTPUT.PUT_LINE('QYID未找到工商登记信息！');
          V_FLAG := 'Y';
      END;
      --只有找到qyid的才是企业，才需要更新
      IF V_FLAG = 'Y' THEN
         UPDATE CREDIT_QYJBXX.T_QYJBXX
         SET XZQH = V_XZQH,
             XZQH_NAME = V_XZQH_NAME,
             QYZT = V_QYZT,
             QYZCH = V_QYZCH,
             TYSHXYDM = V_SHXYDM,
             QYMC = V_QYMC
         WHERE QYID=V_QYID;
      ELSE
        V_ZCBZ_SRC   := V_ZCBZ;
        V_JYFW_SRC   := V_JYFW;
        V_DJJGMC_SRC := V_DJJGMC;
        V_QYLXMC_SRC := V_QYLXMC;
        --以下是转换代码部分
        --ZCBZ
        V_ISZCBZTRANS := 'N';
        IF V_ZCBZ IS NULL THEN
          V_ZCBZ        := '人民币';
          V_ISZCBZTRANS := 'Y';
        ELSE
          BEGIN
            SELECT VALUE
              INTO V_DICTVALUE
              FROM T_DICT_DEPT
             WHERE DEPTID = 'SX'
               AND DICTNAME = 'GONGSHANG_BZ'
               AND CODE = V_ZCBZ
               AND CODE != VALUE;
            V_ZCBZ        := V_DICTVALUE;
            V_ISZCBZTRANS := 'Y';
          EXCEPTION
            --NO_DATA_FOUND 不处理
            WHEN NO_DATA_FOUND THEN
              DBMS_OUTPUT.PUT_LINE('币种代码未找到');
          END;
          
        END IF;
        
        --资金等级
        IF V_ZCBZ = '人民币' AND V_ZCZJ IS NOT NULL THEN
          IF V_ZCZJ < 100 THEN
            V_ZJDJ := 1;
          ELSIF V_ZCZJ < 500 THEN
            V_ZJDJ := 2;
          ELSIF V_ZCZJ < 1000 THEN
            V_ZJDJ := 3;
          ELSIF V_ZCZJ >= 1000 THEN
            V_ZJDJ := 4;
          END IF;
        ELSIF V_ZCBZ != '人民币' AND V_ZCZJ_RMB IS NOT NULL THEN
          IF V_ZCZJ_RMB < 100 THEN
            V_ZJDJ := 1;
          ELSIF V_ZCZJ_RMB < 500 THEN
            V_ZJDJ := 2;
          ELSIF V_ZCZJ_RMB < 1000 THEN
            V_ZJDJ := 3;
          ELSIF V_ZCZJ_RMB >= 1000 THEN
            V_ZJDJ := 4;
          END IF;
        END IF;
        
        --行业门类
        IF (V_SSHYCODE IS NULL) AND (V_SSHY IS NOT NULL) THEN
          BEGIN
            select hyfldm INTO V_SSHYCODE from 
            (select hyfldm from t_dict_jjhyfl t where lbmc=V_SSHY order by dl nulls last,zl nulls last,xl nulls last) where rownum=1;
            --SELECT HYFLDM INTO V_SSHYCODE FROM T_DICT_JJHYFL T WHERE LBMC=V_SSHY;
          EXCEPTION 
            WHEN NO_DATA_FOUND THEN
              DBMS_OUTPUT.PUT_LINE('行业代码未找到');
          END;
        END IF;
        IF (V_SSHYCODE IS NOT NULL) THEN
          V_ML := SUBSTR(V_SSHYCODE, 1, 1);
        ELSE
           V_ML:=NULL;
        END IF;

        --QYLXMC
        V_ISQYLXTRANS := 'N';
        IF (V_QYLXMC IS NULL) AND (V_QYLXDM IS NOT NULL) THEN
          BEGIN
            SELECT VALUE
              INTO V_DICTVALUE
              FROM CREDIT_ADMIN.T_DICT_DEPT
             WHERE DEPTID = 'SX'
               AND DICTNAME = 'GONGSHANG_QYLX'
               AND CODE = V_QYLXDM
               AND CODE != VALUE;
            V_QYLXMC      := V_DICTVALUE;
            V_ISQYLXTRANS := 'Y';
          EXCEPTION
            --NO_DATA_FOUND不处理
            WHEN NO_DATA_FOUND THEN
              DBMS_OUTPUT.PUT_LINE('企业类型代码未找到');
          END;
        END IF;
        --DJJGMC
        V_ISDJJGTRANS := 'N';
        IF (V_DJJGMC IS NULL) AND (V_DJJGDM IS NOT NULL) THEN
          BEGIN
            SELECT VALUE
              INTO V_DICTVALUE
              FROM CREDIT_ADMIN.T_DICT_DEPT
             WHERE DEPTID = 'SX'
               AND DICTNAME = 'GONGSHANG_DJJG'
               AND CODE = V_DJJGDM
               AND CODE != VALUE;
            V_DJJGMC      := V_DICTVALUE;
            V_ISDJJGTRANS := 'Y';
          EXCEPTION
            --NO_DATA_FOUND 不处理
            WHEN NO_DATA_FOUND THEN
              DBMS_OUTPUT.PUT_LINE('登记机关代码未找到');
          END;
        END IF;
        --代码转换部分结束
        --工商年检信息
        V_NJZT      := NULL;
        V_NJRQ      := NULL;
        V_GSNJRECID := NULL;
       -- BEGIN
        --  SELECT NJJGMC, NJRQ, RECID
           ---- INTO V_NJZT, V_NJRQ, V_GSNJRECID
           -- FROM (SELECT NJJGMC, NJRQ, RECID
                   -- FROM T_SX_GONGSHANG_NJXX
                 --  WHERE QYID = V_QYID
                  -- ORDER BY NJRQ NULLS LAST)
          -- WHERE ROWNUM = 1;
       -- EXCEPTION
          --NO_DATA_FOUND不处理
         -- WHEN NO_DATA_FOUND THEN
           -- DBMS_OUTPUT.PUT_LINE('年检记录未找到');
      --  END;

        --地税登记
        V_ISDISHUIMULTI := 'N';
        V_DSNSRSBH      := NULL;
        V_DSDJRQ        := NULL;
        V_DISDJRECID    := NULL;
        V_ISDISHUIJYFW  := 'N';
       
        
        --国税登记信息
        V_GSNSRSBH    := NULL;
        V_GSDJRQ      := NULL;
        V_GUOSDJRECID := NULL;
        V_GSDJJGMC    := NULL;
        BEGIN
          SELECT RECID,NSRSBH,DJRQ,DJJGMC INTO V_GUOSDJRECID,V_GSNSRSBH,V_GSDJRQ,V_GSDJJGMC 
          FROM CREDIT_PRODUCT.T_SX_GSSWDXX T WHERE T.QYID=V_QYID 
          AND (T.BGRQ,T.ROWID)=(SELECT MAX(BGRQ),MAX(ROWID) FROM CREDIT_PRODUCT.T_SX_GSSWDXX WHERE QYID=V_QYID);
        EXCEPTION
            WHEN NO_DATA_FOUND THEN
              DBMS_OUTPUT.PUT_LINE('国税登记信息未找到');
        END;
        
        --社保信息
        V_SHBXBM := NULL;
        V_SBDJRQ := NULL;
        BEGIN
          SELECT DWM,DJRQ INTO V_SHBXBM,V_SBDJRQ FROM CREDIT_PRODUCT.T_NJ_RENSHE_DWLDBZJBXX T WHERE QYID=V_QYID
          AND (T.DJRQ,T.ROWID)=(SELECT MAX(DJRQ),MAX(ROWID) FROM CREDIT_PRODUCT.T_NJ_RENSHE_DWLDBZJBXX WHERE QYID=V_QYID);
        EXCEPTION
          WHEN NO_DATA_FOUND THEN
            DBMS_OUTPUT.PUT_LINE('社保登记信息未找到');
        END;
      
        --地税注销
        V_ISDISHUIZX := 'N';
      
        --海关注销
        V_ISHAIGUANZX := 'N';
        
        --更新数据
        UPDATE CREDIT_QYJBXX.T_QYJBXX
           SET QYLXMC         = V_QYLXMC,
               QYLXMC_SRC     = V_QYLXMC_SRC,
               FDDBRXM        = V_FDDBRXM,
               FDDBRZW        = V_FDDBRZW,
               ZCZJ           = V_ZCZJ,
               ZCBZ           = V_ZCBZ,
               ZCZJ_RMB       = V_ZCZJ_RMB,
               ZCBZ_SRC       = V_ZCBZ_SRC,
               JYFW           = V_JYFW,
               JYFW_SRC       = V_JYFW_SRC,
               ZS             = V_ZS,
               LXDH           = V_LXDH,
               DJJGMC         = V_DJJGMC,
               DJJGMC_SRC     = V_DJJGMC_SRC,
               SLRQ           = V_SLRQ,
               GSDJRECID      = V_GSDJRECID,
               QYLXDM         = V_QYLXDM,
               DJJGDM         = V_DJJGDM,
               ISQYLXTRANS    = V_ISQYLXTRANS,
               ISDJJGTRANS    = V_ISDJJGTRANS,
               ISZCBZTRANS    = V_ISZCBZTRANS,
               NJZT           = V_NJZT,
               NJRQ           = V_NJRQ,
               GSNJRECID      = V_GSNJRECID,
               ISDISHUIJYFW   = V_ISDISHUIJYFW,
               DSNSRSBH       = V_DSNSRSBH,
               DSDJRQ         = V_DSDJRQ,
               DISDJRECID     = V_DISDJRECID,
               ISDISHUIMULTI  = V_ISDISHUIMULTI,
               GSNSRSBH       = V_GSNSRSBH,
               GSDJRQ         = V_GSDJRQ,
               GSDJJGMC       = V_GSDJJGMC,
               GUOSDJRECID    = V_GUOSDJRECID,
               ISGUOSHUIMULTI = V_ISGUOSHUIMULTI,
               HGZCH          = V_HGZCH,
               HGDJRQ         = V_HGDJRQ,
               HAIGDJRECID    = V_HAIGDJRECID,
               ISHAIGUANMULTI = V_ISHAIGUANMULTI,
               ISDISHUIZX     = V_ISDISHUIZX,
               ISGUOSHUIZX    = V_ISGUOSHUIZX,
               ISHAIGUANZX    = V_ISHAIGUANZX,
               XZQH           = V_XZQH,
               XZQH_NAME      = V_XZQH_NAME,
               ZJDJ           = V_ZJDJ,
               SSHY           = V_SSHY,
               SSHY_CODE      = V_SSHYCODE,
               ML             = V_ML,
               SHBXBM         = V_SHBXBM,
               SHBXDJRQ       = V_SBDJRQ,
               QYZT           = V_QYZT,
               TYSHXYDM       = V_SHXYDM,
               QYZCH          = V_QYZCH,
               QYMC           = V_QYMC
         WHERE QYID = V_QYID;      
         COMMIT;
      END IF;
    END IF;
  END IF;
end P_UPDATEQYJBXX;
/
