CREATE procedure              prc_serv_ylh_zhijian_end_qyid is
       v_sql_ylh_zhijian_history        varchar2(5000) := '';
begin
    dbms_output.put_line('Schema: credit_product,  信用信息应用——遗漏户提示——质监（最终）');

    execute immediate 'truncate table SERV_YLH_ZHIJIAN_HISTORY';

    v_sql_ylh_zhijian_history := '
          INSERT INTO SERV_YLH_ZHIJIAN_HISTORY
          			select *
				        			from SERV_YLH_ZHIJIAN_CURRENT
				        where qyid in (
				         		(select qyid
				        							from SERV_YLH_ZHIJIAN_CURRENT
				 						)
				 						MINUS
				 						(select qyid
				 						        from credit_product.T_ZHIJIAN_ZZJGDM
				             				where ( jglxdm in (' || '''' || '1' || '''' || ','
                                    || '''' || '2' || '''' || ','
                                    || '''' || 'B' || '''' || ')'
                                    || 'or jglxdm is null )
				 						)
				        )';

    --dbms_output.put_line(v_sql_ylh_zhijian_history);
    execute immediate v_sql_ylh_zhijian_history;
    dbms_output.put_line('*****************');


      commit;
      exception
    when others then
      rollback;
      raise;

end prc_serv_ylh_zhijian_end_qyid;

/
