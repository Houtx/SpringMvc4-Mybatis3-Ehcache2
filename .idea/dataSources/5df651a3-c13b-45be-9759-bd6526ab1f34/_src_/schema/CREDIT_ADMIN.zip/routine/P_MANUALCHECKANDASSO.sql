CREATE procedure P_MANUALCHECKANDASSO(FILEID IN VARCHAR2) AUTHID CURRENT_USER is
V_FILEID VARCHAR2(50);
CURSOR C IS SELECT RECID FROM T_DATAPROCESS T WHERE T.FILEID=V_FILEID AND T.ISVALID IS NULL;
V_COUNT INTEGER;
V_RECID VARCHAR2(50);
V_START VARCHAR2(20);
V_RULEVERSION VARCHAR2(50);
V_GRID INTEGER;
V_SFZJHM VARCHAR2(50);
V_ASSOCOUNT INTEGER;
begin
  V_FILEID := FILEID;
  V_COUNT := 0;
  V_ASSOCOUNT := 0;
  IF V_FILEID IS NOT NULL THEN
     DELETE FROM TMPDP T WHERE T.FILEID=V_FILEID;
     INSERT INTO TMPDP(FILEID,VCOUNT) VALUES (V_FILEID,0);
     COMMIT;
     V_START := TO_CHAR(SYSDATE,'YYYYMMDDHH24miss');
     SELECT F.RULEVERSIONID INTO V_RULEVERSION FROM T_SYS_DATAFILEINFO T,T_META_RULEVERSION F WHERE T.MESSAGEID=F.MESSAGEID AND T.FILEID=V_FILEID AND F.ISENABLE='Y';
     FOR RC IN C LOOP
         V_RECID := RC.RECID;
         --MANUAL CHECK
         --UPDATE T_DATAPROCESS F SET F.ISVALID='Y',F.RULEVERSIONID=V_RULEVERSION WHERE F.RECID=V_RECID;
         insert into t_nj_renshe_grshbxxx_fmt(recid,tbr,sfzjlx,sfzjhm,xm,dwm,zzjgdm,qymc,ylje,ybje,shyje,gsje,syje,bmscsj) 
select recid,tbr,sfzjlx,sfzjhm,xm,dwm,zzjgdm,qymc,ylje,ybje,shyje,gsje,syje,to_date(bmscsj,'yyyy-mm-dd') from t_nj_renshe_grshbxxx_raw t where t.recid=V_RECID;
         --MANUAL ASSOCIATE
         V_GRID := 0;
         SELECT SFZJHM INTO V_SFZJHM FROM T_NJ_RENSHE_GRSHBXXX_RAW N WHERE N.RECID=V_RECID;
         BEGIN
           SELECT GRID INTO V_GRID FROM T_GRZTBS M WHERE M.SFZJHM=V_SFZJHM;
           V_ASSOCOUNT := V_ASSOCOUNT + 1;
         EXCEPTION
           WHEN OTHERS THEN
             DBMS_OUTPUT.PUT_LINE('NO DATA FOUND');
         END;
         UPDATE T_DATAPROCESS F SET F.ISVALID='Y',F.RULEVERSIONID=V_RULEVERSION,F.STATE='V',F.GRID=V_GRID,F.GR_JOINFLAG='0110' WHERE F.RECID=V_RECID;
         insert into t_nj_renshe_grshbxxx(GRID,recid,tbr,sfzjlx,sfzjhm,xm,dwm,zzjgdm,qymc,ylje,ybje,shyje,gsje,syje,bmscsj)
select V_GRID,recid,tbr,sfzjlx,sfzjhm,xm,dwm,zzjgdm,qymc,ylje,ybje,shyje,gsje,syje,bmscsj from t_nj_renshe_grshbxxx_fmt t where t.recid=V_RECID;
         V_COUNT := V_COUNT +1;
         IF MOD(V_COUNT,10000)=0 THEN
            UPDATE TMPDP T SET T.VCOUNT=V_COUNT WHERE T.FILEID=V_FILEID;
            COMMIT;
         END IF;
     END LOOP;
     UPDATE TMPDP T SET T.VCOUNT=V_COUNT WHERE T.FILEID=V_FILEID;
     COMMIT;
     --CLOSE C;
     UPDATE T_SYS_DATAFILEINFO T SET T.CLEANED='Y',T.SEPARATED='Y',T.ASSOCIATED='Y' WHERE T.FILEID=V_FILEID;
     COMMIT;     
     UPDATE T_SYS_DATAFILEGROUPS T SET T.PROCESSSTATE='YGLBD',T.PROCESSSTATEDESC='已关联比对',T.FINISHED='Y',T.FINISHEDTIME=SYSDATE WHERE T.FILEID=V_FILEID;
     COMMIT;
     --规则检查报告
     begin
     insert into T_RPT_CDATACHECK
  (reportid,
   domainid,
   userid,
   deptid,
   fileid,
   Rulebaseversion,
   messageid,
   recordcounts,
   Validrecordcounts,
   Invalidrecordcounts,
   checkstarttime,
   checkendtime,
   reporttime,
   Logicinvalidrecordcounts,
   Warnrecordcounts,
   Basecheckcolumncounts,
   Logiccheckcolumncounts,
   Logiccheckcolumnscounts,
   rgxz_counts)
  select lower(SYS_GUID()),
         t.domainid,
         t.userid,
         t.deptid,
         t.fileid,
         V_RULEVERSION,
         t.messageid,
         t.recordfilerecordcounts,
         t.recordfilerecordcounts,
         0,
         TO_DATE(V_START,'YYYYMMDDHH24miss'),
         sysdate,
         SYSDATE,
         0,0,0,0,0,0
    from t_sys_datafileinfo t
   where t.fileid = V_FILEID;
   exception
     when others then
       dbms_output.put_line('err');
   end;   
   COMMIT;
   begin
   --关联报告
   INSERT INTO T_RPT_ASSOCIATESTATISTICS(REPORTID,DOMAINID,DEPTID,USERID,MESSAGEID,RECORDFILEID,
     CRULETYPE,CONNECTCOUNT,STARTTIME,LASTUPDATETIME,NOTCONNECTCOUNT,RULE_NGL_COUNTS,RULE_RGL_COUNTS,
     RULE_RQXGL_COUNTS,RULE_GR_0111_COUNTS,RULE_GR_0110_COUNTS)
     SELECT LOWER(SYS_GUID()),DOMAINID,DEPTID,'ywgladmin',messageid,fileid,'0110',V_ASSOCOUNT,
     TO_DATE(V_START,'YYYYMMDDHH24miss'),SYSDATE,RECORDFILERECORDCOUNTS-V_ASSOCOUNT,0,0,0,0,V_ASSOCOUNT FROM T_SYS_DATAFILEINFO WHERE FILEID=V_FILEID;
     
   exception
     when others then
       dbms_output.put_line('err');
   end; 
   COMMIT;  
  END IF;
end P_MANUALCHECKANDASSO;
/
