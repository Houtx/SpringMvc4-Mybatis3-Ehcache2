CREATE FUNCTION CHECKORGCODE(organizationCode VARCHAR2)
/*
    功能：验证组织机构代码，成功返回1，失败返回0
    organizationCode：要验证的组织机构代码
    相关资料：
    http://baike.baidu.com/view/238601.htm
  */
 RETURN NUMBER AS
  codeSum NUMBER(10) := 0;
  code    VARCHAR(100);
  code_9  varchar(1);
  C9      NUMBER(2);
  /*字符与字符的值，每个字符后两位为该字符的字符数值*/
  Ci CHAR(250) := '000101202303404505606707808909A10B11C12D13E14F15G16H17I18J19K20L21M22N23O24P25Q26R27S28T29U30V31W32X33Y34Z35';
  /*前8位字符的加权因子*/
  type v_ar is varray(10) of number;
  Wi v_ar := v_ar(3, 7, 9, 10, 5, 8, 4, 2);
BEGIN
  /*判断是否为null*/
  IF (organizationCode is NULL) THEN
    BEGIN
      RETURN 0;
    END;
  END IF;

  code := RTRIM(LTRIM(REPLACE(organizationCode, '-', ''))); /*把-,前后空格去掉*/

  /*验证长度是否正确*/
  /*验证机构代码是由数字和大写字母组成*/
  IF (LENGTH(code) != 9 or NOT REGEXP_LIKE(code, '^[A-Z0-9]+$')) THEN
    BEGIN
      RETURN 0;
    END;
  END IF;

  /*前8位字符的字符数值分别乘于该位的加权因子，然后求和*/
  for i in 1 .. Wi.count loop
    codeSum := codeSum +
               to_Number(substr(Ci, INSTR(Ci, substr(code, i, 1)) + 1, 2)) *
               Wi(i);
  end loop;

  /* 计算校验码C9*/
  C9     := 11 - (codeSum MOD 11);
  code_9 := substr(code, 9, 1);

  /*验证校验码C9*/
  /*当C9的值为10时，校验码应是拉丁字母X */
  /*当C9的值为11时校验码应是0*/
  /*验证第9位是否等于计算出的校验结果*/
  IF ((C9 = 10 and code_9 = 'X') or (C9 = 11 and code_9 = '0') or
     (code_9 = to_char(C9))) THEN
    BEGIN
      return 1;
    END;
  END IF;

  RETURN 0;
EXCEPTION
  WHEN OTHERS THEN
    raise;
END;

/
