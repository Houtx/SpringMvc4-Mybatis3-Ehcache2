CREATE procedure P_BATCH_ZTKMAPPING15 is
begin
  --针对15张公共表自动设置主题库配置
  --个人双公示主题库
  insert into t_ztk_mapping
  (mappingid,   domainid,   messageid,   mappingtype,   deptid,   deptname,   messageid_src,   messagename_src,
   tablename_src,   tablejoin,   datasql,   usercondition,   sqldesc,   pname,   isuse,   orderid,   createtime,
   updatetime,   ismodified,   isverified,   verifytime,   verifycomment,   verifyuser)
  select f.domainflag||'_'||sys_guid() mappingid,t.domainid, t.messageid,'1' mappingtype,
  m.deptid,n.deptname,m.messageid messageid_src,m.messagename messagename_src,
  m.tablename tablename_src,'a0.RECID=a1.RECID' tablejoin,
  'SELECT a0.GRID,a0.RECID,' || (select wm_concat('a0.' || columnname) from t_meta_column f where f.messageid=m.messageid and f.isuse='Y')||',a1.DEPTID FROM CREDIT_PRODUCT.'||m.tablename ||' a0,T_DATAPROCESS a1 where 1=1 ' DATASQL,
  '' usercondition,n.deptname sqldesc,'' pname,'Y' isuse,m.orderid,sysdate createtime,sysdate updatetime,
  'Y','Y',SYSDATE verifytime,'自动审核通过','ADMIN'
    from t_ztk_meta_table t, t_ztk_type f,t_meta_table m,t_sys_department n
   where t.domainid = f.domainid
     and t.domainid = '016'
     and m.messagename=t.messagename
     and m.deptid=n.deptabbr and m.messageid not in (select messageid_src from t_ztk_mapping where domainid='016');
     commit;

--法人双公示主题库
     insert into t_ztk_mapping
  (mappingid,   domainid,   messageid,   mappingtype,   deptid,   deptname,   messageid_src,   messagename_src,
   tablename_src,   tablejoin,   datasql,   usercondition,   sqldesc,   pname,   isuse,   orderid,   createtime,
   updatetime,   ismodified,   isverified,   verifytime,   verifycomment,   verifyuser)
  select f.domainflag||'_'||sys_guid() mappingid,t.domainid, t.messageid,'1' mappingtype,
  m.deptid,n.deptname,m.messageid messageid_src,m.messagename messagename_src,
  m.tablename tablename_src,'a0.RECID=a1.RECID' tablejoin,
  'SELECT a0.QYID,a0.RECID,' || (select wm_concat('a0.' || columnname) from t_meta_column f where f.messageid=m.messageid and f.isuse='Y')||',a1.DEPTID FROM CREDIT_PRODUCT.'||m.tablename ||' a0,T_DATAPROCESS a1 where 1=1 ' DATASQL,
  '' usercondition,n.deptname sqldesc,'' pname,'Y' isuse,m.orderid,sysdate createtime,sysdate updatetime,
  'Y','Y',SYSDATE verifytime,'自动审核通过','ADMIN'
    from t_ztk_meta_table t, t_ztk_type f,t_meta_table m,t_sys_department n
   where t.domainid = f.domainid
     and t.domainid = '015'
     and m.messagename=t.messagename
     and m.deptid=n.deptabbr and m.messageid not in (select messageid_src from t_ztk_mapping where domainid='015');
     commit;


--报送省级主题库
     insert into t_ztk_mapping
  (mappingid,   domainid,   messageid,   mappingtype,   deptid,   deptname,   messageid_src,   messagename_src,
   tablename_src,   tablejoin,   datasql,   usercondition,   sqldesc,   pname,   isuse,   orderid,   createtime,
   updatetime,   ismodified,   isverified,   verifytime,   verifycomment,   verifyuser)
  select f.domainflag||'_'||sys_guid() mappingid,t.domainid, t.messageid,'0' mappingtype,
  m.deptid,n.deptname,m.messageid messageid_src,m.messagename messagename_src,
  m.tablename tablename_src,'' tablejoin,
  'SELECT a0.QYID,a0.RECID,' || (select wm_concat('a0.' || columnname) from t_meta_column f where f.messageid=m.messageid and f.isuse='Y')||' FROM CREDIT_PRODUCT.'||m.tablename ||' a0 where 1=1 ' DATASQL,
  '' usercondition,n.deptname sqldesc,'' pname,'Y' isuse,m.orderid,sysdate createtime,sysdate updatetime,
  'Y','Y',SYSDATE verifytime,'自动审核通过','ADMIN'
    from t_ztk_meta_table t, t_ztk_type f,t_meta_table m,t_sys_department n
   where t.domainid = f.domainid
     and t.domainid = '017'
     and m.messagename=t.messagename
     and m.deptid=n.deptabbr and m.deptid not in ('SX') and m.messageid not in (select messageid_src from t_ztk_mapping where domainid='017');
     commit;
end P_BATCH_ZTKMAPPING15;
/
