CREATE FUNCTION "FN_GETDOMAINNAME" (DOMAINID  IN VARCHAR2)
return varchar2 is
v_domainnames varchar2(400);
V_LENGTH int;
v_j int;
V_PARAM ty_str_split;----条件
v_domainname varchar2(200);
begin
     V_PARAM:=FN_SPLIT(domainid,',');
     V_LENGTH:=V_PARAM.COUNT;
     v_domainnames:='';
      v_j:=1;
      WHILE v_j<=V_LENGTH
      LOOP
          if(v_j!=1)
          then v_domainnames:=v_domainnames||',';
          end if;
          select t.domainname into v_domainname from t_meta_appdomain t where t.domainid= V_PARAM(v_j);
          v_domainnames:=v_domainnames||v_domainname;
          V_J:=V_J+1;
      END LOOP;
      return v_domainnames;
end fn_getDomainname;
/
