CREATE PROCEDURE p_stat_sgstj_job(
                                                      RESULT OUT VARCHAR2) IS
  V_JOBID varchar(100);
  V_SQL   VARCHAR2(1000);

BEGIN

V_SQL := 'begin
         sys.dbms_job.submit(:jobid,
                        what => ''begin p_stat_sgstj; end;'');
         commit;
         end;';

  EXECUTE IMMEDIATE V_SQL
    USING OUT V_JOBID;
  COMMIT;
  RESULT := V_JOBID;
EXCEPTION
  When others then
    RESULT := sqlerrm(SqlCode);
end p_stat_sgstj_job;
/
