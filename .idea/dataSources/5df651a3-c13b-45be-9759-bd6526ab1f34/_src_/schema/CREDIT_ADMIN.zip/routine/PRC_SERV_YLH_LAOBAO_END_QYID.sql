CREATE procedure              prc_serv_ylh_laobao_end_qyid is
       v_sql_ylh_laobao_history        varchar2(5000) := '';
begin
    dbms_output.put_line('Schema: credit_product,  信用信息应用——遗漏户提示——劳保（最新）');

    execute immediate 'truncate table SERV_YLH_LAOBAO_HISTORY';

    v_sql_ylh_laobao_history := '
          INSERT INTO SERV_YLH_LAOBAO_HISTORY
                select *
                      from SERV_YLH_LAOBAO_CURRENT
                where qyid in (
                     (select qyid
                              from SERV_YLH_LAOBAO_CURRENT
                     )
                     MINUS
                     (select qyid
                             from credit_product.T_LAOBAO_CBXX
                             where ( jglxdm in (' || '''' || '10' || '''' || ','
                                    || '''' || '80' || '''' || ')'
                                    || 'or jglxdm is null )
                     )
                )';

    --dbms_output.put_line(v_sql_ylh_laobao_history);
    execute immediate v_sql_ylh_laobao_history;
    dbms_output.put_line('*****************');


      commit;
      exception
    when others then
      rollback;
      raise;

end prc_serv_ylh_laobao_end_qyid;

/
