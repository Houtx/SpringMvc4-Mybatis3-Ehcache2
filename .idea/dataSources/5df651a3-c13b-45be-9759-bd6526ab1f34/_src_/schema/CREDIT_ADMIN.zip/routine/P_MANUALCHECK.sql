CREATE procedure P_MANUALCHECK(FILEID IN VARCHAR2) AUTHID CURRENT_USER is
V_FILEID VARCHAR2(50);
CURSOR C IS SELECT RECID FROM T_DATAPROCESS T WHERE T.FILEID=V_FILEID AND T.ISVALID IS NULL;
V_COUNT INTEGER;
V_RECID VARCHAR2(50);
V_START VARCHAR2(20);
V_RULEVERSION VARCHAR2(50);
begin
  V_FILEID := FILEID;
  V_COUNT := 0;
  IF V_FILEID IS NOT NULL THEN
     INSERT INTO TMPDP(FILEID,VCOUNT) VALUES (V_FILEID,0);
     COMMIT;
     V_START := TO_CHAR(SYSDATE,'YYYYMMDDHH24miss');
     SELECT F.RULEVERSIONID INTO V_RULEVERSION FROM T_SYS_DATAFILEINFO T,T_META_RULEVERSION F WHERE T.MESSAGEID=F.MESSAGEID AND T.FILEID=V_FILEID AND F.ISENABLE='Y';
     FOR RC IN C LOOP
         V_RECID := RC.RECID;
         UPDATE T_DATAPROCESS F SET F.ISVALID='Y',F.RULEVERSIONID=V_RULEVERSION WHERE F.RECID=V_RECID;
         insert into t_nj_renshe_grshbxxx_fmt(recid,tbr,sfzjlx,sfzjhm,xm,dwm,zzjgdm,qymc,ylje,ybje,shyje,gsje,syje,bmscsj) 
select recid,tbr,sfzjlx,sfzjhm,xm,dwm,zzjgdm,qymc,ylje,ybje,shyje,gsje,syje,to_date(bmscsj,'yyyy-mm-dd') from t_nj_renshe_grshbxxx_raw t where t.recid=V_RECID;
         V_COUNT := V_COUNT +1;
         IF MOD(V_COUNT,10000)=0 THEN
            UPDATE TMPDP T SET T.VCOUNT=V_COUNT WHERE T.FILEID=V_FILEID;
            COMMIT;
         END IF;
     END LOOP;
     UPDATE TMPDP T SET T.VCOUNT=V_COUNT WHERE T.FILEID=V_FILEID;
     COMMIT;
     --CLOSE C;
     UPDATE T_SYS_DATAFILEINFO T SET T.CLEANED='Y' WHERE T.FILEID=V_FILEID;
     COMMIT;     
     UPDATE T_SYS_DATAFILEGROUPS T SET T.PROCESSSTATE='YGZJC',T.PROCESSSTATEDESC='已规则检查' WHERE T.FILEID=V_FILEID;
     COMMIT;
     
     insert into T_RPT_CDATACHECK
  (reportid,
   domainid,
   userid,
   deptid,
   fileid,
   Rulebaseversion,
   messageid,
   recordcounts,
   Validrecordcounts,
   Invalidrecordcounts,
   checkstarttime,
   checkendtime,
   reporttime,
   Logicinvalidrecordcounts,
   Warnrecordcounts,
   Basecheckcolumncounts,
   Logiccheckcolumncounts,
   Logiccheckcolumnscounts,
   rgxz_counts)
  select lower(SYS_GUID()),
         t.domainid,
         t.userid,
         t.deptid,
         t.fileid,
         V_RULEVERSION,
         t.messageid,
         t.recordfilerecordcounts,
         t.recordfilerecordcounts,
         0,
         TO_DATE(V_START,'YYYYMMDDHH24miss'),
         sysdate,
         SYSDATE,
         0,0,0,0,0,0
    from t_sys_datafileinfo t
   where t.fileid = V_FILEID;
   COMMIT;   
  END IF;
end P_MANUALCHECK;
/
