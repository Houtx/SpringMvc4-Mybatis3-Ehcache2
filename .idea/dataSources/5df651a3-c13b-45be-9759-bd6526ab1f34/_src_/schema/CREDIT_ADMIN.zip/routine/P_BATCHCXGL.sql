CREATE procedure p_batchcxgl(V_USERID VARCHAR2,v_deptid varchar2,v_messageid varchar2,result OUT varchar2) is
---重新关联
V_FILEGROUPID T_SYS_DATAFILEGROUPS.FILEGROUPID%TYPE;
V_COUNT          INTEGER := 1; --计数器
V_CGCOUNT        INTEGER := 0; --成功
V_SQL VARCHAR2(2000);
type record_cur_type is ref cursor;
record_cur record_cur_type;
begin
     V_SQL:=' SELECT t.FILEGROUPID from T_SYS_DATAFILEGROUPS  t
               WHERE t.grouptype = ''DATA''
                 AND t.PROCESSSTATE = ''YGLBD''
                 AND (not exists (select * from T_SYS_PROCESSCOMMAND tp
                                   where tp.runstate in (''1'', ''0'')
                                     and t.filegroupid=tp.filegroupid))';
   if(v_deptid IS NOT NULL )
   THEN V_SQL:=V_SQL||' AND T.UPLOADDEPTID='''||v_deptid||''' ';
   end if;
   if(v_messageid IS NOT NULL)
   THEN V_SQL:=V_SQL||' AND T.MESSAGEID='''||v_messageid||''' ';
   end if;
  OPEN record_cur FOR
          V_SQL;
     LOOP
         FETCH record_cur INTO V_FILEGROUPID;
         exit when record_cur%notfound;
         insert into T_SYS_PROCESSCOMMAND
          (
            CMDID,FILEGROUPID,USERID,CMDCODE,CMD,CMDTIME,RUNSTATE
          )
          values
          (
            S_CENTER_DATAPROCESS.NEXTVAL
            ,V_FILEGROUPID
            ,V_USERID
            ,'CXGL'
            ,'重新关联'
            ,SYSDATE,
            '0'
          );
          V_CGCOUNT:=V_CGCOUNT+1;
         IF (V_COUNT / 10000 = 0) THEN
           COMMIT; --提交更新
         END IF;
         V_COUNT:=V_COUNT+1;
   END LOOP;
   COMMIT; --剩下的也要提交
   CLOSE record_cur; --关闭游标
   result:='成功发送命令' ||V_CGCOUNT||'条';
   end p_batchcxgl;
/
