CREATE procedure P_SGS_FRESHDATA AUTHID CURRENT_USER is
begin
  --清理主题库表，删除已停发的记录
  DELETE FROM CREDIT_QYSGS.T_QYSGS_FRXZXK T WHERE T.RECID IN (SELECT RECID FROM CREDIT_PRODUCT.T_DATAPAUSE);
  COMMIT;
  DELETE FROM CREDIT_QYSGS.T_QYSGS_FRXZCF T WHERE T.RECID IN (SELECT RECID FROM CREDIT_PRODUCT.T_DATAPAUSE);
  COMMIT;
  DELETE FROM CREDIT_GRSGS.T_GRSGS_GRXZXK T WHERE T.RECID IN (SELECT RECID FROM CREDIT_PRODUCT.T_DATAPAUSE);
  COMMIT;
  DELETE FROM CREDIT_GRSGS.T_GRSGS_GRXZCF T WHERE T.RECID IN (SELECT RECID FROM CREDIT_PRODUCT.T_DATAPAUSE);
  COMMIT;
  
  --清理暂存表、报送表及公示表
  DELETE FROM T_NJ_SGK_XZXK T WHERE T.RECID IN (SELECT RECID FROM CREDIT_PRODUCT.T_DATAPAUSE);
  COMMIT;
  DELETE FROM T_NJ_SGK_CFXX T WHERE T.RECID IN (SELECT RECID FROM CREDIT_PRODUCT.T_DATAPAUSE);
  COMMIT;
  DELETE FROM T_NJ_SGK_GRXZXK T WHERE T.RECID IN (SELECT RECID FROM CREDIT_PRODUCT.T_DATAPAUSE);
  COMMIT;
  DELETE FROM T_NJ_SGK_GRCFXX T WHERE T.RECID IN (SELECT RECID FROM CREDIT_PRODUCT.T_DATAPAUSE);
  COMMIT;
  --报送表已经报送过的可以保留  
  
  DELETE FROM T_NJ_SGK_XZXK3 T WHERE T.RECID IN (SELECT RECID FROM CREDIT_PRODUCT.T_DATAPAUSE);
  COMMIT;
  DELETE FROM T_NJ_SGK_CFXX3 T WHERE T.RECID IN (SELECT RECID FROM CREDIT_PRODUCT.T_DATAPAUSE);
  COMMIT;
  DELETE FROM T_NJ_SGK_GRXZXK3 T WHERE T.RECID IN (SELECT RECID FROM CREDIT_PRODUCT.T_DATAPAUSE);
  COMMIT;
  DELETE FROM T_NJ_SGK_GRCFXX3 T WHERE T.RECID IN (SELECT RECID FROM CREDIT_PRODUCT.T_DATAPAUSE);
  COMMIT;
  --更新到暂存表
  --法人 
  INSERT INTO T_NJ_SGK_XZXK SELECT * FROM CREDIT_QYSGS.T_QYSGS_FRXZXK T 
  WHERE T.RECID NOT IN (SELECT RECID FROM T_NJ_SGK_XZXK);
  COMMIT;
  INSERT INTO T_NJ_SGK_CFXX SELECT * FROM CREDIT_QYSGS.T_QYSGS_FRXZCF T 
  WHERE T.RECID NOT IN (SELECT RECID FROM T_NJ_SGK_CFXX);
  COMMIT;
  --自然人
  INSERT INTO T_NJ_SGK_GRXZXK SELECT * FROM CREDIT_GRSGS.T_GRSGS_GRXZXK T 
  WHERE T.RECID NOT IN (SELECT RECID FROM T_NJ_SGK_GRXZXK);
  COMMIT;
  INSERT INTO T_NJ_SGK_GRCFXX SELECT * FROM CREDIT_GRSGS.T_GRSGS_GRXZCF T 
  WHERE T.RECID NOT IN (SELECT RECID FROM T_NJ_SGK_GRCFXX);
  COMMIT;
  
  --更新到报送表
  INSERT INTO T_NJ_SGK_CFXX2(irecid, datasetid, qyid, createtime, isvalid, invaliddate, isincreased, verified, 
recid, cfwh, ajmc, cfsy, cflb1, cfyj, qymc, shxydm, zzjgdm, cfjg, cfrq, cfjgmc, bz, xzqh, cfcx, fddbrxm, dbrsfzhm, 
qlbm, syfw, sxyzcd, gsjzq, cflb2, qyzch, fkje, msje, deptid) 
  SELECT irecid, datasetid, qyid, createtime, isvalid, invaliddate, isincreased, verified, 
recid, cfwh, ajmc, cfsy, cflb1, cfyj, qymc, shxydm, zzjgdm, cfjg, cfrq, cfjgmc, bz, xzqh, cfcx, fddbrxm, dbrsfzhm, 
qlbm, syfw, sxyzcd, gsjzq, cflb2, qyzch, fkje, msje, deptid FROM T_NJ_SGK_CFXX T WHERE T.RECID NOT IN (SELECT RECID FROM T_NJ_SGK_CFXX2);
  COMMIT;
  
  INSERT INTO T_NJ_SGK_GRCFXX2(irecid, datasetid, grid, createtime, isvalid, invaliddate, isincreased, verified, 
recid, cfwh, ajmc, cfsy, cflb1, cfyj, xm, sfzjhm, cfjg, cfrq, cfjgmc, bz, xzqh, cfcx, qlbm, syfw, sxyzcd, gsjzq, 
cflb2, deptid)
  SELECT irecid, datasetid, grid, createtime, isvalid, invaliddate, isincreased, verified, 
recid, cfwh, ajmc, cfsy, cflb1, cfyj, xm, sfzjhm, cfjg, cfrq, cfjgmc, bz, xzqh, cfcx, qlbm, syfw, sxyzcd, gsjzq, 
cflb2, deptid FROM T_NJ_SGK_GRCFXX T WHERE T.RECID NOT IN (SELECT RECID FROM T_NJ_SGK_GRCFXX2);
  COMMIT;
  
  INSERT INTO T_NJ_SGK_GRXZXK2(irecid,datasetid, grid, createtime, isvalid, invaliddate, isincreased, verified, 
recid, xkwh, xmmc, splb, xknr, xm, sfzjhm, xkrq, xkyxq, xkjg, bz, xzqh, syfw, deptid, qlbm)
  SELECT irecid,datasetid, grid, createtime, isvalid, invaliddate, isincreased, verified, 
recid, xkwh, xmmc, splb, xknr, xm, sfzjhm, xkrq, xkyxq, xkjg, bz, xzqh, syfw, deptid, qlbm FROM T_NJ_SGK_GRXZXK T
  WHERE T.RECID NOT IN (SELECT RECID FROM T_NJ_SGK_GRXZXK2);
  COMMIT;
  
  INSERT INTO T_NJ_SGK_XZXK2(irecid, datasetid, qyid, createtime, isvalid, invaliddate, isincreased, verified, 
recid, xkwh, xmmc, splb, xknr, qymc, shxydm, zzjgdm, xkrq, xkyxq, xkjg, bz, xzqh, fddbrxm, dbrsfzhm, qlbm, 
syfw, qyzch, zl, bgrq, deptid)
  SELECT irecid, datasetid, qyid, createtime, isvalid, invaliddate, isincreased, verified, 
recid, xkwh, xmmc, splb, xknr, qymc, shxydm, zzjgdm, xkrq, xkyxq, xkjg, bz, xzqh, fddbrxm, dbrsfzhm, qlbm, 
syfw, qyzch, zl, bgrq, deptid FROM T_NJ_SGK_XZXK T WHERE T.RECID NOT IN (SELECT RECID FROM T_NJ_SGK_XZXK2);
  COMMIT;
  
end P_SGS_FRESHDATA;
/
