CREATE PROCEDURE P_EXECUTE_ZTK_QYJBXX IS

V_CMDID t_sys_processcommand2.CMDID%TYPE;
V_JOBID INTEGER;
V_SQL   VARCHAR2(1000);
BEGIN

SELECT SEQ_CMDID_KEY.nextval INTO V_CMDID FROM DUAL;

insert into t_sys_processcommand2
  (CMDID,
   DOMAINID,
   MAPPINGID,
   USERID,
   CMDCODE,
   CMD,
   CMDTIME,
   RUNSTATE)
values
  (V_CMDID,
   '000',
   'QYJBXX_C758FF75F00C42B0E040002005172802',
   'admin',
   'ZTSJSC',
   '主题库数据生成',
   sysdate,
   '0');
commit;

  V_SQL := 'begin
         sys.dbms_job.submit(:jobid,
                        what => ''
                        begin P_ZTK_QYJBXX('||V_CMDID||'); end;'',
 			next_date =>SYSDATE);
         commit;
         end;';
  EXECUTE IMMEDIATE V_SQL
    USING OUT V_JOBID;


END;

/
