CREATE procedure              p_qyztbs_qwsy is
begin
  --更新全文索引
  ctx_ddl.sync_index('JOBINDEX');
  ctx_ddl.optimize_index('JOBINDEX', 'full');
end p_qyztbs_qwsy;

/
