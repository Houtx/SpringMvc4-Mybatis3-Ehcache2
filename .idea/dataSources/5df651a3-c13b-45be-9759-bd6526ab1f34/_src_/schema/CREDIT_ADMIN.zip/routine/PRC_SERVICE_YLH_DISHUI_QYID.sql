CREATE procedure              prc_service_ylh_dishui_qyid is

       start_date             DATE := TO_DATE('01/10/2009', 'dd/MM/YYYY');
       end_date               DATE := TO_DATE('01/04/2010', 'dd/MM/YYYY');
       loop_date              DATE;

       v_start_date_year      varchar2(100) := '';
       v_start_date_month     varchar2(100) := '';
       v_end_date_year        varchar2(100) := '';
       v_end_date_month       varchar2(100) := '';

       v_loop_date_year       varchar2(100) := '';
       v_loop_date_month      varchar2(100) := '';

       v_sql_ylh_dishui_current        varchar2(5000) := '';

begin
    dbms_output.put_line('Schema: credit_product,  信用信息应用——遗漏户提示——地税');

    v_start_date_year := extract(year from start_date);
    v_start_date_month := extract(month from start_date);
    v_end_date_year := extract(year from end_date);
    v_end_date_month := extract(month from end_date);
    dbms_output.put_line('start_date: ' || v_start_date_year || '-' || v_start_date_month || '******' ||
                         'end_date: ' || v_end_date_year || '-' || v_end_date_month );

    loop_date := start_date;

    execute immediate 'truncate table SERV_YLH_DISHUI_CURRENT';

    WHILE
        (loop_date <= end_date)
    LOOP

        v_loop_date_year := extract(year from loop_date);
        v_loop_date_month := extract(month from loop_date);

        dbms_output.put_line('loop_date: ' || v_loop_date_year || '-' || v_loop_date_month);

        v_sql_ylh_dishui_current := '
              INSERT INTO SERV_YLH_DISHUI_CURRENT
                    select qyid, qyzch , fddbrxm ,
                           qylxmc , zs , slrq ,
                           djjgmc , recid,
                           TO_DATE(' || '''' || '15-' || v_loop_date_month || '-' || v_loop_date_year || ''''
                                    ||' , ' || '''' || 'dd-mm-yyyy' || '''' || ') as ylh_date
                           from credit_product.T_GONGSHANG_DJXX
                           where  qyzch is not null
                                  and extract(month from slrq) = ' || '''' || v_loop_date_month || '''' ||
              '
                                  and extract(year from slrq) = ' || '''' || v_loop_date_year || '''' ||
              '
                                  and rowid in (
                                      select Max(rowid)
                                             from  (
                                                  select * from credit_product.T_GONGSHANG_DJXX t
                                                          where qyid in (
                                                                 (select qyid
                                                                        from credit_product.T_GONGSHANG_DJXX
                                                                        where extract(month from slrq) = ' || '''' || v_loop_date_month || '''' ||
              '
                                                                              and extract(year from slrq) = ' || '''' || v_loop_date_year || '''' ||
              '
                                                                 )
                                                                 MINUS
                                                                 (select qyid
                                                                        from credit_product.t_dishui_djxx
                                                                        where extract(month from djrq) = ' || '''' || v_loop_date_month || '''' ||
              '
                                                                             and extract(year from djrq) = ' || '''' || v_loop_date_year || '''' ||
              '
                                                                             and ( substr(qylxdm, 1, 3) != ' || '''' || '600' || '''' ||
                                                                                     'or qylxdm is null )
                                                                 )
                                                           )
                                                           and extract(month from slrq) = ' || '''' || v_loop_date_month || '''' ||
              '
                                                          and extract(year from slrq) = ' || '''' || v_loop_date_year || '''' ||
              '
                                                  )
                                                  group by qyzch
                                          ) ';

        --dbms_output.put_line(v_sql_ylh_dishui_current);
        execute immediate v_sql_ylh_dishui_current;
        dbms_output.put_line('*****************');

        loop_date := ADD_MONTHS(loop_date , 1);
    END LOOP;


      commit;
      exception
    when others then
      rollback;
      raise;

end prc_service_ylh_dishui_qyid;

/
