CREATE FUNCTION              FN_TGSJX(v_deptid IN VARCHAR2,v_attribute IN VARCHAR2)
  RETURN number IS
  v_counts number:=0;
  v_notnull number:=0;
  v_null number:=0;
  v_notnullz number:=0;
  v_nullz number:=0;
  SQLSTR varchar2(8000);
  statCount         number := 0;
  --获取所有的归集字段
  CURSOR CURMETACOLUMN(p_attribute VARCHAR2,p_deptid VARCHAR2) IS
    SELECT TM.DEPTID, TM.TABLENAME, TC.*
      FROM T_META_COLUMN TC, T_META_TABLE TM, T_SYS_DATAFILEINFO TS
     WHERE TC.MESSAGEID = TM.MESSAGEID
       AND TS.MESSAGEID = TM.MESSAGEID
       AND TC.Isuse = 'Y'
       AND TM.DEPTID=p_deptid
       AND TC.ATTRIBUTE=p_attribute
       ORDER BY TM.DEPTID, TC.MESSAGEID;

   begin
 FOR RD IN CURMETACOLUMN(v_attribute,v_deptid) LOOP
   ----为空的
    /*SQLSTR := 'SELECT \*+ NO_CPU_COSTING *\ COUNT(*) FROM T_DATAPROCESS TP, ' ||
              RD.TABLENAME || '_RAW T' ||
              ' WHERE  T.RECID = TP.RECID  AND T.' || RD.COLUMNNAME ||
              ' IS NULL ';*/
    SQLSTR := 'SELECT /*+ NO_CPU_COSTING */ COUNT(*) FROM ' ||
              RD.TABLENAME || '_RAW T' ||
              ' WHERE  T.' || RD.COLUMNNAME ||
              ' IS NULL ';
    EXECUTE IMMEDIATE SQLSTR
      INTO v_null;
      v_nullz:=v_nullz+v_null;
   END LOOP;
   FOR RD IN CURMETACOLUMN(v_attribute,v_deptid) LOOP
   ---不为空
    /*SQLSTR := 'SELECT \*+ NO_CPU_COSTING *\ COUNT(*) FROM T_DATAPROCESS TP, ' ||
              RD.TABLENAME || '_RAW T' ||
              ' WHERE  T.RECID = TP.RECID  AND T.' || RD.COLUMNNAME ||
              ' IS NOT NULL ';*/
    SQLSTR := 'SELECT /*+ NO_CPU_COSTING */ COUNT(*) FROM ' ||
              RD.TABLENAME || '_RAW T' ||
              ' WHERE  T.' || RD.COLUMNNAME ||
              ' IS NOT NULL ';
    EXECUTE IMMEDIATE SQLSTR
      INTO v_notnull;
     v_notnullz:=v_notnullz+v_notnull;
   END LOOP;
   v_counts:=v_nullz+v_notnull;
  case when  v_counts=0 then statCount:=0;
    else statCount:=v_nullz/v_counts;
      end case;
 return statCount;
END FN_TGSJX;

/
