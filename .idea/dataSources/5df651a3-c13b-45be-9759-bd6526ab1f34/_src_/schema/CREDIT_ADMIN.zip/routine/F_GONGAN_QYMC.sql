CREATE FUNCTION              F_GONGAN_QYMC (VSTR VARCHAR2) RETURN VARCHAR2  --公安处罚信息被处罚当事人提取企业名称
IS
  QYMC_tmp varchar2(4000):=vstr;
BEGIN
  IF substrb(QYMC_tmp,1,1) in (':' , '(' , '.' , '*') THEN
    QYMC_tmp:=substrb(QYMC_tmp,2);
  END IF;

  IF substrb(QYMC_tmp,1,2) in ('：' , '（' , '，') THEN
    QYMC_tmp:=substrb(QYMC_tmp,3);
  END IF;

  IF QYMC_tmp like '%1' or QYMC_tmp like '%*' THEN
    QYMC_tmp:=substrb(QYMC_tmp,1,lengthb(QYMC_tmp)-1);
  END IF;

  IF QYMC_tmp like '% %' THEN
    QYMC_tmp:=replace(QYMC_tmp,' ',':');
  END IF;

  IF QYMC_tmp like '%、%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'、',':');
  END IF;

  IF QYMC_tmp like '%。%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'。',':');
  END IF;

  IF QYMC_tmp like '%.%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'.',':');
  END IF;

  IF QYMC_tmp like '%/%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'/',':');
  END IF;

  IF QYMC_tmp like '%\%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'\',':');
  END IF;

  IF QYMC_tmp like '%　%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'　',':') ;
  END IF;

  IF QYMC_tmp like '%  %' THEN
    QYMC_tmp:=replace(QYMC_tmp,'  ',':') ;
  END IF;

  IF QYMC_tmp like '%（%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'（',':');
  END IF;

  IF QYMC_tmp like '%(%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'(',':');
  END IF;

  IF QYMC_tmp like '%）%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'）',':');
  END IF;

  IF QYMC_tmp like '%)%' THEN
    QYMC_tmp:=replace(QYMC_tmp,')',':');
  END IF;

  IF QYMC_tmp like '%{%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'{',':');
  END IF;

  IF QYMC_tmp like '%，%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'，',':');
  END IF;

  IF QYMC_tmp like '%,%' THEN
    QYMC_tmp:=replace(QYMC_tmp,',',':');
  END IF;

  IF QYMC_tmp like '%；%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'；',':');
  END IF;

  IF QYMC_tmp like '%;%' THEN
    QYMC_tmp:=replace(QYMC_tmp,';',':');
  END IF;

  IF QYMC_tmp like '%【%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'【',':');
  END IF;

  IF QYMC_tmp like '%[%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'[',':');
  END IF;

  IF QYMC_tmp like '%：%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'：',':');
  END IF;

  IF QYMC_tmp like '%`%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'`',':');
  END IF;

  IF QYMC_tmp like '%〔%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'〔',':');
  END IF;

  IF QYMC_tmp like '%所经营的%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'所经营的',':');
  END IF;

  IF QYMC_tmp like '%投资经营的%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'投资经营的',':');
  END IF;

  IF QYMC_tmp like '%承包经营的%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'承包经营的',':');
  END IF;

  IF QYMC_tmp like '%经营的%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'经营的',':');
  END IF;

  IF QYMC_tmp like '%位于%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'位于',':');
  END IF;

  IF QYMC_tmp like '%地址%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'地址',':');
  END IF;

  IF QYMC_tmp like '%法人代表%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'法人代表',':');
  END IF;

  IF QYMC_tmp like '%法定代表人%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'法定代表人',':');
  END IF;

  IF QYMC_tmp like '%消防安全责任人%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'消防安全责任人',':');
  END IF;

  IF QYMC_tmp like '%消防安全负责人%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'消防安全负责人',':');
  END IF;

  IF QYMC_tmp like '%安全管理责任人%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'安全管理责任人',':');
  END IF;

  IF QYMC_tmp like '%责任人%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'责任人',':');
  END IF;

  IF QYMC_tmp like '%负责人%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'负责人',':');
  END IF;

  IF QYMC_tmp like '%经营管理人%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'经营管理人',':');
  END IF;

  --未经消防验收擅自使用, 未经消防安全检查擅自开业
  IF QYMC_tmp like '%未经消防%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'未经消防',':');
  END IF;

  --不及时消除火灾隐患
  IF QYMC_tmp like '%不及时消除火灾隐患%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'不及时消除火灾隐患',':');
  END IF;

  --未经审核擅自施工
  IF QYMC_tmp like '%未经审核擅自施工%' THEN
    QYMC_tmp:=replace(QYMC_tmp,'未经审核擅自施工',':');
  END IF;

  IF QYMC_tmp like '%:%' THEN
    QYMC_tmp:=substrb(QYMC_tmp,1,instrb(QYMC_tmp,':',1)-1);
  END IF;

  IF lengthb(QYMC_tmp)<9 OR lengthb(QYMC_tmp)=length(QYMC_tmp) OR QYMC_tmp LIKE '%年%月%' OR QYMC_tmp LIKE '%出生%' OR QYMC_tmp LIKE '%岁单位%'
     OR QYMC_tmp LIKE '%岁%住址%' OR QYMC_tmp LIKE '%身份证%' OR QYMC_tmp LIKE '%32%' OR QYMC_tmp LIKE '%13%' then
    RETURN NULL;
  ELSE
    RETURN QYMC_tmp;
  END IF;
END;

/
