CREATE PROCEDURE P_ZTK_GRJBXX(CMDID IN INTEGER) AUTHID CURRENT_USER AS
  V_DATASETID  VARCHAR2(50);
  V_INSALLSQL  VARCHAR2(500);
  V_INSFILESQL VARCHAR2(500);
  V_STARTTIME  DATE;
  V_MESSAGEID  VARCHAR2(50) := '7F58BB371DED48A79713301239C4AE65';
  V_MAPPINGID  VARCHAR2(50) := 'GRJBXX_7fe84f71416948259ac585fe5d3cc513';
  CURSOR C_ALLDATA(PGRID NUMBER) IS
  SELECT GRID,SFZJHM,SJLY FROM T_GRZTBS WHERE GRID>PGRID;  
  V_COUNT        INTEGER := 0; --计数器
  V_DATE         VARCHAR2(50);
  V_CSRQ         DATE;
  V_UPDATERESULT BOOLEAN;
  --V_COUNT
  ROW_GRZTBS C_ALLDATA%ROWTYPE;
  V_SFZJHM   VARCHAR2(50);
  V_JD       T_XINXI_HJRKXX.JD%TYPE;
  V_PCS      T_XINXI_HJRKXX.PCS%TYPE;
  V_BDSJ     T_XINXI_HJRKXX.BDRQ%TYPE;
  V_FZRQ     T_XINXI_HJRKXX.FZRQ%TYPE;
  V_ZJYXQX   T_XINXI_HJRKXX.YXQX%TYPE;
  V_FZJG     T_XINXI_HJRKXX.FZJGMC%TYPE;
  V_XB       VARCHAR2(10);
  V_MZ       VARCHAR2(100);
  V_MZCODE   VARCHAR2(10);
  V_SSQX     VARCHAR2(20);
  V_SSQXNAME VARCHAR2(30);
  V_GRID     NUMBER;
  V_MAXGRID  NUMBER;
  V_SJLY     VARCHAR2(100); 
  V_ZXRQ     DATE; 
  V_FZRQSTR  VARCHAR2(20);
  V_ZXRQSTR  VARCHAR2(20);  
BEGIN
  --判断是否存在这个CMDID
  DECLARE
    V_TMP VARCHAR2(1);

  BEGIN
    SELECT '1'
      INTO V_TMP
      FROM T_SYS_PROCESSCOMMAND2 T
     WHERE T.CMDID = CMDID
       AND DOMAINID = '011'
       and rownum = 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('命令无效');
      V_UPDATERESULT := F_UPDATECMDSTATE(CMDID, '2', 'N');
      IF NOT V_UPDATERESULT THEN
        --更新状态失败，对后台有影响
        P_WRITELOG(CMDID, '命令执行状态更新失败。');
      END IF;
      RETURN;
  END;
  V_STARTTIME := SYSDATE;
  P_WRITELOG(CMDID, '开始基本信息数据生成');

  V_MAXGRID :=0;
  BEGIN
    SELECT MAX(GRID) INTO V_MAXGRID FROM CREDIT_GRJBXX.T_GRJBXX;
    IF V_MAXGRID IS NULL THEN
      V_MAXGRID:=0;
    END IF;
  EXCEPTION
    WHEN OTHERS THEN
      V_MAXGRID := 0;
  END;
  /*P_WRITELOG(CMDID, '清空数据');
  EXECUTE IMMEDIATE 'delete from credit_grjbxx.T_GRJBXX t';
  COMMIT;
  P_WRITELOG(CMDID, '清空数据完成');
  */
  P_WRITELOG(CMDID, '插入新数据:'||V_MAXGRID);
  SELECT SYS_GUID() INTO V_DATASETID FROM DUAL;
  V_INSALLSQL := 'insert into credit_grjbxx.T_GRJBXX(datasetid,GRid,irecid,createtime,' ||
                 'isincreased,verified,sfzjhm,xm,zjlx,UPDATETIME) ' ||
                 'select ''' || V_DATASETID ||
                 ''' datasetid,grid,sys_guid(),sysdate,''Y'',''Y'',sfzjhm,' ||
                 'xm,SFZJLXMC,UPDATETIME from t_grztbs t WHERE t.GRID>'||V_MAXGRID;

  EXECUTE IMMEDIATE V_INSALLSQL;
  COMMIT;
  P_WRITELOG(CMDID, '插入新数据完成');


  P_WRITELOG(CMDID, '开始更新数据');
  /*
  update credit_grjbxx.T_GRJBXX t
     set xb = (case when length(t.sfzjhm) = 18 then decode((substr(t.sfzjhm, 17, 1) / 2), 0, '女', '男') when length(t.sfzjhm) = 15 then decode((substr(t.sfzjhm, 15, 1) / 2), 0, '女', '男') else '未知' end)
   where t.SFZJMC in ('身份证', '大陆身份证', '居民身份证');
  commit;
  */

  OPEN C_ALLDATA(V_MAXGRID);
  LOOP
    FETCH C_ALLDATA INTO ROW_GRZTBS;
    EXIT WHEN C_ALLDATA%NOTFOUND;
    V_SFZJHM := ROW_GRZTBS.SFZJHM;
    V_GRID := ROW_GRZTBS.GRID;
    V_SJLY := ROW_GRZTBS.SJLY;
    V_XB := '';
    --[出生日期校验]--
    if length(ROW_GRZTBS.SFZJHM) = 15 then
      v_date := '19' || substr(V_SFZJHM, 7, 6);
      V_XB := substr(V_SFZJHM, 15, 1);
    elsif length(V_SFZJHM) = 18 then
      v_date := substr(ROW_GRZTBS.SFZJHM, 7, 8);
      V_XB := substr(V_SFZJHM, 17, 1);
    end if;
    if V_XB IN ('1','3','5','7','9') THEN
       V_XB := '男';
    ELSE
       V_XB := '女';
    END if;
    if IsDate(v_date) then
      --return -2;
      --P_WRITELOG(CMDID,v_date);
      V_CSRQ := to_date(v_date, 'yyyymmdd');      
    else
      V_CSRQ := NULL;
    end if;
    V_JD := NULL;
    V_PCS := NULL;
    V_BDSJ := NULL;
    V_FZRQ := NULL;
    V_ZJYXQX := NULL;
    V_FZJG := NULL;
    V_MZ := NULL;
    V_SSQX := NULL;
    V_ZXRQ := NULL;
    IF V_SJLY='T_XINXI_HJRKXX' THEN
      V_SJLY := '1';
    --常驻人口
      BEGIN
        SELECT JD,PCS,BDRQ,FZRQ,YXQX,FZJGMC,MZ,SSQX INTO V_JD,V_PCS,V_BDSJ,V_FZRQ,V_ZJYXQX,V_FZJG,V_MZCODE,V_SSQX FROM T_XINXI_HJRKXX T WHERE T.GRID=V_GRID AND ROWNUM=1;
      EXCEPTION
        WHEN OTHERS THEN
          --P_WRITELOG(CMDID, '开始更新数据');
           V_JD := NULL;
      END;
    ELSIF V_SJLY='T_NJ_GONGAN_ZZRK' THEN
      V_SJLY := '2';
      --暂住人口
      BEGIN
        SELECT MZ,XZZ,FZRQ,ZXRQ INTO V_MZCODE,V_JD,V_FZRQSTR,V_ZXRQSTR FROM 
        (SELECT MZ,XZZ,FZRQ,ZXRQ FROM T_NJ_GONGAN_ZZRK T WHERE T.GRID=V_GRID ORDER BY ZXRQ DESC NULLS LAST)WHERE ROWNUM=1;
      EXCEPTION
          WHEN OTHERS THEN
          --P_WRITELOG(CMDID, '开始更新数据');
           V_JD := NULL;
      END;
      IF V_FZRQSTR IS NOT NULL AND ISDATE(V_FZRQSTR) THEN
        BEGIN
          V_FZRQ := to_date(V_FZRQSTR, 'yyyymmdd'); 
        EXCEPTION 
          WHEN OTHERS THEN
            V_FZRQ := NULL;
        END;
      END IF;
      IF V_ZXRQSTR IS NOT NULL AND ISDATE(V_ZXRQSTR) THEN
        BEGIN
          V_ZXRQ := TO_DATE(V_ZXRQSTR,'yyyymmdd');
        EXCEPTION
          WHEN OTHERS THEN
            V_ZXRQ := NULL;
        END;
      END IF;
    ELSE
      --TODO,其他数据来源   
      V_SJLY := '0';
    END IF;
    IF V_MZCODE='01' THEN
      V_MZ:= '汉族';
    ELSE
      BEGIN
        SELECT VALUE INTO V_MZ FROM T_DICT_MZ T WHERE T.CODE=V_MZCODE;
      EXCEPTION
        WHEN OTHERS THEN
          V_MZ := V_MZCODE;
      END;
    END IF;
    
    IF V_ZJYXQX='1' THEN
       V_ZJYXQX:='10年';
    ELSIF V_ZJYXQX='2' THEN
       V_ZJYXQX:='20年';
    ELSIF V_ZJYXQX='3' THEN
       V_ZJYXQX:='长期有效';
    ELSE 
       V_ZJYXQX:='其他时效';
    END IF;
    
    --V_SSQXNAME := '南京市';
    V_SSQXNAME := F_GETXZQHNAME(V_SSQX);
    
    --P_WRITELOG(CMDID,V_JD);
    --P_WRITELOG(CMDID,V_PCS);
    --P_WRITELOG(CMDID,V_ZJYXQX);
    UPDATE CREDIT_GRJBXX.T_GRJBXX T
    SET T.XB = V_XB,
        T.CSRQ = V_CSRQ,
        T.JD = V_JD,
        T.PCS = V_PCS,
        T.BDSJ = V_BDSJ,
        T.FZRQ = V_FZRQ,
        T.ZJYXQX = V_ZJYXQX,
        T.FZJG = V_FZJG,
        T.MZ = V_MZ,
        T.SSQX = V_SSQXNAME,
        T.SJLY = V_SJLY,
        T.ZXRQ = V_ZXRQ
    WHERE T.GRID = V_GRID;
    
    V_COUNT := V_COUNT + 1;
    IF MOD(V_COUNT, 1000) = 0 THEN
      --插入进度日志
      P_WRITELOG(CMDID, '已生成' || V_COUNT || '条记录');
    END IF;
    IF MOD(V_COUNT, 10000) = 0 THEN
      --提交
      COMMIT;
    END IF;
  END LOOP;
  COMMIT;
  CLOSE C_ALLDATA;
  P_WRITELOG(CMDID, '更新完成');
  --

  ----计算总记录数
  select count(*) into V_COUNT from credit_grjbxx.T_GRJBXX;
  BEGIN
    SELECT MESSAGEID,MAPPINGID
      INTO V_MESSAGEID,V_MAPPINGID
      FROM T_ZTK_MAPPING
     WHERE DOMAINID = '011'
       AND ROWNUM = 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_WRITELOG(CMDID, '警告：没有找到信息类ID');
  END;
  P_WRITELOG(CMDID, '更新数据生成表');
  V_INSFILESQL := 'INSERT INTO T_ZTK_FILE(CMDID,DATASETID,MAPPINGID,DOMAINID,MESSAGEID,STARTTIME,ENDTIME,RECCOUNT,ISQUANJI) VALUES(' ||
                  ':1,:2,:3,''011'',:4,:5,SYSDATE,:6,''Y'')';
  BEGIN
    EXECUTE IMMEDIATE V_INSFILESQL
      USING CMDID, V_DATASETID, V_MAPPINGID, V_MESSAGEID, V_STARTTIME, V_COUNT;
  EXCEPTION
    WHEN OTHERS THEN
      P_WRITELOG(CMDID, '插入数据生成表记录时发生错误。' || SQLERRM);
  END;
  P_WRITELOG(CMDID, '更新完毕。存储过程执行完毕。');
  V_UPDATERESULT := F_UPDATECMDSTATE(CMDID, '2', 'Y');
  IF NOT V_UPDATERESULT THEN
    --更新状态失败，对后台有影响
    P_WRITELOG(CMDID, '命令执行状态更新失败。');
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    IF C_ALLDATA%ISOPEN THEN
      CLOSE C_ALLDATA;
    END IF;
    V_UPDATERESULT := F_UPDATECMDSTATE(CMDID, '2', 'N');
    IF NOT V_UPDATERESULT THEN
      --更新状态失败，对后台有影响
      P_WRITELOG(CMDID, '命令执行状态更新失败。');
    END IF;
    P_WRITELOG(CMDID, '数据生成失败，发生错误：' || SQLERRM);
END;
/
