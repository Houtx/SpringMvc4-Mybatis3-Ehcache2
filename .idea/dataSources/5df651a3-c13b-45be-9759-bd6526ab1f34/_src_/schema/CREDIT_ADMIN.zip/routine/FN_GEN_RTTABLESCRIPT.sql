CREATE function              FN_GEN_RTTABLESCRIPT(v_messageid in varchar2)
RETURN varchar2 IS
--根据T_META_TABLE产生credit_PRODUCT用户中的实时表建表脚本
   var_sql    varchar2(4000):='';
   var_deptId  t_Meta_Table.DEPTID%TYPE;
   var_shortName  t_Meta_Table.MESSAGEABBR%TYPE;
   var_columnsql  varchar2(4000):='';
   var_isNull varchar2(200):='';
   CURSOR cur_columns IS SELECT * FROM T_META_COLUMN WHERE MESSAGEID=v_messageid order by orderid asc;
   var_table varchar2(200):='';
   var_nopostfixtable varchar2(200):='';
   row_column cur_columns%ROWTYPE;
begin

    select TABLENAME,DEPTID,MESSAGEABBR INTO  var_table,var_deptId,var_shortName from t_Meta_Table  t where t.MESSAGEID=v_messageid;
     var_nopostfixtable:=var_table;
     var_table:=var_table||'';

     var_sql:='drop table '||var_table||' cascade constraints;'|| chr(9)||chr(13);
     var_sql :=var_sql||'create table '||var_table|| chr(9)||chr(13)||'(';
     var_sql :=var_sql||chr(9)||chr(13)||'QYID'||chr(9)||chr(9)||chr(9)||chr(9)||' NUMBER,' ||chr(9)||chr(13);
     var_sql :=var_sql||'RECID'||chr(9)||chr(9)||chr(9)||chr(9)||' VARCHAR2(50) not null,' ||chr(9)||chr(13);

     open cur_columns;
          Loop
             Fetch cur_columns    Into row_column;
             exit when cur_columns%notfound;

     IF(row_column.isnull='N') THEN
          var_isNull:=' not null';
     else
          var_isNull:='';
     END IF;

     IF(row_column.Datatype='D' ) THEN
          var_columnsql:=row_column.COLUMNNAME ||chr(9)||chr(9)||chr(9)||chr(9)||'DATE '||var_isNull||','||chr(9)||chr(13);
     ELSif(row_column.Datatype='N' )THEN
          var_columnsql:=row_column.COLUMNNAME ||chr(9)||chr(9)||chr(9)||chr(9)||'NUMBER '||var_isNull||','||chr(9)||chr(13);
     ELSE--默认都是字符串
           var_columnsql:=row_column.COLUMNNAME ||chr(9)||chr(9)||chr(9)||chr(9)||' VARCHAR2('||row_column.length||')'||var_isNull||','||chr(9)||chr(13);
     END IF;
     var_sql :=var_sql||var_columnsql;
     var_columnsql:='';
     end loop;
    close cur_columns; --关闭游标
        --去除最后一个逗号
    var_sql:=substr(var_sql,1,instr(var_sql,',',-1)-1);
    var_sql :=var_sql ||chr(9)||chr(13) ||');'||chr(9)||chr(13);
    var_sql :=var_sql|| 'alter table '||var_table|| '  add constraint PK_'||var_deptId||'_'||var_shortName||' primary key (RECID);'||chr(9)||chr(13);
    var_sql :=var_sql||'create index CREDIT_PRODUCT.'||var_nopostfixtable||'_QYID on CREDIT_PRODUCT.'||var_table||'(QYID)'||';'||chr(9)||chr(13);
    var_sql:=var_sql||'grant select, insert, update, delete, references, alter, index on CREDIT_PRODUCT.'||var_table||' to CREDIT_ADMIN;';


return var_sql;
end FN_GEN_RTTABLESCRIPT;

/
