CREATE procedure P_BATCH_SETCOLUMNRULE is
begin
  --按照默认规则对新增的表插入规则
  --社会法人行政许可信息
  INSERT INTO T_META_COLUMNRULE
  select m.ruleversionid,
       t.ruleid,
       m.messageid,
       T.tableversion,
       replace(columnid, t.messageid, m.messageid) columnid,
       sysdate createtime,
       t.orderid,
       replace(columnids, t.messageid, m.messageid) columnids,
       T.ISALLOWCOLUMNIDPASS,
       T.ISALLOWCOLUMNIDSPASS,
       T.COLUMNPARAMS,
       T.TABLEPARAMS,
       T.ISCOLUMNUSE,
       T.ISTABLEUSE,
       T.COLUMNPARAMERRORDESC,
       T.TABLEPARAMERRORDESC,
       T.RULECODE,
       T.RULECODENAME
  from t_meta_columnrule t,
       t_meta_ruleversion f,
       t_meta_table n,
       (select *
          from t_meta_ruleversion a
         where a.messageid in
               (select messageid
                  from t_meta_table
                 where messagename = '社会法人行政许可信息')
           and a.isenable = 'Y'
           and a.ruleversionid not in
               (select rulevesion from t_meta_columnrule)) m
 where T.RULEVESION = F.RULEVERSIONID
   AND F.ISENABLE = 'Y'
   AND t.messageid=n.messageid
   and n.deptid='NJ_ANJIAN' and n.messagename='社会法人行政许可信息';
   COMMIT;
   --社会法人行政处罚信息
   INSERT INTO T_META_COLUMNRULE
   select m.ruleversionid,
       t.ruleid,
       m.messageid,
       T.tableversion,
       replace(columnid, t.messageid, m.messageid) columnid,
       sysdate createtime,
       t.orderid,
       replace(columnids, t.messageid, m.messageid) columnids,
       T.ISALLOWCOLUMNIDPASS,
       T.ISALLOWCOLUMNIDSPASS,
       T.COLUMNPARAMS,
       T.TABLEPARAMS,
       T.ISCOLUMNUSE,
       T.ISTABLEUSE,
       T.COLUMNPARAMERRORDESC,
       T.TABLEPARAMERRORDESC,
       T.RULECODE,
       T.RULECODENAME
  from t_meta_columnrule t,
       t_meta_ruleversion f,
       t_meta_table n,
       (select *
          from t_meta_ruleversion a
         where a.messageid in
               (select messageid
                  from t_meta_table
                 where messagename = '社会法人行政处罚信息')
           and a.isenable = 'Y'
           and a.ruleversionid not in
               (select rulevesion from t_meta_columnrule)) m
 where T.RULEVESION = F.RULEVERSIONID
   AND F.ISENABLE = 'Y'
   AND t.messageid=n.messageid
   and n.deptid='NJ_ANJIAN' and n.messagename='社会法人行政处罚信息';
   COMMIT;
   --个人行政许可信息
   INSERT INTO T_META_COLUMNRULE
   select m.ruleversionid,
       t.ruleid,
       m.messageid,
       T.tableversion,
       replace(columnid, t.messageid, m.messageid) columnid,
       sysdate createtime,
       t.orderid,
       replace(columnids, t.messageid, m.messageid) columnids,
       T.ISALLOWCOLUMNIDPASS,
       T.ISALLOWCOLUMNIDSPASS,
       T.COLUMNPARAMS,
       T.TABLEPARAMS,
       T.ISCOLUMNUSE,
       T.ISTABLEUSE,
       T.COLUMNPARAMERRORDESC,
       T.TABLEPARAMERRORDESC,
       T.RULECODE,
       T.RULECODENAME
  from t_meta_columnrule t,
       t_meta_ruleversion f,
       t_meta_table n,
       (select *
          from t_meta_ruleversion a
         where a.messageid in
               (select messageid
                  from t_meta_table
                 where messagename = '个人行政许可信息')
           and a.isenable = 'Y'
           and a.ruleversionid not in
               (select rulevesion from t_meta_columnrule)) m
 where T.RULEVESION = F.RULEVERSIONID
   AND F.ISENABLE = 'Y'
   AND t.messageid=n.messageid
   and n.deptid='NJ_ANJIAN' and n.messagename='个人行政许可信息';
   COMMIT;
   --个人行政处罚信息
   INSERT INTO T_META_COLUMNRULE
   select m.ruleversionid,
       t.ruleid,
       m.messageid,
       T.tableversion,
       replace(columnid, t.messageid, m.messageid) columnid,
       sysdate createtime,
       t.orderid,
       replace(columnids, t.messageid, m.messageid) columnids,
       T.ISALLOWCOLUMNIDPASS,
       T.ISALLOWCOLUMNIDSPASS,
       T.COLUMNPARAMS,
       T.TABLEPARAMS,
       T.ISCOLUMNUSE,
       T.ISTABLEUSE,
       T.COLUMNPARAMERRORDESC,
       T.TABLEPARAMERRORDESC,
       T.RULECODE,
       T.RULECODENAME
  from t_meta_columnrule t,
       t_meta_ruleversion f,
       t_meta_table n,
       (select *
          from t_meta_ruleversion a
         where a.messageid in
               (select messageid
                  from t_meta_table
                 where messagename = '个人行政处罚信息')
           and a.isenable = 'Y'
           and a.ruleversionid not in
               (select rulevesion from t_meta_columnrule)) m
 where T.RULEVESION = F.RULEVERSIONID
   AND F.ISENABLE = 'Y'
   AND t.messageid=n.messageid
   and n.deptid='NJ_ANJIAN' and n.messagename='个人行政处罚信息';
   COMMIT;
   
   --插入双公示字典表
   INSERT INTO T_DICT_DEPT select DEPTABBR,F.DICTNAME,F.CODE,F.VALUE from t_sys_department t,T_DICT_SGS F 
   where (t.deptABBR,F.DICTNAME) not in (select distinct deptid,DICTNAME from t_dict_dept);
   COMMIT;
   
   --其他11张表信息
   INSERT INTO T_META_COLUMNRULE
   select m.ruleversionid,
       t.ruleid,
       m.messageid,
       T.tableversion,
       replace(columnid, t.messageid, m.messageid) columnid,
       sysdate createtime,
       t.orderid,
       replace(columnids, t.messageid, m.messageid) columnids,
       T.ISALLOWCOLUMNIDPASS,
       T.ISALLOWCOLUMNIDSPASS,
       T.COLUMNPARAMS,
       T.TABLEPARAMS,
       T.ISCOLUMNUSE,
       T.ISTABLEUSE,
       T.COLUMNPARAMERRORDESC,
       T.TABLEPARAMERRORDESC,
       T.RULECODE,
       T.RULECODENAME
  from t_meta_columnrule_11 t,
       t_meta_table n,
       (select RULEVERSIONID,MESSAGEID
          from t_meta_ruleversion a
         where a.messageid in
               (select messageid
                  from t_meta_table
                 where messagename in (select distinct messagename from t_meta_columnrule_11))
           and a.isenable = 'Y'
           and a.ruleversionid not in
               (select rulevesion from t_meta_columnrule)
           and a.deptid!='SX') m
   where t.messagename=n.messagename and n.messageid=m.messageid;
    commit;  
    
end P_BATCH_SETCOLUMNRULE;
/
