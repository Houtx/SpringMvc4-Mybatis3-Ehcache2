CREATE procedure P_BATCH_SETUSERMESSAGE is
begin
  insert into t_meta_usermessage
select m.username,f.messageid from t_sys_user m,t_sys_userinfo t,t_meta_table f,t_sys_department a  where f.deptid=a.deptabbr and t.deptid not in ('XINXI','SX') AND m.userid=t.id and t.deptid=a.deptid and (m.username,f.messageid) not in
(select userid,messageid from t_meta_usermessage);

commit;
end P_BATCH_SETUSERMESSAGE;
/
