CREATE function              FN_GEN_RAWTABLESCRIPT(v_messageid in varchar2)
RETURN varchar2 IS
--根据T_META_TABLE产生原始库中的建表的表
   var_sql    varchar2(4000):='';
   var_deptId  t_Meta_Table.DEPTID%TYPE;
   var_shortName  t_Meta_Table.MESSAGEABBR%TYPE;
   CURSOR cur_columns IS SELECT * FROM T_META_COLUMN WHERE MESSAGEID=v_messageid order by orderid asc;
   var_table varchar2(200):='';
   row_column cur_columns%ROWTYPE;
begin

    select TABLENAME,DEPTID,MESSAGEABBR INTO  var_table,var_deptId,var_shortName from t_Meta_Table  t where t.MESSAGEID=v_messageid;
     var_sql:=' drop table '||var_table||' cascade constraints;'|| chr(9)||chr(13);
     var_sql :=var_sql||'create table '||var_table|| chr(9)||chr(13)||'(';
     var_sql :=var_sql||chr(9)||chr(13)||'RECID'||chr(9)||chr(9)||chr(9)||chr(9)||' VARCHAR2(50) not null,' ||chr(9)||chr(13);
     open cur_columns;
          Loop
             Fetch cur_columns    Into row_column;
             exit when cur_columns%notfound;
     var_sql :=var_sql||row_column.COLUMNNAME ||chr(9)||chr(9)||chr(9)||chr(9)||' VARCHAR2(4000),'||chr(9)||chr(13);
     end loop;
    close cur_columns; --关闭游标
        --去除最后一个逗号
    var_sql:=substr(var_sql,1,instr(var_sql,',',-1)-1);
    var_sql :=var_sql ||chr(9)||chr(13) ||');'||chr(9)||chr(13);
    var_sql :=var_sql|| 'alter table '||var_table|| '  add constraint PK_'||var_deptId||'_'||var_shortName||' primary key (RECID);'||chr(9)||chr(13);

     var_sql:=var_sql||'grant select, insert, update, delete, references, alter, index  on CREDIT_GATHER.'||var_table||' to CREDIT_CENTER;'||chr(9)||chr(13);
    var_sql:=var_sql||'grant select, insert, update, delete, references, alter, index on CREDIT_GATHER.'||var_table||' to CREDIT_ADMIN;';


return var_sql;
end FN_GEN_RAWTABLESCRIPT;

/
