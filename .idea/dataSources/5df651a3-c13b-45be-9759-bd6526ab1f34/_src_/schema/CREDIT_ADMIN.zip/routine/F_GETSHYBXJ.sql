CREATE function F_GETSHYBXJ(org in number) return number is
  Result number;
  v_org number(10,2);
begin
  v_org := org;
  if v_org =0.00 then
    Result := 0.00;
  elsif mod(v_org*100,3)=0 then
    Result := v_org*2/3;
  else
    Result := (v_org+0.01)*2/3;
  end if;
  return(Result);
end F_GETSHYBXJ;
/
