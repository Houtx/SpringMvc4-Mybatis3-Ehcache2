CREATE procedure P_BATCH_SETASSOPARA is
begin
  --针对15张表的关联策略设置
  insert into t_meta_assopara (MESSAGEID, TABLENAME, ASSOMETHOD, KEYFIELD, CMPFIELD, 
  FMTTABLE, RTTABLE, HISTABLE, ISUSE,ORDERID, ASSSTRATEGY, ASSORDERID, INSERTTIME, UPDATETIME)
  select messageid,tablename,2,null,'CREATETIME_DEPT',t.tablename||'_FMT',t.tablename,t.tablename||'_HIS','Y',t.orderid,
  '111;110;011;010',999,sysdate,sysdate from t_meta_table t where t.messageid not in (select messageid from t_meta_assopara)
   and t.messagename in ('社会法人行政许可信息','社会法人行政处罚信息');
  COMMIT;

  insert into t_meta_assopara (MESSAGEID, TABLENAME, ASSOMETHOD, KEYFIELD, CMPFIELD,
  FMTTABLE, RTTABLE, HISTABLE, ISUSE, ORDERID, ASSSTRATEGY, ASSORDERID, INSERTTIME, UPDATETIME)
  select messageid,tablename,2,null,'CREATETIME_DEPT',t.tablename||'_FMT',t.tablename,t.tablename||'_HIS',
  'Y',t.orderid,'0110',999,sysdate,sysdate from t_meta_table t 
  where t.messageid not in (select messageid from t_meta_assopara) and t.messagename in ('个人行政许可信息','个人行政处罚信息');
  COMMIT;

  --其他11张表
  insert into t_meta_assopara (MESSAGEID, TABLENAME, ASSOMETHOD, KEYFIELD, CMPFIELD, FMTTABLE, RTTABLE, HISTABLE, ISUSE, ORDERID, ASSSTRATEGY, ASSORDERID, INSERTTIME, UPDATETIME)
  select messageid,tablename,2,null,'CREATETIME_DEPT',t.tablename||'_FMT',t.tablename,t.tablename||'_HIS','Y',t.orderid,'111;110;011;010',999,sysdate,sysdate from t_meta_table t where t.messageid not in (select messageid from t_meta_assopara) and 
  messagename in (select distinct messagename from t_meta_columnrule_11);
  COMMIT;
  
end P_BATCH_SETASSOPARA;
/
