CREATE PROCEDURE              P_STAT_FILEDATAITEMSBYDEPTID(deptid varchar2)
 IS
/**
所有数据文件数据项归集情况统计
  主要统计为空等情况
**/
  --获取所有的归集字段

  RESULT VARCHAR2(2000);
  CURSOR CURMETACOLUMN(v_deptid varchar2) IS
    SELECT TS.*
      FROM T_META_TABLE TM, T_SYS_DATAFILEINFO TS
     WHERE
       TS.MESSAGEID = TM.MESSAGEID
       AND TM.Isuse='Y'
       AND TS.cleaned='Y'
       and tm.deptid =v_deptid

     ORDER BY TM.DEPTID,TS.MESSAGEID;
BEGIN

   FOR rd IN CURMETACOLUMN(deptid) LOOP
   P_STAT_FILEDATAITEMS_BYFILEID(rd.FILEID,RESULT);
   END LOOP;

EXCEPTION
    When others then
      -- RESULT:=sqlerrm(SqlCode);
        NULL;
END P_STAT_FILEDATAITEMSBYDEPTID;

/
