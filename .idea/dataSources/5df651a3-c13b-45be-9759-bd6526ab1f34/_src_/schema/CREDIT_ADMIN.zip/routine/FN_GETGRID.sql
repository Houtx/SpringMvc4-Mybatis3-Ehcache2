CREATE function fn_getgrid  Return number
 is
       v_grid     number;

begin
  select s_grid.nextval into v_grid from dual;
   Return v_grid;
end fn_getgrid;
/
