CREATE function              isequal
(
  var1  in varchar2,
  var2  in varchar2
)
return number    -- 0： 不等  1：相等  -1：错误
is
begin
  if (var1 is null and var2 is null or var1 is not null and var2 is not null and var1 = var2) then
    return 1;
  else
    return 0;
  end if;

  exception
    when others then
    return -1;
end isequal;

/
