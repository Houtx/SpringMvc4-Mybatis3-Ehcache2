CREATE procedure P_DELEFILEBYFILEID(p_fileid in VARCHAR2) is

v_sql  varchar2(3000):= '';
V_FILEID VARCHAR2(50);
V_TABLENAME VARCHAR2(50);
begin
  --a11e83e3-700c-49a4-9527-a42e8ec6f2ed
  -- fileid='a11e83e3-700c-49a4-9527-a42e8ec6f2ed';
  V_FILEID := p_fileid;
  SELECT TABLENAME INTO V_TABLENAME FROM T_META_TABLE T 
  WHERE T.MESSAGEID=(SELECT MESSAGEID FROM T_SYS_DATAFILEINFO F WHERE F.FILEID=V_FILEID);  
  v_sql:='delete from T_SYS_DATAFILEITEM t where t.filegroupid in(select filegroupid from T_SYS_DATAFILEGROUPS t where t.fileid=:1)';
  execute immediate v_sql using in p_fileid;
  v_sql:='delete from T_SYS_DATAFILEGROUPS t where fileid=:1';
  execute immediate v_sql using in p_fileid;
  v_sql:='delete from credit_gather.t_filepreview t where fileid=:1';
  execute immediate v_sql using in p_fileid;
   v_sql:='delete from t_Rpt_Frontprocess t where processid=:1';
  execute immediate v_sql using in p_fileid;
  v_sql:='delete from t_sys_datafileinfo t where fileid=:1';
  execute immediate v_sql using in p_fileid;
 v_sql:='delete from T_RPT_CINCREMENTDATACHECK t where recordfileid=:1';
  execute immediate v_sql using in p_fileid;

 v_sql:='delete from t_Rpt_Cdatacheck t where fileid=:1';
  execute immediate v_sql using in p_fileid;
 v_sql:='delete from t_Rpt_Cdatacheckhis t where fileid=:1';
  execute immediate v_sql using in p_fileid;
  v_sql:='delete from T_RPT_ASSOCIATESTATISTICS t where recordfileid=:1';
  execute immediate v_sql using in p_fileid;
v_sql:='delete from T_RPT_ASSOCIATESTATISTICS t where recordfileid=:1';
  execute immediate v_sql using in p_fileid;
 v_sql:='delete from T_RPT_MANUALCONNECT t where fileid=:1';
  execute immediate v_sql using in p_fileid;

 v_sql:='delete from T_RPT_MANUALCACNCELCONNECT t where fileid=:1';
  execute immediate v_sql using in p_fileid;

 v_sql:='delete from T_RPT_MANUALCREDIT t where fileid=:1';
  execute immediate v_sql using in p_fileid;

 v_sql:='delete from T_RPT_MANUALREPEAT t where fileid=:1';
  execute immediate v_sql using in p_fileid;

 v_sql:='delete from T_RPT_MODIFYRECORDS t where fileid=:1';
  execute immediate v_sql using in p_fileid;

 v_sql:='delete from T_RPT_REDOCDATACHECK t where fileid=:1';
  execute immediate v_sql using in p_fileid;
  
 v_sql:='delete from t_Rpt_Redocdatacheckhis t where fileid=:1';
  execute immediate v_sql using in p_fileid;
  
 v_sql:='delete from T_RPT_CDATACHECKQRECORD t where fileid=:1';
  execute immediate v_sql using in p_fileid;
  
   v_sql:='delete from T_RPT_STATICSQFILESENDRECORDS t where fileid=:1';
  execute immediate v_sql using in p_fileid;
  
    v_sql:='delete from T_DATA_REPAIR t where fileid=:1';
  execute immediate v_sql using in p_fileid;
  
    v_sql:='delete from T_DATA_UPDATES t where fileid=:1';
  execute immediate v_sql using in p_fileid;
--T_DATA_MANUALQYAUDIT(以企业为中心的人工审核)
   v_sql:='delete from T_DATA_RGXG t where fileid=:1';
  execute immediate v_sql using in p_fileid;
commit;
--RAW  
  v_sql := 'delete from credit_gather.'||V_TABLENAME ||' t where t.recid in (select recid from t_dataprocess f where f.fileid=:1)';
  execute immediate v_sql using in p_fileid;
  commit;
--fmt
  v_sql := 'delete from credit_center.'||V_TABLENAME ||'_FMT t where t.recid in (select recid from t_dataprocess f where f.fileid=:1)';
  execute immediate v_sql using in p_fileid;
  commit;
--product
  v_sql := 'delete from credit_product.'||V_TABLENAME ||' t where t.recid in (select recid from t_dataprocess f where f.fileid=:1)';
  execute immediate v_sql using in p_fileid;
  commit;
  v_sql := 'delete from credit_product.'||V_TABLENAME ||'_HIS t where t.recid in (select recid from t_dataprocess f where f.fileid=:1)';
  execute immediate v_sql using in p_fileid;
  commit;
  
  v_sql:='delete from T_DATAPROCESS t where fileid=:1';
  execute immediate v_sql using in p_fileid;
  commit;

end P_DELEFILEBYFILEID;


/
