CREATE procedure P_BATCH_DBJOBBYDEPTID(DEPTID IN VARCHAR2) AUTHID CURRENT_USER is
V_DEPTID VARCHAR2(50);
begin
  --启动某一部门的所有数据库对接
  V_DEPTID := DEPTID;
  IF V_DEPTID IS NOT NULL THEN
    --插入
    insert into credit_gather.t_filepreview
  (deptid,
   uploadbatch,
   fileid,
   messageid,
   sourcename,
   uploadtime,
   userid,
   fileflag,
   sourcetype)
  select m.deptid,
         sys_guid(),
         sys_guid(),
         t.messageid,
         'DB:' || f.deptname || m.messageshortname ||
         to_char(sysdate, 'yyyymmdd'),
         sysdate,
         '后台对接程序',
         '2',
         'ORACLE'
    from t_meta_table_db t, t_meta_table m, t_sys_department f
   where t.messageid = m.messageid
     and m.deptid = f.deptabbr
     AND M.DEPTID=V_DEPTID
     AND (t.dbusername,t.tablename) in 
  (select owner,table_name from dba_tables  where num_rows>0 and owner like 'MID%');
     COMMIT;
  END IF;
end P_BATCH_DBJOBBYDEPTID;
/
