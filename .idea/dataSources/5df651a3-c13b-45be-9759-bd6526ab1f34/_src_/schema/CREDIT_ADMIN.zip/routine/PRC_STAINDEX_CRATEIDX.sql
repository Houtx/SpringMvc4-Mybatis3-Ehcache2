CREATE procedure              PRC_STAINDEX_CRATEIDX is
  progname         varchar(50);
  sqlstr           varchar(4000);
begin
  progname := 'credit_admin.PRC_STAINDEX_CRATEIDX';

  sqlstr := 'create index I_STA_TABLEINDEX_QYID on T_STA_TABLEINDEX (QYID) tablespace TS_ADMININD';
  prc_add_joblog(progname, sqlstr);
  commit;

  begin
    execute immediate sqlstr;
  exception
    when others then
      prc_add_joblog(progname, 'SQLCODE: ' || SQLCODE || ', SQLERRM: ' || SQLERRM);
      commit;
      --null;
      --insert into t_log_joblog values (progname,  sysdate, '3. ERROR while: create index I_STA_TABLEINDEX_QYID');
  end;


  sqlstr := 'create index I_STA_TABLEINDEX_RECID on T_STA_TABLEINDEX (RECID) tablespace TS_ADMININD';
  prc_add_joblog(progname, sqlstr);
  commit;
  begin
    execute immediate sqlstr;
  exception
    when others then
      prc_add_joblog(progname, 'SQLCODE: ' || SQLCODE || ', SQLERRM: ' || SQLERRM);
      commit;
      --null;
      --insert into t_log_joblog values (progname,  sysdate, '3. ERROR while: create index I_STA_TABLEINDEX_RECID');
  end;

  sqlstr := 'create bitmap index I_STA_TABLEINDEX_TABLENAME on T_STA_TABLEINDEX (tablename) tablespace TS_ADMININD';
  prc_add_joblog(progname, sqlstr);
  commit;
  begin
    execute immediate sqlstr;
  exception
    when others then
      prc_add_joblog(progname, 'SQLCODE: ' || SQLCODE || ', SQLERRM: ' || SQLERRM);
      commit;
      --null;
      --insert into t_log_joblog values (progname,  sysdate, '3. ERROR while: create index I_STA_TABLEINDEX_TABLENAME');
  end;

  sqlstr := 'create bitmap index I_STA_TABLEINDEX_MESSAGEID on T_STA_TABLEINDEX (TABLEMESSAGEID) tablespace TS_ADMININD';
  prc_add_joblog(progname, sqlstr);
  commit;
  begin
    execute immediate sqlstr;
  exception
    when others then
      prc_add_joblog(progname, 'SQLCODE: ' || SQLCODE || ', SQLERRM: ' || SQLERRM);
      commit;
      --null;
      --insert into t_log_joblog values (progname,  sysdate, '3. ERROR while: create index I_STA_TABLEINDEX_MESSAGEID');
  end;

end PRC_STAINDEX_CRATEIDX;

/
