CREATE procedure P_UPDATEQYZTBS(QYID IN INTEGER) is
V_QYID INTEGER;
V_QYMC VARCHAR(200);
V_QYZCH VARCHAR2(30);
V_RECID VARCHAR2(50);
V_TRADENAME VARCHAR2(100);
V_FDDBR VARCHAR2(100);
V_ZZJGDM VARCHAR2(30);
V_SHXYDM VARCHAR2(50);
begin
  V_QYID := QYID;
  IF V_QYID IS NOT NULL THEN
  BEGIN
     select qymc,qyzch,recid,fddbrxm,trade_name,zzjgdm INTO
     V_QYMC,V_QYZCH,V_RECID,V_FDDBR,V_TRADENAME,V_ZZJGDM
     from ((SELECT qymc,qyzch,recid,fddbrxm,trade_name,zzjgdm,hzrq,length(qyzch) len   
         from T_SX_JGDJXX
       where qyid = V_QYID 
       union
       SELECT   qymc,qyzch,recid,fddbrxm,trade_name,zzjgdm,hzrq,length(qyzch) len   
         from T_SX_JGDJXX_HIS
       where qyid = V_QYID)
        order by hzrq desc nulls last,len desc) where rownum=1;
      V_SHXYDM := NULL;
      IF LENGTH(V_QYZCH)!=18 THEN
        BEGIN
          SELECT QYZCH INTO V_SHXYDM FROM T_SX_TYSHXYDMXX WHERE QYID=V_QYID AND ROWNUM=1;
        EXCEPTION
          WHEN OTHERS THEN
            DBMS_OUTPUT.PUT_LINE('未找到18位代码');
        END;
      END IF;
      IF V_SHXYDM IS NOT NULL THEN
        V_QYZCH := V_SHXYDM;
      END IF;
      IF LENGTH(V_QYZCH)=18 AND V_ZZJGDM IS NULL THEN
        V_ZZJGDM := SUBSTR(V_QYZCH,9,9);
      END IF;
      --UPDATE QYZTBS      
      IF V_ZZJGDM IS NOT NULL THEN
         UPDATE T_QYZTBS T SET T.QYMC=V_QYMC,T.QYZCH=V_QYZCH,
         T.ZCHRECID=V_RECID,T.FDDBR=V_FDDBR,T.HYMC=V_TRADENAME,T.ZZJGDM=V_ZZJGDM
         WHERE T.QYID=V_QYID;
      ELSE
         UPDATE T_QYZTBS T SET T.QYMC=V_QYMC,T.QYZCH=V_QYZCH,
         T.ZCHRECID=V_RECID,T.FDDBR=V_FDDBR,T.HYMC=V_TRADENAME
         WHERE T.QYID=V_QYID;
      END IF;
      COMMIT;
  EXCEPTION
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE('NOT FOUND');
  END;
  END IF;
end P_UPDATEQYZTBS;
/
