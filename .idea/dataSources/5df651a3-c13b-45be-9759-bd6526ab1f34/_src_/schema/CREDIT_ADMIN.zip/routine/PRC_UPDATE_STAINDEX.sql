CREATE procedure              prc_update_staindex is
  temptabtype      varchar(50);
  tempparentid     varchar(50);
  tempdept         varchar(50);
  tempdeptname     varchar(50);
  temptablename    varchar(50);
  tablemessagename varchar(255);
  temporderid      varchar2(10);
  tempmessageid    varchar2(50);
  tempdeptabbr     varchar2(200);
  sqlstr           varchar(4000);
  progname         varchar(50);
  tabidx           number;

  CURSOR cur is
    select b.deptid,
           b.deptabbr,
           b.deptname,
           a.tablename,
           a.tabletype,
           c.parentid,
           a.messagename,
           a.messageid,
           b.pageorder
      from t_meta_table a, t_sys_department b, t_dict_tabletype c
     where a.isuse = 'Y'
       and a.tabletype = c.code
       and a.domainid like '001%'
       and a.deptid = b.deptabbr
       and a.isuse = 'Y'
     group by b.deptid,
              b.deptabbr,
              b.deptname,
              a.tablename,
              a.tabletype,
              c.parentid,
              a.messagename,
              a.messageid,
              b.pageorder
     order by b.pageorder, a.tabletype;
begin
  progname := 'credit_admin.prc_update_staindex';
  prc_add_joblog(progname, '1.0 begin update staindex');
  commit;

  prc_add_joblog(progname, '2.0 Truncate table T_STA_TABLEINDEX');
  execute immediate 'truncate table T_STA_TABLEINDEX';
  prc_add_joblog(progname, '2.1 Table T_STA_TABLEINDEX truncated');


  prc_add_joblog(progname, '3.0 Drop index');
  commit;


  begin
    sqlstr := 'drop index I_STA_TABLEINDEX_QYID';

    prc_add_joblog(progname, '4.0 ' || sqlstr);
    commit;
    execute immediate sqlstr;
  exception
    when others then
      --null;
      prc_add_joblog(progname, '4.1 ERROR while: ' || sqlstr);
  end;

  begin
    sqlstr := 'drop index I_STA_TABLEINDEX_RECID';

    prc_add_joblog(progname, '5.0 ' || sqlstr);
    commit;
    execute immediate sqlstr;
  exception
    when others then
      --null;
      prc_add_joblog(progname, '5.1 ERROR while: ' || sqlstr);
  end;

  begin
    sqlstr := 'drop index I_STA_TABLEINDEX_MESSAGEID';

    prc_add_joblog(progname, '6.0 ' || sqlstr);
    commit;
    execute immediate sqlstr;
  exception
    when others then
      --null;
      prc_add_joblog(progname, '6.1 ERROR while: ' || sqlstr);
  end;

  begin
    sqlstr := 'drop index I_STA_TABLEINDEX_TABLENAME';

    prc_add_joblog(progname, '7.0 ' || sqlstr);
    commit;
    execute immediate sqlstr;
  exception
    when others then
      --null;
      prc_add_joblog(progname, '7.1 ERROR while: ' || sqlstr);
  end;

  tabidx := 7;

  open cur;
  loop
    fetch cur
      into tempdept,
           tempdeptabbr,
           tempdeptname,
           temptablename,
           temptabtype,
           tempparentid,
           tablemessagename,
           tempmessageid,
           temporderid;

    sqlstr := 'insert into T_STA_TABLEINDEX(orderid,deptid,deptabbr,deptname,tablename,tabletype,parentid,tablemessagename,tablemessageid,counts,qyid,recid)' ||
              ' select ''' || temporderid || ''',''' || tempdept || ''',''' ||
              tempdeptabbr || ''',''' || tempdeptname || ''',''' ||
              temptablename || ''',''' || temptabtype || ''',''' ||
              tempparentid || ''',''' || tablemessagename || ''',''' ||
              tempmessageid || ''',1, qyid,recid  from ' ||
              temptablename || ' where qyid > 0';
    begin
      tabidx := tabidx + 1;
      prc_add_joblog(progname, tabidx || '.0 ' || sqlstr);
      commit;

      execute immediate sqlstr;
      commit;
    exception
      when others then
        rollback;

        prc_add_joblog(progname, tabidx || '.1 ERROR: ' || sqlstr);
        commit;

        --raise;
    end;

    EXIT WHEN cur%NOTFOUND;
  END LOOP;

  sqlstr := 'create index I_STA_TABLEINDEX_QYID on T_STA_TABLEINDEX (QYID) tablespace TS_ADMININD';
  prc_add_joblog(progname, '9999.1: ' || sqlstr);
  commit;
  begin
    execute immediate sqlstr;
  exception
    when others then
      null;
      prc_add_joblog(progname, '9999.1.1: ERROR while: create index I_STA_TABLEINDEX_QYID');
  end;

  sqlstr := 'create index I_STA_TABLEINDEX_RECID on T_STA_TABLEINDEX (RECID) tablespace TS_ADMININD';
  prc_add_joblog(progname, '9999.2: ' || sqlstr);
  commit;
  begin
    execute immediate sqlstr;
  exception
    when others then
      null;
      prc_add_joblog(progname, '9999.2.1. ERROR while: create index I_STA_TABLEINDEX_RECID');
  end;


  sqlstr := 'create bitmap index I_STA_TABLEINDEX_MESSAGEID on T_STA_TABLEINDEX (TABLEMESSAGEID) tablespace TS_ADMININD';
  prc_add_joblog(progname, '9999.3: ' || sqlstr);
  commit;
  begin
    execute immediate sqlstr;
  exception
    when others then
      null;
      prc_add_joblog(progname, '9999.3.1. ERROR while: create index I_STA_TABLEINDEX_MESSAGEID');
  end;

  sqlstr := 'create bitmap index I_STA_TABLEINDEX_TABLENAME on T_STA_TABLEINDEX (tablename) tablespace TS_ADMININD';
  prc_add_joblog(progname, '9999.4: ' || sqlstr);
  commit;
  begin
    execute immediate sqlstr;
  exception
    when others then
      null;
      prc_add_joblog(progname, '9999.4.1 ERROR while: create index I_STA_TABLEINDEX_TABLENAME');
  end;

  prc_add_joblog(progname, '9999.9 end');
  commit;
end prc_update_staindex;

/
