CREATE procedure              prc_rebuid_dataprocess_idx is
begin
  prc_add_joblog('prc_rebuid_dataprocess_idx', '开始重建 I_DATAPROCESS_FILE');
  commit;
  execute immediate 'alter index credit_center.I_DATAPROCESS_FILE rebuild online';

  prc_add_joblog('prc_rebuid_dataprocess_idx', '开始重建 PK_DATAPROCESS');
  commit;
  execute immediate 'alter index credit_center.PK_DATAPROCESS rebuild online';

  prc_add_joblog('prc_rebuid_dataprocess_idx', '开始重建 I_DATAPROCESS_DEPTID');
  commit;
  execute immediate 'alter index credit_center.I_DATAPROCESS_DEPTID rebuild online';

  prc_add_joblog('prc_rebuid_dataprocess_idx', '开始重建 I_DATAPROCESS_MD5CODE');
  commit;
  execute immediate 'alter index credit_center.I_DATAPROCESS_MD5CODE rebuild online';

  prc_add_joblog('prc_rebuid_dataprocess_idx', '开始重建 I_DATAPROCESS_MD5CODE2');
  commit;
  execute immediate 'alter index credit_center.I_DATAPROCESS_MD5CODE2 rebuild online';

  prc_add_joblog('prc_rebuid_dataprocess_idx', '开始重建 I_DATAPROCESS_MESSAGEID');
  commit;
  execute immediate 'alter index credit_center.I_DATAPROCESS_MESSAGEID rebuild online';

  prc_add_joblog('prc_rebuid_dataprocess_idx', '开始重建 I_DATAPROCESS_QYID');
  commit;
  execute immediate 'alter index credit_center.I_DATAPROCESS_QYID rebuild online';

  prc_add_joblog('prc_rebuid_dataprocess_idx', '重建 DATAPROCESS 索引完成');
  commit;

end prc_rebuid_dataprocess_idx;

/
