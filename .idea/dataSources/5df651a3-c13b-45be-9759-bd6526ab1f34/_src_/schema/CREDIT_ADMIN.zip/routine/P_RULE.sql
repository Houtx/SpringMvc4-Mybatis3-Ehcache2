CREATE procedure              p_rule(p_deptid in varchar2) is

       Cursor cur_deptid is   --定义游标
             select T.MESSAGEID,T.FILEID from t_sys_datafileinfo t where t.deptid=p_deptid AND t.cleaned='Y';

       row_deptid  cur_deptid%Rowtype; --声明行变量
       v_fileid varchar2(1000) :='';
       v_messageid varchar2(1000) :='';
       p_reten integer:=-1;
begin

      --delete t_rpt_ruledatacheckstatics ; -- 执行存储过程之前清空 t_rpt_ruledatacheckstatics 表
      --commit;

      open cur_deptid;
          Loop
             Fetch cur_deptid
                Into row_deptid;
             exit when cur_deptid%notfound;
                 v_fileid :=row_deptid.fileid;
                 v_messageid := row_deptid.messageid;

       p_rule_statistics(v_fileid,v_messageid,p_reten); --调用存储过程

       end loop;
       close cur_deptid; --关闭游标


end ;

/
