CREATE procedure p_startdbgather(messageid in varchar2) authid current_user is
v_msgid varchar2(50);
begin
  v_msgid := messageid;
  if v_msgid  is not null then  
  insert into credit_gather.t_filepreview
  (deptid,
   uploadbatch,
   fileid,
   messageid,
   sourcename,
   uploadtime,
   userid,
   fileflag,
   sourcetype)
  select m.deptid,
         sys_guid(),
         sys_guid(),
         t.messageid,
         'DB:' || f.deptname || m.messageshortname ||
         to_char(sysdate, 'yyyymmdd'),
         sysdate,
         '后台对接程序',
         '2',
         'ORACLE'
    from t_meta_table_db t, t_meta_table m, t_sys_department f
   where t.messageid = m.messageid
     and m.deptid = f.deptabbr
     and t.messageid=v_msgid;
   commit;
   end if;
end p_startdbgather;
/
