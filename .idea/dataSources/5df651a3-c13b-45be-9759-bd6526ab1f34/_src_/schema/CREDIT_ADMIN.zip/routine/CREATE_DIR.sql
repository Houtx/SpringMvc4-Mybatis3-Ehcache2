CREATE function CREATE_DIR(v_folderPath varchar2) return varchar2 as language java name 'com.les.common.util.FileUtils.newFolder(java.lang.String) return java.lang.String';

/
