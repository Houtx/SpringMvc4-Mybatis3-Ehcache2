CREATE procedure P_ZTK_GONGSHANG_XZXK(CMDID IN INTEGER) is
       V_UPDATERESULT BOOLEAN;
       V_STARTTIME  DATE;
         V_INSFILESQL VARCHAR2(500);
         V_COUNT     INTEGER := 0;
        V_MESSAGEID  VARCHAR2(50) := '53E1D2FC33744EA0AB1819BBF14693D4';
        V_MAPPINGID  VARCHAR2(50) := 'QYSGS_3d54c59f7a854ab4bba3c34972b264ca';
begin
  --判断是否存在这个CMDID
  DECLARE
    V_TMP VARCHAR2(1);
  BEGIN
    SELECT '1'
      INTO V_TMP
      FROM T_SYS_PROCESSCOMMAND2 T
     WHERE T.CMDID = CMDID
       AND DOMAINID = '015'
       and rownum = 1;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('命令无效');
      V_UPDATERESULT := F_UPDATECMDSTATE(CMDID, '2','N');
      IF NOT V_UPDATERESULT THEN
        --更新状态失败，对后台有影响
        P_WRITELOG(CMDID, '命令执行状态更新失败。');
      END IF;
      RETURN;
    WHEN OTHERS THEN
      V_UPDATERESULT := F_UPDATECMDSTATE(CMDID, '2','N');
      IF NOT V_UPDATERESULT THEN
        --更新状态失败，对后台有影响
        P_WRITELOG(CMDID, '命令执行状态更新失败。');
      END IF;
      P_WRITELOG(CMDID, '查询命令发生错误：' || SQLERRM);
      RETURN;
  END;
  V_STARTTIME := SYSDATE;
  select count(1) into V_COUNT FROM CREDIT_PRODUCT.T_NJ_GONGSHANG_XZXK a0
    where  not exists (select 1 from credit_qysgs.t_qysgs_frxzxk where recid=a0.recid);
  -- P_WRITELOG(CMDID, '开始市工商局行政许可信息数据生成');
  
  P_WRITELOG(CMDID, '插入市工商局行政许可信息数据');
  begin
    insert into credit_qysgs.t_qysgs_frxzxk
    (irecid, datasetid, qyid, createtime, isvalid, invaliddate, isincreased, verified, recid, xkwh, xmmc, splb, xknr, qymc, shxydm,qyzch,zzjgdm, xkrq, xkyxq, xkjg, bz, xzqh, fddbrxm, dbrsfzhm, qlbm, syfw, zl, bgrq, deptid)
    select sys_guid(),'A806C4A622F54C3AAD882D0A46D11894',a0.QYID,sysdate,'','','','Y',a0.RECID,a0.XKWH,a0.XMMC,a0.SPLB,a0.XKNR,a0.QYMC,a0.SHXYDM,a0.QYZCH,a0.ZZJGDM,a0.XKRQ,a0.XKYXQ,a0.XKJG,a0.BZ,a0.XZQH,a0.FDDBRXM,a0.DBRSFZHM,a0.QLBM,a0.SYFW,a0.ZL,a0.BGRQ,a1.DEPTID FROM CREDIT_PRODUCT.T_NJ_GONGSHANG_XZXK a0,T_DATAPROCESS a1 
    where a0.recid=a1.recid  and not exists (select 1 from credit_qysgs.t_qysgs_frxzxk where recid=a0.recid);
  exception 
    when others then
      rollback;
      P_WRITELOG(CMDID, '插入市工商局行政许可信息数据生成表记录时发生错误。错误：' || SQLERRM);
  end;
  commit;
  P_WRITELOG(CMDID, '数据生成完毕，共生成' || V_COUNT || '条记录。');
  P_WRITELOG(CMDID, '插入市工商局行政许可信息数据完成');
  BEGIN
    SELECT MESSAGEID,MAPPINGID
      INTO V_MESSAGEID,V_MAPPINGID
      FROM T_ZTK_MAPPING
     WHERE mappingid='QYSGS_3d54c59f7a854ab4bba3c34972b264ca';
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      P_WRITELOG(CMDID, '警告：没有找到信息类ID');
  END;
  V_INSFILESQL := 'INSERT INTO T_ZTK_FILE(CMDID,DATASETID,MAPPINGID,DOMAINID,MESSAGEID,STARTTIME,ENDTIME,RECCOUNT,ISQUANJI,CORPCOUNT,RECCOUNT_QYID) VALUES(' ||
                  ':1,''A806C4A622F54C3AAD882D0A46D11894'',:2,''015'',:3,:4,SYSDATE,:5,''Y'',:6,:7)';
  BEGIN
    EXECUTE IMMEDIATE V_INSFILESQL
      USING CMDID,V_MAPPINGID,V_MESSAGEID, V_STARTTIME, V_COUNT,V_COUNT,V_COUNT;
  EXCEPTION
    WHEN OTHERS THEN
      P_WRITELOG(CMDID, '插入数据生成表记录时发生错误。' || SQLERRM);
  END;
  P_WRITELOG(CMDID, '更新完毕。存储过程执行完毕。');
  V_UPDATERESULT := F_UPDATECMDSTATE(CMDID, '2','Y');
  IF NOT V_UPDATERESULT THEN
    --更新状态失败，对后台有影响
    P_WRITELOG(CMDID, '命令执行状态更新失败。');
  END IF;
end P_ZTK_GONGSHANG_XZXK;
/
