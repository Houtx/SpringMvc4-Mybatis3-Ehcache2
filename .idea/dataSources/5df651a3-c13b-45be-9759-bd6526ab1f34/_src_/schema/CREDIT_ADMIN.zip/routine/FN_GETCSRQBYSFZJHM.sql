CREATE function fn_getcsrqbysfzjhm (sfzjhm in varchar2) Return date
 is
       v_csrq     date;
       v_date     varchar2(50);

begin
   if length(sfzjhm) = 15 then
      v_date := '19' || substr(sfzjhm, 7, 6);
   elsif length(sfzjhm) = 18 then
      v_date := substr(sfzjhm, 7, 8);
   end if;
   if IsDate(v_date) then
      V_CSRQ := to_date(v_date, 'yyyymmdd');
   else
      V_CSRQ := NULL;
   end if;
   Return v_csrq;
end fn_getcsrqbysfzjhm;
/
