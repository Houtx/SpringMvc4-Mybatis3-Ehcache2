CREATE procedure              prc_update_mv_tj is
  progname varchar(100);
begin
  progname := 'prc_update_mv_tj';
  prc_add_joblog(progname, '1.1.2 开始刷新 MV_TJ_XXL_SJX_JLS');
  commit;
  dbms_mview.refresh('MV_TJ_XXL_SJX_JLS');
  insert into MV_TJ_XXL_SJX_JLS_HIS SELECT * FROM MV_TJ_XXL_SJX_JLS;

  dbms_mview.refresh('MV_TJ_XXL_SJX_JLS2');
  insert into MV_TJ_XXL_SJX_JLS_HIS2
  SELECT *
    FROM MV_TJ_XXL_SJX_JLS2 v
   where not exists
   (select * from MV_TJ_XXL_SJX_JLS_HIS2 h where v.dt = h.dt);

  prc_add_joblog(progname, '1.1.3 刷新 MV_TJ_XXL_SJX_JLS 完成');
  commit;
end prc_update_mv_tj;

/
