CREATE function fnc_assstrategy_show(f_i_assstrategys in varchar2)
RETURN varchar2 IS
  --Project:江苏征信
  --Author：杜炼
  --Create Date：2009-12-18
  --Last Modified： 2009-12-18
  --Description：用于显示用;号隔开的关联表assstrategy名
  --Module：业务管理规则定义
 var_note    varchar2(1000):='';
var_count   number := 0;
   r_emp varchar2(1000); --声明一个行类型变量
   --TYPE c_type IS REF CURSOR; --声明REF游标类型
   --cur       c_type; --声明REF游标类型的变量
   p_salary NUMBER; --声明一个标量变量
   CURSOR c IS SELECT * FROM TABLE (CAST (fn_split (f_i_assstrategys, ';') AS ty_str_split));
   r c%ROWTYPE;
var_sql  varchar2(1000):='';
begin
    OPEN c ;
   LOOP
     FETCH c
           INTO r;
     EXIT WHEN c%NOTFOUND;
      var_sql:='select distinct name from t_sys_dict where mark like ''assstrategy%'' and value='''||r.column_value||'''';
      execute immediate var_sql into r_emp;
      var_note := to_char(var_note||r_emp||',');
        var_count := var_count+1;
   END LOOP;
   CLOSE c; --关闭游标

    if var_count>0 then
       var_note:=SUBSTR(var_note,0,LENGTH(var_note)-1);
    end if;
    return var_note;
end fnc_assstrategy_show;
/
