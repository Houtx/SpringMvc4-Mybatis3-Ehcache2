CREATE procedure              prc_test_putline is
begin
   dbms_output.put_line('prc_test_putline');
end prc_test_putline;

/
