CREATE function              ENCRYPTED_DATA(p_text varchar2) return varchar2 as language java name 'com.les.common.util.CryptoTools.encode(java.lang.String) return java.lang.String';

/
