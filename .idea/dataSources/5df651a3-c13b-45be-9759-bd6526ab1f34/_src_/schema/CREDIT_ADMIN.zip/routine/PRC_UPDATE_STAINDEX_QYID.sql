CREATE procedure              prc_update_staindex_qyid(v_qyid number) is
begin
  delete from T_STA_TABLEINDEX where qyid = v_qyid;
  dbms_output.put_line('delete from T_STA_TABLEINDEX where qyid = ' ||
                       v_qyid);

  --delete from t_sta_tableindex where qyid=1000008564;
  insert into t_sta_tableindex
    (orderid,
     deptid,
     deptabbr,
     deptname,
     tablename,
     tabletype,
     parentid,
     tablemessagename,
     tablemessageid,
     counts,
     qyid,
     recid)
    select temporderid,
           tempdept,
           tempdeptabbr,
           tempdeptname,
           temptablename,
           temptabtype,
           tempparentid,
           tablemessagename,
           tempmessageid,
           1,
           qyid,
           recid
      from (select b.deptid      tempdept,
                   b.deptabbr    tempdeptabbr,
                   b.deptname    tempdeptname,
                   a.tablename   temptablename,
                   a.tabletype   temptabtype,
                   c.parentid    tempparentid,
                   a.messagename tablemessagename,
                   a.messageid   tempmessageid,
                   b.pageorder   temporderid
              from t_meta_table a, t_sys_department b, t_dict_tabletype c
             where a.isuse = 'Y'
               and a.tabletype = c.code
               and a.domainid like '001%'
               and a.deptid = b.deptabbr
               and a.isuse = 'Y'
             group by b.deptid,
                      b.deptabbr,
                      b.deptname,
                      a.tablename,
                      a.tabletype,
                      c.parentid,
                      a.messagename,
                      a.messageid,
                      b.pageorder) t,
           (select qyid, messageid, recid
              from t_dataprocess
             where qyid = v_qyid) dp
     where t.tempmessageid = dp.messageid;

end prc_update_staindex_qyid;

/
