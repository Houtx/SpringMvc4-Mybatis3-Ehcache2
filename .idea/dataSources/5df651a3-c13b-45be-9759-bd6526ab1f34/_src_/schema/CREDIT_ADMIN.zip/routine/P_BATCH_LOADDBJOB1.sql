CREATE procedure P_BATCH_LOADDBJOB1 AUTHID CURRENT_USER is
CURSOR C_ALLDATA IS
  select 'analyze table '||dbusername||'.'||tablename||' compute statistics' SQLSTR from t_meta_table_db t where t.dbusername not in ('MID_SX','MID_XINXI');

begin
  --全部执行一次计算统计  
  FOR R_SQLDATA IN C_ALLDATA LOOP
    BEGIN
      EXECUTE IMMEDIATE R_SQLDATA.SQLSTR;
    EXCEPTION
      WHEN OTHERS THEN
        DBMS_OUTPUT.put_line(SQLERRM);
    END;
  END LOOP;  
end P_BATCH_LOADDBJOB1;
/
