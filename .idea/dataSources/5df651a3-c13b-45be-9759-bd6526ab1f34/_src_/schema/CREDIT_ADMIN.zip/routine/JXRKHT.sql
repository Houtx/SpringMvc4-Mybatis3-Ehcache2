CREATE procedure JXRKHT(fileid in varchar2) authid current_user is
fid varchar2(50) :='';
tabname varchar2(100):='';
delsql varchar2(4000):='';
begin
  fid:=fileid;
  if(fid is null or fid ='') then
    dbms_output.put_line('NULL PARAMETER!');
  else
    select tablename into tabname from t_meta_table t where t.messageid=(select messageid from t_sys_datafilegroups f where f.fileid=fid);
    if(tabname is null or tabname='') then
      dbms_output.put_line('NULL PARAMETER!');
    else
      --解析回退某个信息
      begin
        execute immediate 'delete from credit_gather.t_filepreview t where t.fileid='''||fid||'''';
        commit;
      exception 
        when others then
          dbms_output.put_line(sqlcode||sqlerrm);
      end;
      delete from t_sys_datafileitem t where t.filegroupid=(select filegroupid from t_sys_datafilegroups f where f.fileid=fid);
      commit;  
      delete from t_sys_datafilegroups t where t.fileid=fid;
      commit;
      delete FROM t_sys_datafileinfo t where t.fileid=fid;
      commit;
      delete from t_filesarchive t where t.filecode=fid; 
      commit;
      --删除真实数据
      delsql := 'delete from credit_gather.'||tabname||' t where t.recid in (select recid from t_dataprocess f where f.fileid='''||fid||''')';
      begin
        execute immediate delsql;
        commit;
      exception 
        when others then
          dbms_output.put_line(sqlcode||sqlerrm);
      end;
      delete from t_dataprocess f where f.fileid=fid;
      commit;
    end if ;    
  end if;
  
end JXRKHT;
/
