CREATE procedure              prc_serv_ylh_guoshui_end_qyid is
       v_sql_ylh_guoshui_history        varchar2(5000) := '';
begin
    dbms_output.put_line('Schema: credit_product,  信用信息应用——遗漏户提示——国税（最终）');

    execute immediate 'truncate table SERV_YLH_GUOSHUI_HISTORY';

    v_sql_ylh_guoshui_history := '
          INSERT INTO SERV_YLH_GUOSHUI_HISTORY
          			select *
				        			from SERV_YLH_GUOSHUI_CURRENT
				        where qyid in (
				         		(select qyid
				        							from SERV_YLH_GUOSHUI_CURRENT
				 						)
				 						MINUS
				 						(select qyid
				 						        from credit_product.t_guoshui_djxx
				             				where ( substr(qylx, 1, 1) != ' || '''' || '5' || '''' ||
                                    'or qylx is null )
				 						)
				        )
				        and qylxmc not like' || '''' || '%个体工商户%' || '''';

    --dbms_output.put_line(v_sql_ylh_guoshui_history);
    execute immediate v_sql_ylh_guoshui_history;
    dbms_output.put_line('*****************');


      commit;
      exception
    when others then
      rollback;
      raise;

end prc_serv_ylh_guoshui_end_qyid;

/
