CREATE procedure P_BATCH_LOADDBJOB AUTHID CURRENT_USER is
begin
  
  --直接插入对接表启动
  insert into credit_gather.t_filepreview(
  deptid,uploadbatch,fileid,messageid,sourcename,uploadtime,userid,fileflag,sourcetype)
  select m.deptid,sys_guid(),sys_guid(),t.messageid,'DB:'||f.deptname||m.messageshortname||to_char(sysdate,'yyyymmdd'),
  sysdate,'后台对接程序','2','ORACLE' from t_meta_table_db t,t_meta_table m,t_sys_department f where t.messageid=m.messageid and m.deptid=f.deptabbr and t.dbusername not in ('MID_SX','MID_XINXI') and (t.dbusername,t.tablename) in 
  (select owner,table_name from dba_tables  where num_rows>0 and owner like 'MID%');
  COMMIT;
end P_BATCH_LOADDBJOB;
/
