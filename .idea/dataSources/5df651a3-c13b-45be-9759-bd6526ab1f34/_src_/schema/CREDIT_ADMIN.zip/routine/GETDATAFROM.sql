CREATE function              GetDataFrom
(
  fileid  in varchar2,
  intercode  in varchar2
)
return number    -- 0： 星网  1：模拟系统  2：新系统
is
begin
  if intercode is null then
    return 2;
  end if;

  if intercode = '0' then
    return 0;
  end if;

  return 1;
end GetDataFrom;

/
