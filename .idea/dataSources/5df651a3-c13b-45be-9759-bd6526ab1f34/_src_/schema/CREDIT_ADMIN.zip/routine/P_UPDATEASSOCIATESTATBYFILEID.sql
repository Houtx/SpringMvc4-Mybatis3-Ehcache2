CREATE procedure P_UPDATEASSOCIATESTATByFileId(p_fileid in varchar2) IS
V_FILEID      T_RPT_ASSOCIATESTATISTICS.RECORDFILEID%TYPE;
V_JOINFLAG    T_DATAPROCESS.JOINFLAG%TYPE;
V_NOTCCOUNTS  T_RPT_ASSOCIATESTATISTICS.NOTCONNECTCOUNT%TYPE:=0;--未关联记录总数
V_111         T_RPT_ASSOCIATESTATISTICS.NOTCONNECTCOUNT%TYPE:=0;--111关联记录总数
V_110         T_RPT_ASSOCIATESTATISTICS.NOTCONNECTCOUNT%TYPE:=0;--110关联记录总数
V_101         T_RPT_ASSOCIATESTATISTICS.NOTCONNECTCOUNT%TYPE:=0;--101关联记录总数
V_011         T_RPT_ASSOCIATESTATISTICS.NOTCONNECTCOUNT%TYPE:=0;--011关联记录总数
V_100         T_RPT_ASSOCIATESTATISTICS.NOTCONNECTCOUNT%TYPE:=0;--100关联记录总数
V_001         T_RPT_ASSOCIATESTATISTICS.NOTCONNECTCOUNT%TYPE:=0;--001关联记录总数
V_010         T_RPT_ASSOCIATESTATISTICS.NOTCONNECTCOUNT%TYPE:=0;--010关联记录总数

--统计关联数
CURSOR cur_joinflag(v_fileid varchar2) IS
SELECT JOINFLAG, COUNT(1) AS CNT  FROM T_DATAPROCESS T WHERE  t.qyid>0 AND  t.FILEID = v_fileid GROUP BY T.JOINFLAG;
begin

     V_FILEID:=p_fileid;
     SELECT COUNT(1) INTO V_NOTCCOUNTS
          FROM T_DATAPROCESS T
         WHERE
         --T.STATE IS NOT NULL ,WXL意见
           T.Isvalid='Y'
           AND ((T.QYID IS NULL) OR (T.QYID <= 0))
           AND t.fileid=V_FILEID;
     --目前首先更新未关联记录数
     FOR rdjoinflag IN cur_joinflag(V_FILEID) LOOP
       V_JOINFLAG:=rdjoinflag.JOINFLAG;
       IF V_JOINFLAG IS NOT NULL AND LENGTH(V_JOINFLAG)>0 THEN
            case
              when V_JOINFLAG='111' THEN
                V_111:=nvl(rdjoinflag.CNT,0);
              when V_JOINFLAG='110' THEN
                V_110:=nvl(rdjoinflag.CNT,0);
              when V_JOINFLAG='101' THEN
                 V_101:=nvl(rdjoinflag.CNT,0);
              when V_JOINFLAG='011' THEN
                 V_011:=nvl(rdjoinflag.CNT,0);
              when V_JOINFLAG='100' THEN
                 V_100:=nvl(rdjoinflag.CNT,0);
              when V_JOINFLAG='001' THEN
                 V_001:=nvl(rdjoinflag.CNT,0);
              when V_JOINFLAG='010' THEN
                 V_010:=nvl(rdjoinflag.CNT,0);
            end case;

       END IF;

  END LOOP;

     UPDATE T_RPT_ASSOCIATESTATISTICS SET NOTCONNECTCOUNT=nvl(V_NOTCCOUNTS,0)
     ,RULE_111_COUNTS =  V_111
      ,RULE_110_COUNTS = V_110
      ,RULE_011_COUNTS =V_011
      ,RULE_010_COUNTS = V_010
      ,RULE_100_COUNTS =V_100
      ,RULE_101_COUNTS = V_101
      ,RULE_001_COUNTS =V_001
      ,LASTUPDATETIME=sysdate
      WHERE recordfileid=V_FILEID;
     COMMIT;
end P_UPDATEASSOCIATESTATByFileId;


/
