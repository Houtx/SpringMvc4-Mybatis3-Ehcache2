CREATE VIEW V_SYS_DICT AS SELECT a.ID,a.mark,a.NAME AS remark,a.p_id,'2' AS openmode FROM t_sys_dict a
UNION
SELECT b."ID",b."MARK",b."REMARK",b."P_ID",'1' AS openmode FROM t_sys_dictroot b
/
