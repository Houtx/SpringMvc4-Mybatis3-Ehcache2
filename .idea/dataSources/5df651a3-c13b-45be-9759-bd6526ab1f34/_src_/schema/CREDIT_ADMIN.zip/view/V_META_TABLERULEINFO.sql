CREATE VIEW V_META_TABLERULEINFO AS select tt.deptid,
       tt.messagename,
       fnc_columns_show(tcr.columnids) columnnames
       ,(select rulename from T_META_RULE where ruleid = tcr.ruleid) rulename
       ,tcr.rulecode
  from t_meta_columnrule tcr, T_META_TABLE tt
 where tt.messageid = tcr.messageid
   and tcr.columnids is not null
   and tcr.istableuse = 'Y'
  -- and tt.deptid='ZHIJIAN'
   order by tcr.messageid,tcr.columnid
/
