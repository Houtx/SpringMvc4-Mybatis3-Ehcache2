CREATE VIEW V_QJBM2 AS select 'DEPT_'||dep_parentid DEPT1,'DEPT_NJ_'||dep_parentid DEPTID2 from t_sys_department m where m.dep_parentid in
(SELECT deptid FROM T_SYS_DEPARTMENT T WHERE T.DEP_PARENTID='NJ' and orderid>99)
/
