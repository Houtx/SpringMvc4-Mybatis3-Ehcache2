CREATE VIEW V_LOG_JOBLOG AS select "LOGPROG","LOGTIME","LOGDESC","LOGID" from t_log_joblog t order by t.logtime desc, t.logid desc, t.logprog desc, t.logdesc desc
/
