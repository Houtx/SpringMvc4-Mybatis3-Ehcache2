CREATE VIEW V_DICT_TABLETYPE AS SELECT (LPAD(' ', 4 * (LEVEL - 1), ' ┃ ') || ' ┣' || VALUE)NAME,
      VALUE,
      CODE,
      TYPE,
     t.parentid
  FROM T_DICT_TABLETYPE t
 WHERE 1 = 1
 START WITH (parentID = '99999')
CONNECT BY PRIOR t.CODE = t.parentid
order  siblings  by t.code, t.parentID
/
