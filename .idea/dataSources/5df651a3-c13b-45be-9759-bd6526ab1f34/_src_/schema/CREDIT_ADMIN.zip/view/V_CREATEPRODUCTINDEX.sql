CREATE VIEW V_CREATEPRODUCTINDEX AS select 'create index CREDIT_PRODUCT.' || t.tablename ||
       '_QYID ON CREDIT_PRODUCT.' || t.tablename || '(QYID);'||chr(13)||
        'create index CREDIT_PRODUCT.' || t.histablename ||
       '_QYID ON CREDIT_PRODUCT.' || t.histablename || '(QYID);' as indexsql
  from T_META_TABLE t
/
