CREATE VIEW V_QJBM AS select 'DEPT_'||deptid DEPTID,'DEPT_NJ_'||dep_parentid DEP_PARENTID from t_sys_department m where m.dep_parentid in
(SELECT deptid FROM T_SYS_DEPARTMENT T WHERE T.DEP_PARENTID='NJ' and orderid>99)
/
