CREATE VIEW V_DICTTABLETYPE AS SELECT (LPAD(' ', 4 * (LEVEL - 1), ' ┃ ') || ' ┣' || value)TYPENAME,
      code,
      value,
      parentid
  FROM T_DICT_TABLETYPE  t
 WHERE 1 = 1
 START WITH (parentid = '99999')
CONNECT BY PRIOR t.code = t.parentid
order  siblings  by  t.parentid asc
/
