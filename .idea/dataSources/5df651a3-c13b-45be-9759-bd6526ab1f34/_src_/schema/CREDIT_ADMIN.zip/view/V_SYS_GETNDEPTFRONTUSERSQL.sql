CREATE VIEW V_SYS_GETNDEPTFRONTUSERSQL AS select 'CREATE TABLESPACE TS_' || v.deptabbr || ' DATAFILE ''$PATH\TS_' ||
       v.deptabbr || '01.DBF'' SIZE 50M REUSE AUTOEXTEND ON NEXT 5M MAXSIZE UNLIMITED;' as tablespacesql,
       'CREATE TEMPORARY TABLESPACE TS_' || v.deptabbr || '_TEMP TEMPFILE ''$PATH\TS_' ||
       v.deptabbr || '_TEMP01.DBF'' SIZE 10M REUSE AUTOEXTEND ON NEXT 5M MAXSIZE UNLIMITED;' as tablespacetempsql,

       'CREATE USER DEPT_' || v.deptabbr || ' IDENTIFIED BY ' || v.deptabbr ||' DEFAULT TABLESPACE TS_' || v.deptabbr ||
       ' TEMPORARY TABLESPACE TS_' || v.deptabbr || '_TEMP;' as deptusersql,

           'CREATE USER MID_' || v.deptabbr || ' IDENTIFIED BY MID_'|| v.deptabbr || ' DEFAULT TABLESPACE TS_' || v.deptabbr ||
       ' TEMPORARY TABLESPACE TS_' || v.deptabbr || '_TEMP;' as deptmidusersql,

       'GRANT CONNECT,RESOURCE,DBA,UNLIMITED TABLESPACE TO DEPT_'||v.deptabbr||';' as grantsql,
          'GRANT CONNECT,RESOURCE,UNLIMITED TABLESPACE TO MID_'||v.deptabbr||';' as midgrantsql,


       'imp DEPT_' ||v.deptabbr||'/'||v.deptabbr ||'@ORCL244_Hacredit file=F:\市级数据库备份\市级部门脚本\dept_empty20121128.dmp ignore=y full=y constraints=y' as impsql

       ,'set username=DEPT_'||v.deptabbr||'
set usepwd='||v.deptabbr||'
imp %username%/%usepwd%@ORCL244_Hacredit file=F:\市级数据库备份\市级部门脚本\dept_empty20121128.dmp ignore=y full=y constraints=y
sqlplus %username%/%usepwd%@ORCL244_Hacredit @F:\市级数据库备份\市级部门脚本\other.sql'  as impfullemptysql

,'set username=DEPT_'||v.deptabbr||'
set usepwd='||v.deptabbr||'
sqlplus %username%/%usepwd%@ORCL244_Hacredit @F:\市级数据库备份\市级部门脚本\other.sql'  as impexcutesql


  from V_SYS_DEPARTMENT v
 where v.DEPTABBR   in ('HA_XQXT')
/
