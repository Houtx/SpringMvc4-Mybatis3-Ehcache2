CREATE VIEW V_SYS_COLUMN AS select a.attribute,a."MESSAGEID",a."COLUMNID",a."COLUMNNAME",a."DATAITEMNAME",a."DATATYPE",a."LENGTH",a."PRECISION",a."ISNULL",a."ISPK",a."ISUSE",a."DICTNAME",a."UNIT",a."ORDERID",a."CREATETIME",a."UPDATETIME",a.isvisible,a.isoffical,a."STOPTIME",b.name as datatypename from t_meta_column a, t_sys_dict b
where b.mark='columndatatype' and a.datatype=b.value
/
