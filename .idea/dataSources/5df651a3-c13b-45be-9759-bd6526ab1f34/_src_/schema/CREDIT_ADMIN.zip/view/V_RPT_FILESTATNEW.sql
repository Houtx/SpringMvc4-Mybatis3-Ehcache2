CREATE VIEW V_RPT_FILESTATNEW AS (select
       tsd.fileid,
       tt.domainid,
       td.deptabbr deptid,
       td.deptname,
       b.code,
       td.orderid,
       td.pageorder,
       td.indate,
       tt.messageid,
       tt.messagename,
       tt.orderid messorderid,
       case
         when tf.statperiod is null then
          tsd.recordfilecreatetime
         else
          tf.statperiod
       end as createtime,
       nvl(tsd.rawrecordfilerecordcounts, 0) rawcounts, ---部门前置原始提供记录数
       nvl(tsd.recordfilerecordcounts, 0) xmlfilereccounts, ---提交中心xml文件中的记录数
       nvl(trf.incchkerrcount, 0) repeat_invalidcounts_dept, ---前置处理疑问记录-重复疑问记录数
       nvl(trf.fmtchkerrcount, 0) fmt_invalidcounts_dept, ---前置处理疑问记录-格式疑问记录数
       nvl(trc.incrementrecordcounts, 0) inccounts_one, --第一次增量记录数
       nvl(trc.notincrementrecordcounts, 0) not_inccounts_one, --第一次非增量记录数
       nvl(trc.centerincrementrecordcounts, 0) inccounts_two, --第二次增量记录数
       nvl(trc.centernotincrementrecordcounts, 0) not_inccounts_two, --第二次非增量记录数
       nvl(trcc.validrecordcounts, 0) validcounts, ----有效记录数
       nvl(trcc.validrecordcounts, 0) indbcounts, ---入库记录数
        nvl(trcc.invalidrecordcounts, 0) invalidcounts, ----中心处理疑问记录数
       nvl(trcc.logicinvalidrecordcounts, 0) logic_invalidcounts, -----中心处理疑问记录数-逻辑疑问记录数
       nvl(tra.connectcount, 0) ccounts, ----关联记录数
       nvl(tra.notconnectcount, 0) notconnectcount, ----未关联记录数,
       NVL(tra.rule_111_counts,0)rule_111_counts,
       NVL(tra.rule_110_counts,0)rule_110_counts,
       NVL(tra.rule_011_counts,0)rule_011_counts,
       NVL(tra.rule_010_counts,0)rule_010_counts,
       NVL(tra.rule_100_counts,0)rule_100_counts
  from t_sys_department          td,
       v_dict_xzqh               b,
       t_meta_table              tt,
       t_sys_datafileinfo        tsd,
       t_rpt_frontprocess        trf,
       t_rpt_cincrementdatacheck trc,
       t_rpt_cdatacheck          trcc,
       t_rpt_associatestatistics tra,
       t_stat_filetimeconfig     tf,
       ----(select * from T_SYS_DATAFILEGROUPS t where t.isparsed != 'D' )   tsdd
       T_SYS_DATAFILEGROUPS tsdd
  where td.deptabbr = tt.deptid
  --- and td.plugin_flag='Y'
   ---and tsd.associated='Y'
  --- and tt.isuse = 'Y'
  --- and tt.staflag = 'Y'
   and td.XZQHID = b.code
   and tt.messageid = tsd.messageid
   and tsd.fileid = trc.recordfileid(+)
   and tsd.fileid = trf.processid(+)
   and tsd.fileid = trcc.fileid(+)
   and tsd.fileid = tra.recordfileid(+)
   and tsd.fileid = tf.fileid(+)
   and tsd.fileid= tsdd.Fileid (+)
    )
/
