CREATE VIEW V_SYS_USERRESOURCE AS select distinct r.userid,s.id,s.NAME,s.PARENT,s.URL,s.ISVALID,s.MENUORDER,s.ROOFGARDEN,s.TYPE,s.OPENMODE,
s.ATTRIBUTE,s.CREATETIME,
s.resdescription
,d.value openmodename,d2.value typename
  from v_sys_userrole r,
       v_sys_roleresource s,
       t_sys_dict d,
       t_sys_dict d2
 where r.roleid = s.roleid  and s.openmode=d.key and s.type=d2.key
       and d.mark='openmode' and d2.mark='resourcetype'

/
