CREATE VIEW V_SYS_ACCESSLOG AS select a."USERID",a."LOGOUT_TIME",a."LOGIN_TIME",a."LOGIN_IP",b.personname,b.deptname from t_sys_accesslog a,v_sys_userinfo b where a.userid=b.id
/
