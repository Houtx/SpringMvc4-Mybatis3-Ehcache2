CREATE VIEW V_SYS_ROLERESOURCE AS select a.roleid,b."ID",b."NAME",b."PARENT",b."URL",b."ISVALID",b."MENUORDER",b."ROOFGARDEN",b."TYPE",b."OPENMODE",b."ATTRIBUTE",b."CREATETIME",b.resdescription from t_sys_roleresource a,t_SYS_RESOURCE b where a.resourceid=b.id

/
