CREATE VIEW V_DE_BATCHGENINSERTDEPT AS select

'delete from DEPT_'||ts.deptabbr||'.de_inter_ex_dir;'||chr(13)||
'delete from DEPT_'||ts.deptabbr||'.de_inter_ex_node;'||chr(13)||
'commit;'||chr(13)||
'insert into DEPT_' || ts.deptabbr ||
       '.de_inter_ex_dir select * from  de_inter_ex_dir t where t.node_code=''JSXY_ZXQZ'';' ||
       chr(13) || 'insert into DEPT_'|| ts.deptabbr ||
       '.de_inter_ex_dir select * from  de_inter_ex_dir t where t.node_code=''' ||
       ts.deptabbr || ''';' || chr(13) || 'insert into DEPT_' || ts.deptabbr ||
       '.de_inter_ex_node select * from  de_inter_ex_node t where t.node_code=''JSXY_ZXQZ'';' ||
       chr(13) || 'insert into DEPT_' || ts.deptabbr ||
       '.de_inter_ex_node select * from  de_inter_ex_node t where t.node_code=''' ||
       ts.deptabbr || ''';' || chr(13) || 'update DEPT_' || ts.deptabbr ||
       '.de_inter_ex_node t set t.is_current=''1'' where t.node_code='''||
       ts.deptabbr ||''';'||chr(13)||'commit;' as INSERTSQL,

       'update DEPT_'||ts.deptabbr ||'.De_Inter_Ex_dir t
   set t.send_path    = replace(t.send_path, ''D:'', ''C:'')
 where t.node_code = ''JSXY_ZXQZ'';'||chr(13)||'commit;' as updatedir


  from t_Sys_Department ts where ts.deptabbr not in('HA','JS')
/
