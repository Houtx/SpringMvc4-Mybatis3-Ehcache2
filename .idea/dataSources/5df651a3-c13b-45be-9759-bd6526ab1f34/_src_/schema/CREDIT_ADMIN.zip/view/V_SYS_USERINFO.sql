CREATE VIEW V_SYS_USERINFO AS SELECT t."ID",
       t."PERSONNAME",
       t."POSITION",
       t."EMAIL",
       t."FAX",
       t."TELL",
       t."ADDRESS",
       t."SEX",
       t."BIRTHDAY",
       t."CREATETIME",
       t."ISVALID",
       t."DEPTID",
       t."ORDERID",
       t."STOPTIME",
       t."ISADMIN",
       t."UPDATETIME",
       t.office,
       u.username,
       t.phone,
       t.sfzjh,
       d.deptname as deptname
  from t_sys_userinfo t, t_sys_department d,t_sys_user u
 where t.id=u.userid and t.deptid = d.deptid(+)
/
