CREATE VIEW V_SYS_USERINFO2 AS SELECT t."ID",t."PERSONNAME",t."POSITION",t."EMAIL",t."FAX",t."TELL",t."ADDRESS",t."SEX",t."BIRTHDAY",t."CREATETIME",t."ISVALID",t."DEPTID",t."ORDERID",t."STOPTIME",t."ISADMIN",t."PHONE",t."OFFICE", t."SFZJH", t."UPDATETIME",d.deptname as deptname from t_sys_userinfo t,t_sys_department d
where t.deptid=d.deptid(+)
/
