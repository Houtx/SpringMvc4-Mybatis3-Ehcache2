CREATE VIEW V_GONGSHANG_SLDJBG_GT_SSQY AS select s."QYID",s."RECID",s."QYMC",s."QYZCH",s."FDDBRXM",s."FDDBRZW",s."QYLXDM",s."QYLXMC",s."ZCZJ",s."ZCZJ_RMB",s."ZJBZ",s."JYFW",s."ZS",s."LXDH",s."DJJGDM",s."DJJGMC",s."SLRQ",s."HZRQ",s."YQYZCH",s."QYZT",s."TRADE_CODE",s."TRADE_NAME",
  q.zzjgdm,q.fddbr, (
  case
      when ((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ = 0) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB = 0) then '其它'
      when ((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ < 100 AND ZCZJ>0) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB < 100 AND ZCZJ>0) then '100万以下'
      when (((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ>=100 AND ZCZJ<500) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB>=100 AND ZCZJ_RMB<500)) then '100万～500万'
      when (((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ>=500 AND ZCZJ<1000) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB>=500 AND ZCZJ_RMB<1000)) then '500万～1000万'
      when (((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ>=1000) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB>=1000)) then '1000万以上'
      else '其它'
    end
  ) ZCZJ_FW,
  (
    case
      when ((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ = 0) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB = 0) then 0
      when ((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ < 100 AND ZCZJ>0) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB < 100 AND ZCZJ>0) then 1
      when (((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ>=100 AND ZCZJ<500) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB>=100 AND ZCZJ_RMB<500)) then 2
      when (((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ>=500 AND ZCZJ<1000) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB>=500 AND ZCZJ_RMB<1000)) then 3
      when (((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ>=1000) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB>=1000)) then 4
      else 0
    end
  ) ZCZJ_DJ,
  (case when (ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) then zczj
        else zczj_rmb end
  ) zczj_rmb2,
  nvl(d.ssqy,
    decode(substr(s.djjgdm, 1, 4), '3200', '省直属',
              '3201', '南京', '3202', '无锡', '3203', '徐州', '3204', '常州',
              '3205', '苏州', '3206', '南通', '3207', '连云港', '3208', '淮安',
              '3209', '盐城', '3210', '扬州', '3211', '镇江', '3212', '泰州',
              '3213', '宿迁', null) ) ssqy,
  nvl(d.xzqhid, decode(substr(s.djjgdm, 1, 4), '3200', '320000',
              '3201', '320100', '3202', '320200', '3203', '320300', '3204', '320400',
              '3205', '320500', '3206', '320600', '3207', '320700', '3208', '320800',
              '3209', '320900', '3210', '321000', '3211', '321100', '3212', '321200',
              '3213', '321300', null)) xzqhid,
  q.qyzt qyztcode,
  --q.sshy,
  --nvl(q.sshyml, '0') sshyml,
  q.Hydm SSHY,
  nvl(q.Hydmml, '0') SSHYML,
  (
     case
      when (s.qylxdm IS NULL or s.qylxdm in ('77','A000')) then '410'
      when (s.qylxdm in ('214','167','168')) then '412'
      else '其它'
    end
  ) QYLXDM_JJPC
 from t_dict_gsdjjgdm d, t_qyztbs q, T_GONGSHANG_SLDJBG s
where d.djjgdm(+)=s.djjgdm
  and q.qyid=s.qyid
  and q.sjly='2'

/
