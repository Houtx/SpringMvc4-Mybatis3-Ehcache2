CREATE VIEW V_SYS_DEPARTMENT AS SELECT (LPAD(' ', 4 * (LEVEL - 1), ' ┃ ') || ' ┣' || DEPTNAME)DEPTDISPLAYNAME,
    t.dep_parentid as parentid,
    t."DEPTID",t."DEPTNAME",t."DEPTABBR",t."ORDERID",t."PLUGIN_FLAG",t."DEP_PARENTID",t."XZQHID",t."ISVALID",t."DEPTFULLNAME",t."INDATE",t."PAGEORDER",t."OFFICALNUM",t."DEPTSHORTNAME",t."DEPTSHORTABBR",t."QLYG",t."DATAFLAG",t."ISQX"
  FROM t_sys_department t
 WHERE 1 = 1
 and t.isvalid='Y'
 --and t.dep_parentid='ZJ'
 --and t.plugin_flag='Y'
 START WITH (DEP_PARENTID = 'JS')
CONNECT BY PRIOR t.DEPTid = t.DEP_PARENTID
order  siblings  by  t.DEP_PARENTID, t.orderid asc
/
