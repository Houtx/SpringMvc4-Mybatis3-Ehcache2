CREATE VIEW T_SUM_NJJT AS SELECT

                 DEPTABBR

                  FROM t_Sys_Department t
                 WHERE 1 = 1
                   and t.isvalid = 'Y'
                -- and (t.deptabbr='NJJT' or t.dep_parentid='NJJT')
                 START WITH (DEP_PARENTID = 'ROOT' AND DEPTID = 'NJJT')
                CONNECT BY PRIOR t.deptid = t.DEP_PARENTID
/
