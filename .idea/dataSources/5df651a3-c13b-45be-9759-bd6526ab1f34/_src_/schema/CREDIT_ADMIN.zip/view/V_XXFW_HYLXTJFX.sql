CREATE VIEW V_XXFW_HYLXTJFX AS SELECT A.VALUE SJLYMC,
             T.COUNTS,
             case
               when a.code = '0' then
                'Z'
               else
                a.code
             end code
        FROM (SELECT t.ml, COUNT(*) COUNTS
                FROM credit_qyjbxx.t_qyjbxx T
               GROUP BY ml
              HAVING ml IS NOT NULL) T,
             (SELECT CODE, VALUE
                FROM CREDIT_ADMIN.T_DICT_TJFX_ZBFL T
               WHERE LENGTH(CODE) = 1) A
       WHERE T.ml = A.code
/
