CREATE VIEW V_SYS_USER2 AS select a."USERID",a."USERNAME",a."PWD",b."ID",b."PERSONNAME",b."POSITION",b."EMAIL",b."FAX",b."TELL",b."ADDRESS",b."SEX",b."BIRTHDAY",b."CREATETIME",b."ISVALID",b."DEPTID",b."ORDERID",b."STOPTIME",b."DEPTNAME", b."ISADMIN",b."PHONE",b."OFFICE", b."SFZJH", b."UPDATETIME"  from t_sys_user a ,v_sys_userinfo2 b where a.userid=b.id and b.ISVALID='Y'
/
