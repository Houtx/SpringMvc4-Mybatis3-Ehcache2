CREATE VIEW V_GONGSHANG_SLDJBG_QY_SSQY AS select s."QYID",s."RECID",replace(replace(s."QYMC", '(','（'), ')', '）') QYMC,s."QYZCH",s."FDDBRXM",s."FDDBRZW",s."QYLXDM",s."QYLXMC",s."ZCZJ",s."ZCZJ_RMB",s."ZJBZ",s."JYFW",s."ZS",s."LXDH",s."DJJGDM",s."DJJGMC",s."SLRQ",s."HZRQ",s."YQYZCH",s."QYZT",s."TRADE_CODE",s."TRADE_NAME",Q.ZZJGDM,Q.FDDBR,(
    case
      when ((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ = 0) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB = 0) then '其它'
      when ((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ < 100 AND ZCZJ>0) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB < 100 AND ZCZJ>0) then '100万以下'
      when (((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ>=100 AND ZCZJ<500) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB>=100 AND ZCZJ_RMB<500)) then '100万～500万'
      when (((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ>=500 AND ZCZJ<1000) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB>=500 AND ZCZJ_RMB<1000)) then '500万～1000万'
      when (((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ>=1000) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB>=1000)) then '1000万以上'
      else '其它'
    end
  ) ZCZJ_FW,
  (
    case
      when ((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ = 0) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB = 0) then 0
      when ((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ < 100 AND ZCZJ>0) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB < 100 AND ZCZJ>0) then 1
      when (((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ>=100 AND ZCZJ<500) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB>=100 AND ZCZJ_RMB<500)) then 2
      when (((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ>=500 AND ZCZJ<1000) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB>=500 AND ZCZJ_RMB<1000)) then 3
      when (((ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) AND ZCZJ>=1000) OR (ZJBZ not in ('人民币', '002', '(人民币)', '（人民币）') AND ZCZJ_RMB>=1000)) then 4
      else 0
    end
  ) ZCZJ_DJ,
  (case when (ZJBZ IS NULL OR ZJBZ in ('人民币', '002', '(人民币)', '（人民币）')) then zczj
        else zczj_rmb end
  ) zczj_rmb2,
  nvl(d.ssqy,
    decode(substr(s.djjgdm, 1, 4), '3200', '省直属',
              '3201', '南京', '3202', '无锡', '3203', '徐州', '3204', '常州',
              '3205', '苏州', '3206', '南通', '3207', '连云港', '3208', '淮安',
              '3209', '盐城', '3210', '扬州', '3211', '镇江', '3212', '泰州',
              '3213', '宿迁', null) ) ssqy,
  nvl(d.xzqhid, decode(substr(s.djjgdm, 1, 4), '3200', '320000',
              '3201', '320100', '3202', '320200', '3203', '320300', '3204', '320400',
              '3205', '320500', '3206', '320600', '3207', '320700', '3208', '320800',
              '3209', '320900', '3210', '321000', '3211', '321100', '3212', '321200',
              '3213', '321300', null)) xzqhid,
  q.qyzt qyztcode,
  --q.sshy,
  --nvl(q.sshyml, '0') sshyml,
  q.Hydm SSHY,
  nvl(q.Hydmml, '0') SSHYML,
  q.hymc,
  (
     case
      when (s.qylxdm in ('25', '1000','1099')) then '110'  --国有企业
      when (s.qylxdm in ('26','2000')) then '120'   --集体企业
      when (s.qylxdm in ('27','28','91','2100','2110','2200')) then '130'  --股份合作企业
      when (s.qylxdm in ('29', '3000')) then '140'             --联营企业
      when (s.qylxdm in ('213', '220', 'E100')) then '149'       --其他联营企业
      when (s.qylxdm in ('50','7100', '7200')) then '151'         --国有独资公司
      when (s.qylxdm in ('51','180','181','7300','7800','7802','7803','7804','7805','7806','7807','7808','7810','7811','7813','7814','7815','7816','7817','7818','7820','7821','7822','7826','7827','7829','7900')) then '159' --其他有限责任公司
      when (s.qylxdm in ('11','16','17','22','49','103','199','200','201','205','206','7000','7700','7710','7720','7730','7731','7740')) then '160' --股份有限公司
      when (s.qylxdm in ('24','212','9000','9001','9002')) then '172' --私营合伙企业
      when (s.qylxdm in ('182')) then '173'  --私营有限责任公司
      when (s.qylxdm in ('23','211','8000')) then '175'  --个人独资企业
      when (s.qylxdm in ('170')) then '190'  --其他企业
      when (s.qylxdm in ('185','193','194')) then '210'   --合资经营企业（港或澳、台资）
      when (s.qylxdm in ('187')) then '220'    --合作经营企业（港或澳、台资）
      when (s.qylxdm in ('99','100','143','195','196','197','7610','7620','7630','7640','7650','7660','7670')) then '230' --港、澳、台商独资经营企业
      when (s.qylxdm in ('207','208','7410')) then '240'  --港、澳、台商投资股份有限公司
      when (s.qylxdm in ('130','4000','4100','4200','4300','4400','4500','4600','4700','7400','7420','7430','7440','7450','7460','7470')) then '310'  --中外合资经营企业
      when (s.qylxdm in ('119','134','184','186','5000','5100','5200','5300','5400','5500','5600','5700','7500','7510','7520','7530','7540','7550','7560','7570')) then '320'  --中外合作经营企业
      when (s.qylxdm in ('93','164','165','166','188','189','190','192','216','D100','D200','D300')) then '330' --外资企业
      when (s.qylxdm in ('98','218','7600')) then '340'  --外商投资股份有限公司
      when (s.qylxdm in ('152','B000')) then '351'  --外国企业常驻代表机构
      when (s.qylxdm in ('137','C200')) then '352'  --提供劳务、承包工程作业企业
      when (s.qylxdm in ('138','139','140','C300','C400','C500')) then '359'  --其他外国企业
      else '其它'
    end
  ) QYLXDM_JJPC
 from t_dict_gsdjjgdm d, t_qyztbs q, T_GONGSHANG_SLDJBG s
where d.djjgdm(+)=s.djjgdm
  and q.qyid=s.qyid
-- and s.qylxdm not in ('77', '168', '214', '167', '0', 'A000')
  and q.sjly='1'
/
