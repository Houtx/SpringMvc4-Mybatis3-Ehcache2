CREATE VIEW V_EX_FILES AS select t.file_name,
       t.send_ip,
       t.receive_ip,
       t.file_size,
       t.transfertype,
       t.start_time,
       t.end_time,
       t.receive_time,
       t.result
  from credit_exchange.t_file_transfer t
/
