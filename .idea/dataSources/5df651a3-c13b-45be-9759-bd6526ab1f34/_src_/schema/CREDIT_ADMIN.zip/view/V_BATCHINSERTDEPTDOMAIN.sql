CREATE VIEW V_BATCHINSERTDEPTDOMAIN AS select 'insert into DEPT_' || v.DEPTABBR ||
        '.t_meta_appdomain (DOMAINID, DOMAINNAME, ORDERID)
values (''010'', ''个人信用信息'', 4);'||chr(13)||'commit;' as insertsql
  from V_SYS_DEPARTMENT v
 where v.DEPTABBR  not in( 'HA','HA_XINXI')
/
