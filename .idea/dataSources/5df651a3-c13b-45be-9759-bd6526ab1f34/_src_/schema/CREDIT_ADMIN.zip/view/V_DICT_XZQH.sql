CREATE VIEW V_DICT_XZQH AS select t.code,
       t.value,
       decode(substr(t.code, 3, 6), '0000', 99999,
       decode(substr(t.code, 5, 6),'00',substr(t.code,1,2)||'0000',
       substr(t.code,1,4)||'00'
       )
       ) parentid
  from t_dict_xzqh t
/
