CREATE VIEW V_SYS_RESOURCE AS select s."ID",s."NAME",s."PARENT",s."URL",s."ISVALID",s."MENUORDER",s."ROOFGARDEN",s."TYPE",s."OPENMODE",s."ATTRIBUTE",s."CREATETIME",d.name openmodename,d2.name typename,d.value openmodevalue,d2.name typevalue
,s.defaultauditlevel,s.resdescription
  from t_sys_resource s,
       t_sys_dict d,
       t_sys_dict d2
 where s.openmode=d.key and s.type=d2.key
       and d.mark='openmode' and d2.mark='resourcetype'
/
