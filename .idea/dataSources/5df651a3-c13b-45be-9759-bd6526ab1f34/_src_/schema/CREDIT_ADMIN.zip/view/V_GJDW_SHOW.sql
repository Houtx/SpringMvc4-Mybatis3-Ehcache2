CREATE VIEW V_GJDW_SHOW AS select a."DEPTID",a."DEPTNAME",fnc_gjdw_show(a.deptid) as note,a.dep_parentid,a.orderid,a.xzqhid from
                          (select a.deptid, b.deptfullname deptname,b.dep_parentid,b.orderid,b.xzqhid
                            from t_meta_table a, t_sys_department b
                           where a.deptid = b.deptabbr and b.deptabbr!='RENHANG'
                           group by a.deptid,b.deptfullname,b.orderid,b.dep_parentid,b.xzqhid
                           ) a order by a.orderid
/
