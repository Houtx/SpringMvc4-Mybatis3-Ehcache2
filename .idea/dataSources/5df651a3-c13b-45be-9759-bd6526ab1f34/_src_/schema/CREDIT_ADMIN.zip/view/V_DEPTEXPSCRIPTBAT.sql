CREATE VIEW V_DEPTEXPSCRIPTBAT AS select 'set dmpfilename=部门前置_' || v.DEPTABBR || '%date:~0,10%.dmp' ||
       chr(13) || 'set logfilename=部门前置_' || v.DEPTABBR ||
       '备份日志_%date:~0,10%.log' || chr(13) || 'set backdir=%~dp0' || chr(13) ||
       'set dmpfullpath=%backdir%%dmpfilename%' || chr(13) ||
       'set logfullpath=%backdir%%logfilename%' || chr(13) ||
       'set db=ORCL144_Hacredit' || chr(13) ||
       'exp system/oracle@%db% owner=(DEPT_' || v.DEPTABBR || ',MID_' ||
       v.DEPTABBR || ') file=%dmpfullpath% log=%logfullpath%' || chr(13) as deptbackbatscript
  from V_SYS_DEPARTMENT v where v.PLUGIN_FLAG='Y'
/
