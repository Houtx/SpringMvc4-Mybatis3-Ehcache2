CREATE VIEW V_RPT_RPTFILEINFO AS select t."DOMAINID",t."FILEID",t."DEPTID",t."RAWRECORDFILECOMMITER",t."RAWRECORDFILENAME",t."RAWRECORDFILERECORDCOUNTS",t."RECORDFILENAME",t."RECORDFILERECORDCOUNTS",t."RECORDFILECREATETIME",t."MESSAGEID",t."USERID",t."STARTTIME",t."FINISHTIME",t."CREATETIME",t."SOURCETYPE",t."XMLPARSE",t."INCCHECKED",t."CLEANED",t."ASSOCIATED",t."SYNCED",t."SEPARATED",t."RECCHECKED",
        tf.begintime FBTIME,
       tf.endtime   FETIME,
       tf.increasecount,
       tf.incchkerrcount,
       tf.fmtchkerrcount,
       tsf.recvtime,
       ti.RECORDCOUNTS,
       ti.INCREMENTRECORDCOUNTS,
       ti.NOTINCREMENTRECORDCOUNTS,
       ti.CENTERINCREMENTRECORDCOUNTS,
       ti.CENTERNOTINCREMENTRECORDCOUNTS,
       ti.reportstarttime INCCHECKSTARTTIME,
       ti.REPORTFINISHTIME INCCHECKENDTIME,
       tc.validrecordcounts,
       tc.invalidrecordcounts,
       tc.checkstarttime CHECKSTARTTIME,
       tc.checkendtime CHECKENDTIME,
       ts.connectcount,
       ts.starttime  CSTARTTIME,
       ts.lastupdatetime  CFINISHTIME,
       tsf.processstate
        from T_SYS_DATAFILEINFO         t,
             t_sys_datafilegroups    tsf,
              T_RPT_FRONTPROCESS tf,
              T_RPT_CINCREMENTDATACHECK  ti,
              T_RPT_CDATACHECK           tc,
              T_RPT_ASSOCIATESTATISTICS  ts  WHERE  tsf.fileid=t.fileid
AND  t.fileid=tf.processid
and t.fileid=ti.recordfileid(+)
and t.fileid=tc.fileid(+)
 and t.fileid=ts.recordfileid(+)
/
