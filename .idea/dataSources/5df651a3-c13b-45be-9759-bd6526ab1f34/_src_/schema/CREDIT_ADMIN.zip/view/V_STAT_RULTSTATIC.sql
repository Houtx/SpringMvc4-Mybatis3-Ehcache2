CREATE VIEW V_STAT_RULTSTATIC AS select T_RPT_RULEDATACHECKSTATICS.FILEID,
       (SELECT RAWRECORDFILENAME
          FROM T_SYS_DATAFILEINFO
         WHERE T_SYS_DATAFILEINFO.FILEID = T_RPT_RULEDATACHECKSTATICS.FILEID) RAWRECORDFILENAME,
       T_RPT_RULEDATACHECKSTATICS.MESSAGEID,
       (SELECT MESSAGENAME
          FROM T_META_TABLE
         WHERE T_META_TABLE.MESSAGEID = T_RPT_RULEDATACHECKSTATICS.MESSAGEID) MESSAGENAME,
       COLUMNID,
       COLUMNDESC,
       RULEID,
       (case RULEID when 'IsNotEmptyOrNull' THEN '检查是否为空'
       when 'IsLengthValidate' then '检查长度是否合法'
       when 'IsNumber' then '检查是否是数值类型'
       when 'CheckDateHangLogic' then '检查是否是合法的日期格式'
       when 'IsExistDictValue' then '检查数据在字典中是否存在'
       else (SELECT RULENAME FROM t_meta_RULE where t_meta_RULE.RULEID=T_RPT_RULEDATACHECKSTATICS.RULEID)
       END)RULENAME
       ,RULECODE,
       (case T_RPT_RULEDATACHECKSTATICS.rulecode
         when 'A0001' then
          '检查字段值是否为空'
         when 'A0002' then
          '检查字段值的长度是否合法'
         when 'A0003' then
          '检查字段值是否是数值类型'
         when 'A0004' then
          '检查字段值是否是合法的日期格式'
         when 'A0005' then
          '检查字段的在字典表中是否存在'
         when 'A0006' then
          '检查字段的值是否是合法的工商注册号'
         when 'A0007' then
          '检查字段的值是否是合法的组织机构代码'
         when 'A0008' then
          '检查字段的值是否是合法的海关注册号'
         when 'A0009' then
          '检查字段的值是否是合法的纳税人识别号'
         else
          decode(T_RPT_RULEDATACHECKSTATICS.Rulechecktype,
                 'TABLEDATACHECK',
                 (select RULECODENAME
                    from t_meta_columnrule r
                   where r.ruleid = T_RPT_RULEDATACHECKSTATICS.ruleid
                     and r.messageid = T_RPT_RULEDATACHECKSTATICS.messageid
                     and r.columnids = T_RPT_RULEDATACHECKSTATICS.COLUMNID
                      and r.rulevesion = T_RPT_RULEDATACHECKSTATICS.Ruleversionid),
                     (select RULECODENAME
                    from t_meta_columnrule r
                   where r.ruleid = T_RPT_RULEDATACHECKSTATICS.ruleid
                     and r.messageid = T_RPT_RULEDATACHECKSTATICS.messageid
                     and r.columnid = T_RPT_RULEDATACHECKSTATICS.COLUMNID
                      and r.rulevesion = T_RPT_RULEDATACHECKSTATICS.Ruleversionid)
                     )
       end) RULECODENAME,
       COLUMNNAME,
       NOTPASSCOUNTS,
       to_char(STIME, 'yyyy-mm-dd hh24:mi:ss') STIME,
       ts.recordfilecreatetime,
       RULECHECKTYPE,RULEVERSIONID,(select ruleversion from t_meta_ruleversion t where t.ruleversionid=T_RPT_RULEDATACHECKSTATICS.Ruleversionid) as ruleversion
  from T_RPT_RULEDATACHECKSTATICS ,T_SYS_DATAFILEINFO ts
  where T_RPT_RULEDATACHECKSTATICS.FILEID=ts.fileid
 order by MESSAGEID, COLUMNID,RULECHECKTYPE,RULEID
/
