CREATE VIEW V_XXFW_YYQKFX AS select t.njzt qyzt,count(1) counts from credit_qyjbxx.t_qyjbxx t group by t.njzt
/
