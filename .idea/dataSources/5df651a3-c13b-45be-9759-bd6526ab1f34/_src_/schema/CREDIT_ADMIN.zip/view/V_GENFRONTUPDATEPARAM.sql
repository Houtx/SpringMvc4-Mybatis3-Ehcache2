CREATE VIEW V_GENFRONTUPDATEPARAM AS select 'update DEPT_' || v.DEPTABBR ||
       '.t_Sys_Parameter t set t.paramvalue=''N'' where t.paramname=''GATHER_XML''; ' as updatsql
  from v_Sys_Department v

  where v.DEPTABBR not in('HA','JS','HA_GCJS','HA_XINXI')
/
