CREATE VIEW V_STAT_METATABLERULESTATICS AS select
tc.deptname,
tc.messagename,
tc.columnname,
tc.dataitemname,
tc.messageid,
b.rulecode,b.rulecodename,b.ruleid,b.rulename,
tc.deptorderid,
tc.messageorderid,
tc.columnorderid,
('检查'||b.columnnames||'是否符合相关业务规则') as rulecodedesc
from
 (
 select b.*,
       c.rulename,
       c.ruledescription,
       fnc_columns_show(b.columnids) columnnames,
       b.isallowcolumnidspass,
       c.checkparamcount,
       c.ruleparamdescrption
  from t_meta_columnrule b, t_meta_rule c
 where b.ruleid = c.ruleid ) b ,
 (SELECT
       ts.deptname,
       a.messagename,
       a.tablename,
       b.*,
       ts.orderid as deptorderid,
       a.orderid as messageorderid,
       b.orderid as columnorderid
  from t_meta_table a, t_meta_column b,t_sys_department ts
 where a.messageid = b.messageid and a.deptid=ts.deptabbr
 order by ts.orderid,a.orderid,b.orderid) tc
     where
       b.columnids like  '%'||tc.columnid||'%'
/
