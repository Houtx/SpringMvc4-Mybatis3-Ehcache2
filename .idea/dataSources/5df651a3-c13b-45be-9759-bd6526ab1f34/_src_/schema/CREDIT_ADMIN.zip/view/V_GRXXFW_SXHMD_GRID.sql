CREATE VIEW V_GRXXFW_SXHMD_GRID AS select distinct grid from grcredit_xxfw.t_grxxfw_gjgxsxhmd where grid>0
union
select distinct grid from grcredit_xxfw.t_grxxfw_jtyzsxhmd where grid>0
union
select distinct grid from grcredit_xxfw.t_grxxfw_wmjtxx where grid>0
union
select distinct grid from grcredit_xxfw.t_grxxfw_sxzrrmd where grid>0
/
