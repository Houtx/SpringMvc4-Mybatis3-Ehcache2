CREATE VIEW V_SYS_ROLE AS select a.ID,a.ROLENAME,a.ISVALID,a.ROOFGARDEN,a.REMARK,a.CREATETIME,a.auditlevel,a.isonlyselflevel,
nvl(c.auditlevelname,'无')auditlevelname
from t_sys_role a ,T_SYS_SYSAUDITTYPE c
where a.auditlevel=c.auditlevel(+)
/
