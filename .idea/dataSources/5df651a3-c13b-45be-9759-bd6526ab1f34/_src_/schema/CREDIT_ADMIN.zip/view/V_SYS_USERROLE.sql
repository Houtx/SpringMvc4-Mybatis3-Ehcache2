CREATE VIEW V_SYS_USERROLE AS select a.userid,a.roleid ,b.rolename,b.roofgarden  from  t_sys_userrole a ,t_sys_role b
where  a.roleid=b.id and b.isvalid='Y'
/
