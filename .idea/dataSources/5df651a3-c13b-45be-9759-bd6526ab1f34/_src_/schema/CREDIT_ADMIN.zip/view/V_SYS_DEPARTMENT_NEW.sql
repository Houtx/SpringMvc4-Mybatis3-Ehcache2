CREATE VIEW V_SYS_DEPARTMENT_NEW AS SELECT (LPAD(' ', 4 * (LEVEL - 1), ' ┃ ') || ' ┣' || DEPTNAME)DEPTDISPLAYNAME,
    t."DEPTID",t."DEPTNAME",t."DEPTABBR",t."ORDERID",t."PLUGIN_FLAG",t."DEP_PARENTID",t."XZQHID",t."ISVALID",t."DEPTFULLNAME",t."INDATE",t."PAGEORDER",t."OFFICALNUM",t."DEPTSHORTNAME",t."DEPTSHORTABBR",t."QLYG", b.code, b.value,b.parentid
  FROM t_sys_department t,v_dict_xzqh b
 WHERE 1 = 1
 and t.isvalid='Y'
 AND t.xzqhid= b.code(+)
 --and t.dep_parentid='ZJ'
 --and t.plugin_flag='Y'
 START WITH (DEP_PARENTID = 'JS')
CONNECT BY PRIOR t.DEPTID = t.DEP_PARENTID
order  siblings  by  t.DEP_PARENTID, t.orderid asc
/
