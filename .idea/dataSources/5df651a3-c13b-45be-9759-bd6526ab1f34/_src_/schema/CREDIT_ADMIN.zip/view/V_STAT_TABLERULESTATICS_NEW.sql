CREATE VIEW V_STAT_TABLERULESTATICS_NEW AS select deptname     as 部门名称,
       messageid,
       messagename  as 归集信息类名称,
       dataitemname as 归集字段名称,
       rulecode     as 规则代码,
       rulecodedesc as 规则代码描述,
       rulename     as 使用的检查函数名称
  from (select *
          from v_stat_metacolumnrulestatics t1
        union
        select * from v_stat_metatablerulestatics t2) t
 order by t.deptorderid, t.deptname,t.messageorderid, t.columnorderid
/
