CREATE VIEW V_STAT_SGS AS select deptname,bsrq_xk_max,bsrq_cf_max,xkrq_max,cfrq_max,cq_frxk+cq_grxk xkcq,cq_frcf+cq_grcf cfcq from t_sgs_stat_everyday t where t.tjrq=trunc(sysdate) order by orderid
/
