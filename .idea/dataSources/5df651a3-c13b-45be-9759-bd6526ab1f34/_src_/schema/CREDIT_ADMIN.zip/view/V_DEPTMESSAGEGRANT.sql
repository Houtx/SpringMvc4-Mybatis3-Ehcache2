CREATE VIEW V_DEPTMESSAGEGRANT AS select 'delete from ' || t.username || '.t_sys_roleupload;' || chr(13) ||
       'commit;' || chr(13) || 'insert into ' || t.username ||
       '.t_sys_roleupload  select ''5e304e1d-d279-4996-a6b4-7d3a13808c7e'', messageid, ''y'', ''y'' from ' ||
       t.username || '.t_meta_table;' || chr(13) || 'commit;' || chr(13) as DeptMessageGrant
  from all_users t
 where t.username like 'DEPT_%'
/
