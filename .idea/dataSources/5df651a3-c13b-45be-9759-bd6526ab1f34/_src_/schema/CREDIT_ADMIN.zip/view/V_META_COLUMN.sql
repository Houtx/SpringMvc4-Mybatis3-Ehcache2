CREATE VIEW V_META_COLUMN AS SELECT a.deptid,a.domainid,a.tablename,a.messagename,a.orderid tabno,b."MESSAGEID",b."COLUMNID",b."COLUMNNAME",b."DATAITEMNAME",b."DATATYPE",b."LENGTH",b."PRECISION",b."ISNULL",b."ISPK",b."ISUSE",b."DICTNAME",b."UNIT",b."ORDERID",b."CREATETIME",b."UPDATETIME",b."STOPTIME",b."ISVISIBLE",b."ISOFFICAL" from t_meta_table a,t_meta_column b where a.messageid=b.messageid
/
