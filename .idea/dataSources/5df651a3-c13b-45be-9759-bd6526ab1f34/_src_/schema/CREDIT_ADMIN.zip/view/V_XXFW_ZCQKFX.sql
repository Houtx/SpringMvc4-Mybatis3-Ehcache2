CREATE VIEW V_XXFW_ZCQKFX AS select to_char(slrq, 'YYYY') slnf, count(*) cnt
  from credit_qyjbxx.t_qyjbxx
 group by to_char(slrq, 'YYYY')
/
