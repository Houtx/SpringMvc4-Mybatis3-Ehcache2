CREATE VIEW V_TJBMXXL AS select d.deptname,t.messagename,
(select nvl(count(df.fileid),0) from t_sys_datafilegroups df where df.finished='Y' and df.messageid=t.messageid)cnt
from t_sys_department d,t_meta_table t
where d.deptabbr=t.deptid and d.isqx in('3','5')
order by d.orderid,d.deptabbr,t.orderid
/
