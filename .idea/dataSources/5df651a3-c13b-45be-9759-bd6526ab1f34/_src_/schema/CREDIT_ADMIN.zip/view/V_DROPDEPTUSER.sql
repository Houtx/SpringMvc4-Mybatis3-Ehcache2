CREATE VIEW V_DROPDEPTUSER AS select 'drop user DEPT_' || ts.deptabbr || ' cascade;' || chr(13) ||
       'drop user MID_' || ts.deptabbr || ' cascade;' as dropdeptusersl
  from t_Sys_Department ts
 where ts.deptid not in('SX','HA','JS','HA_XINXI')
/
