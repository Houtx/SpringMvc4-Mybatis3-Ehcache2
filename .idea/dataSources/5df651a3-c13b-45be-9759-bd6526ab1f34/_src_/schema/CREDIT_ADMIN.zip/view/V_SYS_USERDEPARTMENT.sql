CREATE VIEW V_SYS_USERDEPARTMENT AS select (LPAD(' ', 4 * (LEVEL - 1), ' ┃ ') || ' ┣' || t1.DEPTNAME)DEPTDISPLAYNAME,
       (LEVEL)deptlevel,
       t1.dep_parentid as parentid,t1."DEPTID",t1."DEPTNAME",t1."DEPTABBR",t1."ORDERID",
       t1."PLUGIN_FLAG",t1."DEP_PARENTID",t1."XZQHID",t1."ISVALID",t1."DEPTFULLNAME",
       t1."INDATE",t1."PAGEORDER",t1."OFFICALNUM",t1."DEPTSHORTNAME",t1."DEPTSHORTABBR",
       t1."QLYG",t1."DATAFLAG",t1."ISQX"
from(
       select t.*
       from t_sys_department t
       where t.isvalid='Y'
       union all
       select td.isqx,td.deptyname,null,null,null,null,null,
              null,null,null,null,null,null,null,null,null,
              td.par_isqx
       FROM t_sys_departType td
       where td.isqx is not null
    ) t1
start with (t1.isqx = 'JS')
connect by prior  t1.deptid = t1.isqx
order  siblings  by  t1.DEP_PARENTID, t1.orderid asc
/
