CREATE VIEW V_MENU AS SELECT (LPAD(' ', 4 * (LEVEL - 1), ' ┃ ') || ' ┣' || name)MENUNAME,
      name
      ,
      id,
      parent,
      url,
      menuorder
  FROM t_Sys_Resource t
 WHERE 1 = 1
 and t.isvalid='Y'
 START WITH (parent = '99999')
CONNECT BY PRIOR t.id = t.parent
order  siblings  by  t.parent, t.menuorder asc
/
