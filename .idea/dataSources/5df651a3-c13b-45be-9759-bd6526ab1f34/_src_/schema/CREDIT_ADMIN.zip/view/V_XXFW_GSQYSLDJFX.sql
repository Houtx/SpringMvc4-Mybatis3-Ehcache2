CREATE VIEW V_XXFW_GSQYSLDJFX AS select to_char(slrq, 'YYYY') slnf, to_char(slrq, 'MM') slyf, count(*) cnt
  from credit_qyjbxx.t_qyjbxx
 group by to_char(slrq, 'YYYY'),  to_char(slrq, 'MM')
/
