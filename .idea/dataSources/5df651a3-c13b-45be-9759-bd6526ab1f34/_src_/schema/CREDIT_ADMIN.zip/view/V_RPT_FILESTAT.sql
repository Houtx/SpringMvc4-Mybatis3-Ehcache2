CREATE VIEW V_RPT_FILESTAT AS (
select td.deptabbr deptid,
       td.deptname,
       td.orderid deptorderid,
       tt.messageid,
       tt.messagename,
       tt.orderid messorderid,
       trf.createtime,
       nvl(tsd.rawrecordfilerecordcounts,0) rawcounts,---部门前置原始提供记录数
       nvl(tsd.recordfilerecordcounts,0) xmlfilereccounts,---提交中心xml文件中的记录数
       nvl(trf.incchkerrcount,0) repeat_invalidcounts_dept,---前置处理疑问记录-重复疑问记录数
       nvl(trf.fmtchkerrcount,0) fmt_invalidcounts_dept,---前置处理疑问记录-格式疑问记录数
       nvl(trc.incrementrecordcounts,0) inccounts_one,--第一次增量记录数
       nvl(trc.notincrementrecordcounts,0) not_inccounts_one,--第一次非增量记录数
       nvl(trc.centerincrementrecordcounts,0) inccounts_two,--第二次增量记录数
       nvl(trc.centernotincrementrecordcounts,0) not_inccounts_two,--第二次非增量记录数
       nvl(trcc.validrecordcounts,0) validcounts,----有效记录数
       nvl(trcc.validrecordcounts,0) indbcounts,---入库记录数
       nvl(trcc.invalidrecordcounts,0) invalidcounts,----中心处理疑问记录数
       nvl(trcc.logicinvalidrecordcounts,0) logic_invalidcounts,-----中心处理疑问记录数-逻辑疑问记录数
       nvl(tra.connectcount,0) ccounts,----关联记录数
       nvl(tra.notconnectcount,0) notconnectcount----未关联记录数
  from t_sys_department          td,
       t_meta_table              tt,
       t_sys_datafileinfo        tsd,
       t_rpt_frontprocess        trf,
       t_rpt_cincrementdatacheck trc,
       t_rpt_cdatacheck          trcc,
       t_rpt_associatestatistics tra
 where td.deptabbr = tt.deptid
   and tt.messageid = tsd.messageid
   and tsd.fileid = trc.recordfileid(+)
   and tsd.fileid=trf.processid(+)
   and tsd.fileid = trcc.fileid(+)
   and tsd.fileid = tra.recordfileid(+)
)
/
