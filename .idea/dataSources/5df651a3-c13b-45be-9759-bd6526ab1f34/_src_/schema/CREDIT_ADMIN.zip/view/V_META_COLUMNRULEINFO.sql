CREATE VIEW V_META_COLUMNRULEINFO AS select
       tt.deptid,
       tt.messagename,
       tc.dataitemname,
       tc.datatype,
       tc.dictname,
       tc.isnull,
       tc.isuse,
       (select rulename from T_META_RULE where ruleid = tcr.ruleid) rulename
       ,tcr.rulecode
  from t_meta_columnrule tcr, T_META_TABLE tt, T_META_COLUMN tc
 where tt.messageid = tcr.messageid
   and tcr.columnid = tc.columnid
   and tc.messageid = tt.messageid
   and tcr.columnid is not null
   and tcr.iscolumnuse = 'Y'
   --and tt.deptid='ZHIJIAN'
   order by tcr.messageid,tcr.columnid
/
