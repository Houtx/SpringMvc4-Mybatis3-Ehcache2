CREATE VIEW V_SYS_TABLE AS select a."DEPTID",a."DOMAINID",a."MESSAGEID",a."MESSAGENAME"
,a."MESSAGEABBR",a."TABLENAME",a."TABLETYPE",a."ISUSE"
,a."ORDERID",a."GATHERPERIOD",a."CREATETIME",a."VERSION"
,a."UPDATEDATE",a."MESSAGESHORTNAME",a."HISTABLENAME"
,a."HISORDERS",a."STAFLAG"
,fnc_splitvalue2name(a.domainid,'select domainname from t_meta_appdomain where DOMAINID',',') domainname
, fnc_splitvalue2name(a.domainid,
                           'select domaintype from t_meta_appdomain where DOMAINID',
                           ',') domaintype,
       a.Messagetype,e.typename gatherperiodname,
      -- 'T_' || a.deptid || '_' || a.tablename realname,
       c.value tabletypename,
       b.deptid as departmentid,
       a.tgtype
  from t_meta_table a, t_sys_department b, t_dict_tabletype c,T_DICT_GATHERPERIOD e
 where a.deptid = b.deptabbr
   and a.tabletype = c.code(+)
   and a.gatherperiod=e.typecode(+)
/
