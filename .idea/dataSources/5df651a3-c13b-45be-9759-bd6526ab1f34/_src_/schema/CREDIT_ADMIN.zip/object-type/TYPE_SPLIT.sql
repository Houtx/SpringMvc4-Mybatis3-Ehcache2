CREATE TYPE "TYPE_SPLIT"                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               as table of VARCHAR2(4000)


/
