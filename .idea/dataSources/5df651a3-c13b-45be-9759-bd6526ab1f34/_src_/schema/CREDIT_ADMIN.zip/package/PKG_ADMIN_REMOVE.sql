CREATE package PKG_ADMIN_REMOVE is

  -- Author  : JASON
  -- Created : 2012-11-13 16:06:38
  -- Purpose : 删除数据库对象

  /*
  create table T_SYS_REMOVELOG(
    LOG_ID varchar2(32) primary key,
    REMOVE_TYPE varchar2(20),
    OBJECT_NAME varchar2(200),
    OBJECT_ID varchar2(50),
    OBJECT_CONTENT varchar2(1000),
    OPERATE_ERR number,
    REMOVE_TIME date
  );
  
  create table T_SYS_REMOVELOG_DETAIL(
    LOG_ID varchar2(32), 
    LOG_SQL varchar2(4000), 
    LOG_ERR varchar2(4000)
   );
   create index I_SYS_REMOVELOG_DETAIL 
   on T_SYS_REMOVELOG_DETAIL(LOG_ID);
    
  
  */

  --删除采集表
  procedure remove_table(messageid in varchar2);
  
  procedure remove_table_column(messageid in varchar2,columnid in varchar2);
  

end PKG_ADMIN_REMOVE;
/
