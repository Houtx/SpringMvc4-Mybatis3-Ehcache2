CREATE package P_BMGJKH is
  PROCEDURE P_kh_task_job;
  PROCEDURE P_kh_task;
  PROCEDURE P_kh_task_hs(V_deptid    varchar,
                         V_domainid  varchar,
                         V_messageid varchar,
                         V_times     varchar,
                         v_taskparams varchar,
                         V_taskid    varchar);
  PROCEDURE P_kh_xxtgfs(v_deptid    varchar,
                        v_domainids  varchar,
                        v_messageids varchar,
                        V_STATTIME   varchar,
                        V_ENDTIME    varchar,
                        V_taskid     varchar,
                        v_pzid       varchar,
                        v_khid       varchar);
  PROCEDURE P_kh_xxgfx(v_deptid    varchar,
                        v_domainids  varchar,
                        v_messageids varchar,
                        V_STATTIME   varchar,
                        V_ENDTIME    varchar,
                        V_taskid     varchar,
                        v_pzid       varchar,
                        v_khid       varchar);
  PROCEDURE P_kh_zqx(v_deptid    varchar,
                        v_domainids  varchar,
                        v_messageids varchar,
                        V_STATTIME   varchar,
                        V_ENDTIME    varchar,
                        V_taskid     varchar,
                        v_pzid       varchar,
                        v_khid       varchar);
 function  zqxgss (dfbalue in varchar2, zql in number ) return number  ;
 
 PROCEDURE P_kh_wzx(v_deptid    varchar,
                        v_domainids  varchar,
                        v_messageids varchar,
                        V_STATTIME   varchar,
                        V_ENDTIME    varchar,
                        V_taskid     varchar,
                        v_pzid       varchar,
                        v_khid       varchar);
 
 PROCEDURE P_kh_sxx(v_deptid    varchar,
                        v_domainids  varchar,
                        v_messageids varchar,
                        V_STATTIME   varchar,
                        V_ENDTIME    varchar,
                        v_taskparams varchar,
                        V_taskid     varchar,
                        v_pzid       varchar,
                        v_khid       varchar);

                        
PROCEDURE P_kh_yy(v_deptid    varchar,
                        v_domainids  varchar,
                        v_messageids varchar,
                        V_STATTIME   varchar,
                        V_ENDTIME    varchar,
                        V_taskid     varchar,
                        v_pzid       varchar,
                        v_khid       varchar);                        


--判断时间差                        
function f_sjc(V_STATTIME in varchar2, V_ENDTIME in varchar2) return number;


---获取时间段
function f_shd(v_statperiod in varchar2) return varchar2;

end P_BMGJKH;
/
