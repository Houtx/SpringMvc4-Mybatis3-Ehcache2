CREATE package body P_BMGJKH is
      PROCEDURE P_kh_task_job is
        V_JOBID T_META_PROCEDURE.JOBID%TYPE; --创建JOB时指定的JOBID
        V_SQL   VARCHAR2(1000);
        begin
          V_SQL := 'begin
                 sys.dbms_job.submit(:jobid,
                                what => ''begin P_BMGJKH.P_kh_task; end;'',
                                interval =>''sysdate+10/(60*24*60)'');
                 commit;
                 end;';
          EXECUTE IMMEDIATE V_SQL  USING OUT V_JOBID;
        COMMIT;
      end P_kh_task_job;

      PROCEDURE P_kh_task is
        RESULT VARCHAR2(4000);
        v_count integer;
        V_deptids   VARCHAR2(4000);
        V_domainids   VARCHAR2(4000);
        V_messageids   VARCHAR2(4000);
        v_taskparams     t_ks_task.taskparams%type;
        V_times   VARCHAR2(4000);
        V_jshs   VARCHAR2(4000);
        V_SQL   VARCHAR2(1000);
        V_taskid VARCHAR2(50);
        v_pzid t_ks_gjkhpz.pzid%type;
        V_JOBID t_ks_task.JOBID%TYPE; --创建JOB时指定的JOBID
        begin
          select count(*) into v_count from t_ks_task t where t.taskstate='1';
          if(v_count=0)then
              select t.taskid, t.kh_deptids,t.kh_domainids,t.kh_messageids,t.kh_times,t.taskparams,tg.jshs,t.pzid
              into V_taskid,V_deptids,V_domainids,V_messageids,V_times,v_taskparams,V_jshs,v_pzid
              from t_ks_task t, t_ks_gjkhpz tg
             where t.taskstate = '0'
               and t.pzid = tg.pzid
               and t.tasktime =
                   (select min(tasktime) from t_ks_task where taskstate = '0');
           V_SQL := 'begin
                 sys.dbms_job.submit(:jobid,
                                what => ''begin '||V_jshs ||
                                '( ''''' ||V_deptids||''''','''''||V_domainids||
                                ''''','''''||V_messageids||''''','''''||V_times||''''','''''||v_taskparams||''''','''''||V_taskid||'''''); end;'',
                                interval =>''null'');
                 commit;
                 end;';
          EXECUTE IMMEDIATE V_SQL USING OUT V_JOBID;
          update t_ks_task t set t.taskstate='1' ,  t.taskstime=sysdate , t.jobid=V_JOBID where t.taskid=V_taskid;
          update t_ks_gjkhpz t set t.isuseed='Y' where t.pzid=v_pzid;
          commit;
          end if;
      EXCEPTION
        When others then
           RESULT:=sqlerrm(SqlCode);
           update t_ks_task t set t.taskstate='2' , t.Tasketime=sysdate,t.taskresult='E' ,t.taskresultdesc=RESULT  where t.taskid=V_taskid;
      end P_kh_task;

     PROCEDURE P_kh_task_hs(V_deptid varchar,V_domainid varchar,V_messageid varchar,V_times varchar,v_taskparams varchar,V_taskid varchar) is
        RESULT VARCHAR2(4000);
        V_SQL VARCHAR2(4000);
        v_j             integer;
        v_deptiddarray  ty_str_split;
        v_domainidarray ty_str_split;
        v_messageidarray ty_str_split;
        v_timesarray      ty_str_split;
        v_deptidlength        integer;
        v_domainidlength        integer;
        v_messageidlength        integer;
        v_timeslength        integer;
        v_domainids     varchar2(100);
        v_deptids       varchar2(4000);
        v_messageids    varchar2(4000);
        vdeptid       t_sys_department.deptabbr%type;
        vdeptname     t_sys_department.deptname%type;
        vorderid      t_sys_department.orderid%type;
        V_STATTIME      VARCHAR2(50);
        V_ENDTIME       VARCHAR2(50);
        type record_cur_type is ref cursor;
        record_cur record_cur_type;
        v_pzid          t_ks_task.pzid%type;
        v_khid          VARCHAR2(50);
     begin
            select t.pzid into v_pzid from t_ks_task t where taskid=V_taskid;
            ---domainid
            v_domainidarray := FN_SPLIT(v_domainid, ',');
            v_domainidlength  := v_domainidarray.COUNT;
            v_j       := 1;
            WHILE v_j <= v_domainidlength LOOP
              if v_j = 1 then
                v_domainids := v_domainids || 'and ( ';
              else
                v_domainids := v_domainids || ' or ';
              end if;
              v_domainids := v_domainids || ' tt.DOMAINID like ''%' ||
                             replace(v_domainidarray(v_j),' ','') || '%''';
               if v_j = v_domainidlength then
                v_domainids := v_domainids || ' ) ';
               end if;
              v_j         := v_j + 1;
            END LOOP;
            -----deptid
            v_j:=0;
            v_deptiddarray := FN_SPLIT(v_deptid, ',');
            v_deptidlength  := v_deptiddarray.COUNT;
            v_j       := 1;
            WHILE v_j <= v_deptidlength LOOP
              if v_j = 1 then
                v_deptids := v_deptids || 'and tt.deptid in ( ';
              else
                v_deptids := v_deptids || ', ';
              end if;
              v_deptids := v_deptids || '''' || v_deptiddarray(v_j) || '''';
             if v_j = v_deptidlength  then
                v_deptids := v_deptids || ' ) ';
             end if;
              v_j         := v_j + 1;
            END LOOP;
             -----messageid
            v_j:=0;
            v_messageidarray := FN_SPLIT(V_messageid, ',');
            v_messageidlength  := v_messageidarray.COUNT;
            v_j       := 1;
            WHILE v_j <= v_messageidlength LOOP
              if v_j = 1 then
                v_messageids := v_messageids || 'and tt.messageid in ( ';
              else
                v_messageids := v_messageids || ', ';
              end if;
              v_messageids := v_messageids || '''' || v_messageidarray(v_j) || '''';
             if v_j = v_messageidlength  then
                v_messageids := v_messageids || ' ) ';
             end if;
              v_j         := v_j + 1;
            END LOOP;

            -----times
            v_timesarray := FN_SPLIT(V_times, ',');
            v_timeslength:=v_timesarray.COUNT;
            if v_timeslength=2 then
                v_stattime:=v_timesarray(1);
                v_endtime:=v_timesarray(2);
            elsif v_timeslength=1 and  SUBSTR(V_times,1,1)=',' then
                v_endtime:=v_timesarray(1);
            elsif v_timeslength=1 then
                v_stattime:=v_timesarray(1);
            end if;
            V_SQL := ' select distinct tt.deptid,td.deptname,td.orderid
                        from t_sys_department td, t_meta_table tt
                       where td.deptabbr = tt.deptid ';
            if v_domainids is not null or v_domainid <> ' ' then
              V_SQL := V_SQL || v_domainids;
            end if;
            if v_deptids is not null or v_deptid <> ' ' then
              V_SQL := V_SQL || v_deptids;
            end if;
            if v_messageids is not null or v_messageids <> ' ' then
              V_SQL := V_SQL || v_messageids;
            end if;
              V_SQL := V_SQL||' order by td.orderid,td.deptname,tt.deptid ';
           OPEN record_cur FOR
             V_SQL;
           LOOP
               FETCH record_cur INTO vdeptid,vdeptname,vorderid;
                 EXIT WHEN record_cur%NOTFOUND;
                 v_khid:=sys_guid();
                 insert into T_KH_JG_KHZF(khid,TASKID,Pzid,DEPTID,TGFS_SCORE,GFX_SCORE,ZQX_SCORE,WZX_SCORE,SXX_SCORE,YY_SCORE,CREATETIME,ISMODIFY,EXPTCOUNTS)values(v_khid,V_taskid,v_pzid,vdeptid,0,0,0,0,0,0,sysdate,'N',0);
                 COMMIT ;
                 insert into T_KH_TASKLOGS(logid,Taskid,LOGDETAIL,Logtime)values(sys_guid(),V_taskid,'开始计算'||vdeptname||'信息提供方式',sysdate);
                 ----信息提供方式
                 P_BMGJKH.P_kh_xxtgfs(vdeptid,v_domainids,v_messageids,V_STATTIME,V_ENDTIME,V_taskid,v_pzid ,v_khid ) ;
                 insert into T_KH_TASKLOGS(logid,Taskid,LOGDETAIL,Logtime)values(sys_guid(),V_taskid,'信息提供方式计算结束,开始计算'||vdeptname||'信息规范性',sysdate);
                 ----信息规范性
                 P_BMGJKH.P_kh_xxgfx(vdeptid,v_domainids,v_messageids,V_STATTIME,V_ENDTIME,V_taskid,v_pzid ,v_khid ) ;
                 insert into T_KH_TASKLOGS(logid,Taskid,LOGDETAIL,Logtime)values(sys_guid(),V_taskid,'信息规范性计算结束,开始计算'||vdeptname||'信息准确性',sysdate);
                 --信息准确性
                 P_BMGJKH.P_kh_zqx(vdeptid,v_domainids,v_messageids,V_STATTIME,V_ENDTIME,V_taskid,v_pzid ,v_khid ) ;
                 insert into T_KH_TASKLOGS(logid,Taskid,LOGDETAIL,Logtime)values(sys_guid(),V_taskid,'信息准确性计算结束,开始计算'||vdeptname||'信息完整性',sysdate);
                 --信息完整性
                 P_BMGJKH.P_kh_wzx(vdeptid,v_domainids,v_messageids,V_STATTIME,V_ENDTIME,V_taskid,v_pzid ,v_khid ) ;
                 insert into T_KH_TASKLOGS(logid,Taskid,LOGDETAIL,Logtime)values(sys_guid(),V_taskid,'信息完整性计算结束,开始计算'||vdeptname||'信息时效性',sysdate);
                  --信息时效性
                  P_BMGJKH.P_kh_sxx(vdeptid,v_domainids,v_messageids,V_STATTIME,V_ENDTIME,v_taskparams,V_taskid,v_pzid ,v_khid ) ;
                 insert into T_KH_TASKLOGS(logid,Taskid,LOGDETAIL,Logtime)values(sys_guid(),V_taskid,'信息时效性计算结束,开始计算'||vdeptname||'信息完整性',sysdate);
                 --信息完整性
                 P_BMGJKH.P_kh_yy(vdeptid,v_domainids,v_messageids,V_STATTIME,V_ENDTIME,V_taskid,v_pzid ,v_khid ) ;          
                 insert into T_KH_TASKLOGS(logid,Taskid,LOGDETAIL,Logtime)values(sys_guid(),V_taskid,vdeptname||'信息完整性计算结束',sysdate);
              
              END LOOP;
           update t_ks_task t set t.taskstate='2' , t.Tasketime=sysdate,t.taskresult='S'   where t.taskid=V_taskid;
     	 EXCEPTION
        When others then
           RESULT:=sqlerrm(SqlCode);
           update t_ks_task t set t.taskstate='2' , t.Tasketime=sysdate,t.taskresult='E' ,t.taskresultdesc=RESULT  where t.taskid=V_taskid;
     end P_kh_task_hs;

 --信息提供方式考核
 PROCEDURE P_kh_xxtgfs(v_deptid     varchar,
                       v_domainids  varchar,
                       v_messageids varchar,
                       V_STATTIME   varchar,
                       V_ENDTIME    varchar,
                       V_taskid     varchar,
                       v_pzid       varchar,
                       v_khid       varchar) is
   RESULT      VARCHAR2(4000);
   V_SQL       VARCHAR2(4000);
   V_SQL1      VARCHAR2(4000);
   v_tgfstypes varchar2(50);
   type record_cur_type is ref cursor;
   record_cur     record_cur_type;
   record_cur_mes record_cur_type;
   vdeptid        t_meta_table.deptid%type;
   vmessageid     t_meta_table.messageid%type;
   v_tgfsid       t_kh_jg_tgfs.tgfsid%type;
   v_mxid         t_kh_jg_tgfsmx.mxid%type;
   v_zbid         t_kh_jg_tgfsmx.zbid%type;
   v_pz_score     t_kh_jg_tgfsmx.pz_score%type;
   v_zbname       t_kh_jg_tgfsmx.zbname%type;
   v_tgfs_verid   t_kh_jg_tgfsmx.tgfs_verid%type;
   --v_tgfs_verid1  T_KH_JG_TGFS.TGFS_VERID%type := ' ';
   v_js_score     t_kh_jg_tgfsmx.js_score%type;
   v_TZQ_SCORE    t_kh_jg_tgfs.tzq_score%type := 0;
   V_WEIGHT       t_kh_jg_tgfs.Weight%type := 0;
   v_i            integer := 0;
   v_exit         integer := 0;
   v_zqs          varchar2(50);
   v_params       ty_str_split;
   V_STATTIME_new   varchar2(20);
   V_ENDTIME_new    varchar2(20);
   v_zq_stattime  varchar2(20);--周期开始时间
   v_zq_endtime   varchar2(20);--周期结束时间
   v_statperiod   varchar2(20);
   ---获取时间段内的月份
   cursor cur_months(P_STATTIME varchar2,P_ENDTIME varchar2) is 
         SELECT TO_CHAR(ADD_MONTHS(TO_DATE(substr(P_STATTIME,0,7), 'YYYY-MM'), ROWNUM - 2),
                 'YYYY-MM') statperiod
      FROM DUAL
    CONNECT BY ROWNUM <=
               months_between(to_date(substr(P_ENDTIME,0,7), 'yyyy-mm'),
                              ADD_MONTHS(to_date(substr(P_STATTIME,0,7), 'yyyy-mm'), -1)) + 2;
 begin   
   V_SQL := ' select  tt.deptid,tt.messageid from t_sys_department td, t_meta_table tt where td.deptabbr = tt.deptid and tt.deptid= ''' ||
            v_deptid || '''' || v_domainids || v_messageids ||
            ' order by td.orderid,tt.orderid ';
   ---遍历信息类
   OPEN record_cur FOR V_SQL;
   LOOP
     FETCH record_cur
       INTO vdeptid, vmessageid;
     EXIT WHEN record_cur%NOTFOUND;
    
    V_STATTIME_new:=V_STATTIME||' 00:00:00'; 
    V_ENDTIME_new:=V_ENDTIME||' 23:59:59';
    --判断是否存在给信息类的配置
     select COUNT(*)
       into v_exit
       from t_ks_message t
      where t.messageid = vmessageid
        and t.isuse = 'Y'
        AND T.PZLX = '1';
     if (v_exit > 0) then
       v_tgfsid := sys_guid();  
       select t.khid  
       into v_tgfs_verid
       from t_ks_message t
      where t.messageid = vmessageid
        and t.isuse = 'Y'
        AND T.PZLX = '1';  
         select t.mw
         into V_WEIGHT
         from t_ks_message t
        where t.khid = v_tgfs_verid;   
       insert into T_KH_JG_TGFS
         (TGFSID,
          KHID,
          TASKID,
          DEPTID,
          MESSAGEID,
          WEIGHT,
          PZID,
          TGFS_VERID,
          TZQ_SCORE,
          TZH_SCORE,
          TOTAL_SCORE,
          CREATETIME)
       values
         (v_tgfsid,
          v_khid,
          V_taskid,
          vdeptid,
          vmessageid,
          V_WEIGHT,
          v_pzid,
          v_tgfs_verid,
          0,
          0,
          0,
          sysdate);
      /* V_SQL1 := 'select distinct  t.deptid , t.messageid,tkd.khid, tkd.pzid, tkd.dfname, tkd.dfvalue' ||
                 ' from (select distinct  tt.deptid , tt.messageid, tt.tgfstype' ||
                 ' from (select tsd.*,' || '  case' ||
                 '    when tf.statperiod is null then' ||
                 '     tsd.recordfilecreatetime' || '     else' ||
                 '     tf.statperiod' || '  end as stattime' ||
                 ' from t_sys_datafileinfo tsd, t_stat_filetimeconfig tf' ||
                 '   where tsd.fileid = tf.fileid(+)) tt where tt.messageid=''' ||
                 vmessageid || '''';
       if v_stattime is not null or v_stattime <> ' ' then
         V_SQL1 := V_SQL1 ||
                   ' and to_date(to_char(tt.stattime, ''yyyy-mm-dd''),''yyyy-mm-dd'') >=to_date(''' ||
                   v_stattime || ''', ''yyyy-mm-dd'')';
       end if;
       if v_endtime is not null or v_endtime <> ' ' then
         V_SQL1 := V_SQL1 ||
                   ' and to_date(to_char(tt.stattime, ''yyyy-mm-dd''), ''yyyy-mm-dd'') <=to_date(''' ||
                   v_endtime || ''', ''yyyy-mm-dd'')';
       end if;
       V_SQL1 := V_SQL1 ||
                 ') t, t_ks_message tkm,t_ks_message_dfpz tkd where t.messageid = tkm.messageid' ||
                 ' and t.tgfstype = tkd.dfcode and tkm.khid = tkd.khid  and tkm.pzlx = ''1''' ||
                 ' and tkm.isuse = ''Y'' and t.messageid=''' || vmessageid || '''' ||
                 ' group by  t.deptid ,t.messageid,tkd.khid,tkd.pzid, tkd.dfname, tkd.dfvalue' ||
                 ' order by  t.deptid ,t.messageid, tkd.dfvalue desc';
       v_i    := 0;
       OPEN record_cur_mes FOR V_SQL1;
       LOOP
         FETCH record_cur_mes
           INTO vdeptid,
                vmessageid,
                v_tgfs_verid,
                v_zbid,
                v_zbname,
                v_pz_score;
         EXIT WHEN record_cur_mes%NOTFOUND;
         v_i        := v_i + 1;
         v_mxid     := sys_guid();
         v_js_score := v_pz_score;
         insert into T_KH_JG_TGFSMX
           (MXID,
            TGFSID,
            KHID,
            TASKID,
            DEPTID,
            MESSAGEID,
            ZBID,
            PZ_SCORE,
            ZBNAME,
            TGFS_VERID,
            JS_SCORE,
            CREATETIME)
         values
           (v_mxid,
            v_tgfsid,
            v_khid,
            V_taskid,
            vdeptid,
            vmessageid,
            v_zbid,
            v_pz_score,
            v_zbname,
            v_tgfs_verid,
            v_js_score,
            sysdate);
         if v_TZQ_SCORE < v_js_score then
           v_TZQ_SCORE   := v_js_score;
           v_tgfs_verid1 := v_tgfs_verid;
         end if;
       END LOOP;
       if (v_i = 0) then
         v_mxid := sys_guid();
         select tkd.khid, tkd.pzid, tkd.dfname, tkd.dfvalue
           into v_tgfs_verid, v_zbid, v_zbname, v_pz_score
           from t_ks_message tkm, t_ks_message_dfpz tkd
          where tkm.khid = tkd.khid
            and tkm.pzlx = '1'
            and tkm.isuse = 'Y'
            and messageid = vmessageid
            and dfcode = 'NWWSJKDJFS';
         v_js_score := v_pz_score;
         insert into T_KH_JG_TGFSMX
           (MXID,
            TGFSID,
            KHID,
            TASKID,
            DEPTID,
            MESSAGEID,
            ZBID,
            PZ_SCORE,
            ZBNAME,
            TGFS_VERID,
            JS_SCORE,
            CREATETIME)
         values
           (v_mxid,
            v_tgfsid,
            v_khid,
            V_taskid,
            vdeptid,
            vmessageid,
            v_zbid,
            v_pz_score,
            v_zbname,
            v_tgfs_verid,
            v_js_score,
            sysdate);
         v_TZQ_SCORE := v_js_score;
       end if;
       select t.mw
         into V_WEIGHT
         from t_ks_message t
        where t.khid = v_tgfs_verid;
       update T_KH_JG_TGFS t
          set t.weight      = V_WEIGHT,
              T.TGFS_VERID  = v_tgfs_verid1,
              t.tzq_score   = v_TZQ_SCORE,
              t.tzh_score   = v_TZQ_SCORE,
              t.total_score = V_WEIGHT * v_TZQ_SCORE
        where t.tgfsid = v_tgfsid;
       ---配置设置已经使用
       update t_ks_message tkm
          set tkm.isuseed = 'Y'
        where tkm.Messageid = vmessageid
          and tkm.pzlx = '1'
          and tkm.isuse = 'Y';*/
          ---遍历月份周期
         FOR rd in cur_months(V_STATTIME_new,V_ENDTIME_new) loop
             v_statperiod:=rd.statperiod;
             v_zqs:=f_shd(v_statperiod);
             if(v_zqs!='-1')then 
                 v_params := FN_SPLIT(v_zqs, ',');
                 v_zq_stattime:=v_params(1);
                 v_zq_endtime:=v_params(2);
                 ---判断时间是否在该时间段内
                 if (to_date(V_STATTIME_new,'YYYY-MM-DD HH24:MI:SS')>=TO_DATE(v_zq_stattime,'YYYY-MM-DD HH24:MI:SS') and to_date(V_STATTIME_new,'YYYY-MM-DD HH24:MI:SS')<=TO_DATE(V_ENDTIME_new,'YYYY-MM-DD HH24:MI:SS')) then
                   v_zq_stattime:=V_STATTIME_new;
                   if(to_date(V_ENDTIME_new,'YYYY-MM-DD HH24:MI:SS')<TO_DATE(v_zq_endtime,'YYYY-MM-DD HH24:MI:SS'))then 
                      v_zq_endtime:=V_ENDTIME_new;                                  
                   end if;
/*                   if(to_date(v_zq_stattime,'YYYY-MM-DD HH24:MI:SS')<TO_DATE(V_ENDTIME_new,'YYYY-MM-DD HH24:MI:SS'))then
*/                       V_STATTIME_new:=to_char(add_months(TO_DATE(v_params(1),'YYYY-MM-DD HH24:MI:SS'),1),'YYYY-MM-DD HH24:MI:SS');
/*                   end if;
*/                   V_SQL1 :='select nvl(avg(t2.dfvalue),0)
                              from (select tsd.*,' || '  case' ||
                           '    when tf.statperiod is null then' ||
                           '     tsd.recordfilecreatetime' || '     else' ||
                           '     tf.statperiod' || '  end as stattime' ||
                           ' from t_sys_datafileinfo tsd, t_stat_filetimeconfig tf' ||
                           '   where tsd.fileid = tf.fileid(+))  t,
                                   (select TKD.DFCODE, TKD.DFVALUE
                                      from t_ks_message tkm, t_ks_message_dfpz tkd
                                     where tkm.khid = tkd.khid
                                       and tkm.pzlx = ''1''
                                       and tkm.isuse = ''Y'' 
                                       and tkm.messageid ='''||vmessageid||''') t2
                             where t.deptid = '''||vdeptid||'''
                               AND T.messageid ='''||vmessageid||'''
                               AND T.TGFSTYPE = t2.dfcode';
                     V_SQL1 := V_SQL1 ||
                               ' and t.stattime >=to_date(''' ||
                               v_zq_stattime || ''', ''yyyy-mm-dd HH24:MI:SS'')';
                     V_SQL1 := V_SQL1 ||
                               ' and t.stattime <=to_date(''' ||
                               v_zq_endtime || ''', ''yyyy-mm-dd HH24:MI:SS'')';             
                    
                      v_mxid     := sys_guid();
                      execute immediate V_SQL1 into v_js_score;
                      insert into T_KH_JG_TGFSMX
                         (MXID,
                          TGFSID,
                          KHID,
                          TASKID,
                          DEPTID,
                          MESSAGEID,
                          ZBID,
                          PZ_SCORE,
                          ZBNAME,
                          TGFS_VERID,
                          JS_SCORE,
                          CREATETIME,
                          tjzq,
                          tj_begintime,
                          tj_endtime
                          )
                       values
                         (v_mxid,
                          v_tgfsid,
                          v_khid,
                          V_taskid,
                          vdeptid,
                          vmessageid,
                          null,
                          null,                         
                          null,
                          v_tgfs_verid,
                          v_js_score,
                          sysdate,
                          replace(v_statperiod,'-',''),
                          v_zq_stattime,
                          v_zq_endtime);                    
                 end if;
             end if;
           END LOOP;      
         select avg(t.js_score) into v_TZQ_SCORE from T_KH_JG_TGFSMX t where t.tgfsid=v_tgfsid;     
         update T_KH_JG_TGFS t
          set t.tzq_score   = v_TZQ_SCORE,
              t.tzh_score   = v_TZQ_SCORE,
              t.total_score =  v_TZQ_SCORE*t.weight
        where t.tgfsid = v_tgfsid;
       ---配置设置已经使用
       update t_ks_message tkm
          set tkm.isuseed = 'Y'
        where tkm.Messageid = vmessageid
          and tkm.pzlx = '1'
          and tkm.isuse = 'Y';
    end if;
   end loop;
   --计算部门完整性得分
   update T_KH_JG_KHZF t
      set t.tgfs_score =
          nvl((select avg(TOTAL_SCORE) from T_KH_JG_TGFS where khid = v_khid),0)
    where t.khid = v_khid;
   commit;
 EXCEPTION
   When others then
     RESULT := sqlerrm(SqlCode);
     INSERT INTO T_LOG_EXECUTEPROCEDURES
       (LOGID,
        PID,
        USERID,
        ERESULT,
        PARAM_IN,
        EDESC,
        EFDESC,
        STIME,
        ETIME,
        LOGTIME)
     VALUES
       (SYS_GUID(),
        'p_bmgjkh',
        'P_kh_xxtgfs',
        'E',
        'taskid:' || v_taskid || 'deptid:' || vdeptid || ' messageid:' ||
        vmessageid,
        RESULT,
        NULL,
        SYSDATE,
        SYSDATE,
        SYSDATE);
     commit;
 end P_kh_xxtgfs;

   --信息规范性
     PROCEDURE P_kh_xxgfx(v_deptid    varchar,
                           v_domainids  varchar,
                           v_messageids varchar,
                           V_STATTIME   varchar,
                           V_ENDTIME    varchar,
                           V_taskid     varchar,
                           v_pzid       varchar,
                           v_khid       varchar) is
       RESULT VARCHAR2(4000);
       V_SQL       VARCHAR2(4000);
       V_SQL1      VARCHAR2(4000);
       v_tgfstypes varchar2(50);
       type record_cur_type is ref cursor;
       record_cur     record_cur_type;
       record_cur_mes record_cur_type;
       vdeptid        t_meta_table.deptid%type;
       vmessageid     t_meta_table.messageid%type;
       v_gfxid        t_kh_jg_gfx.gfxid%type;
       v_gfxkhjg      t_kh_jg_gfx.gfxkhjg%type:='';
       v_RG_SCORE     t_kh_jg_gfx.rg_score%type:=0;
       v_filename_sffh      t_kh_jg_gfxmx.filename_sffh%type;
       v_record_sffh        t_kh_jg_gfxmx.record_sffh%type:='Y';
       v_data_sffh          t_kh_jg_gfxmx.data_sffh%type:='Y';
       v_gfx_verid         t_kh_jg_gfxmx.gfxid%type;
       v_count            integer:=0;
       v_exit         integer:=0;
     begin
       V_SQL := ' select  tt.deptid,tt.messageid from t_sys_department td, t_meta_table tt where td.deptabbr = tt.deptid and tt.deptid= '''||v_deptid||''''
                || v_domainids || v_messageids || ' order by td.orderid,tt.orderid ';
       OPEN record_cur FOR V_SQL;
       LOOP
         FETCH record_cur
           INTO vdeptid, vmessageid;
         EXIT WHEN record_cur%NOTFOUND;
         select COUNT(*) into v_exit from t_ks_message t where t.messageid=vmessageid and t.isuse='Y' AND T.PZLX='2';
         if(v_exit>0) then
           v_gfxid := sys_guid();
           V_SQL1 := 'select count(*)
                              from (select tsd.*,
                                           case
                                             when tf.statperiod is null then
                                              tsd.recordfilecreatetime
                                             else
                                              tf.statperiod
                                           end as stattime
                                      from t_sys_datafileinfo tsd, t_stat_filetimeconfig tf
                                     where tsd.fileid = tf.fileid(+)) tt where tt.messageid='''
                     ||vmessageid || '''';
           if v_stattime is not null or v_stattime <> ' ' then
             V_SQL1 := V_SQL1 ||
                       ' and to_date(to_char(tt.stattime, ''yyyy-mm-dd''),''yyyy-mm-dd'') >=to_date(''' ||
                       v_stattime || ''', ''yyyy-mm-dd'')';
           end if;
           if v_endtime is not null or v_endtime <> ' ' then
             V_SQL1 := V_SQL1 ||
                       ' and to_date(to_char(tt.stattime, ''yyyy-mm-dd''), ''yyyy-mm-dd'') <=to_date(''' ||
                       v_endtime || ''', ''yyyy-mm-dd'')';
           end if;
           EXECUTE IMMEDIATE V_SQL1 into v_count;
             if(v_count=0)then 
                 v_filename_sffh:='N';
             else
                 V_SQL1:=V_SQL1||' and tt.sfgf=''N'' ';   
                  EXECUTE IMMEDIATE V_SQL1 into v_count;
                  IF(v_count>0)THEN 
                     v_filename_sffh:='N';
                  ELSE
                     v_filename_sffh:='Y';
                  END IF;
              end if;
              IF(v_filename_sffh='Y')THEN
                   v_gfxkhjg:='1';
                  select tkm.khid,TKD.Dfvalue into v_gfx_verid, v_RG_SCORE from t_ks_message tkm,t_ks_message_dfpz tkd where tkm.khid=tkd.khid and tkm.isuse='Y' and tkm.pzlx='2'and tkd.dfcode = 'FHGFYQ' and tkm.messageid=vmessageid;
              ELSE
                   v_gfxkhjg:='2';
                  select tkm.khid,TKD.Dfvalue into v_gfx_verid, v_RG_SCORE from t_ks_message tkm,t_ks_message_dfpz tkd where tkm.khid=tkd.khid and tkm.isuse='Y' and tkm.pzlx='2'and tkd.dfcode = 'JBGFYQ' and tkm.messageid=vmessageid;
              END IF;
              insert into T_KH_JG_GFX
                         (gfxid,
                          KHID,
                          TASKID,
                          DEPTID,
                          MESSAGEID,
                          PZID,
                          GFX_VERID,
                          GFXKHJG,
                          RG_SCORE,                         
                          CREATETIME)
                       values
                         (v_gfxid,
                          v_khid,
                          V_taskid,
                          vdeptid,
                          vmessageid, 
                          v_pzid,            
                          v_gfx_verid,
                          v_gfxkhjg,
                          v_RG_SCORE,
                          sysdate);
             insert into T_KH_JG_GFXMX(mxid,GFXID,KHID,TASKID,DEPTID,MESSAGEID,TGFS_VERID,FILENAME_SFFH,RECORD_SFFH,DATA_SFFH,CREATETIME)
             values(SYS_GUID(),v_gfxid,v_khid,V_taskid,v_deptid,vmessageid,v_gfx_verid,v_filename_sffh,v_record_sffh,v_data_sffh,sysdate);
             commit;
           ---配置设置已经使用
           update t_ks_message tkm set tkm.isuseed='Y'
                  where tkm.Messageid=vmessageid
                    and tkm.pzlx = '2'
                    and tkm.isuse ='Y';
          END IF;
       end loop;
       --计算部门规范性得分
       update T_KH_JG_KHZF t set t.gfx_score=nvl((select avg(RG_SCORE) from T_KH_JG_GFX  where khid=v_khid),0) where t.khid=v_khid; 
       commit;
    EXCEPTION
    When others then
    RESULT := sqlerrm(SqlCode);
    INSERT INTO T_LOG_EXECUTEPROCEDURES(LOGID,
                 PID, USERID, ERESULT, PARAM_IN,EDESC,EFDESC,
                 STIME,ETIME, LOGTIME)
              VALUES(SYS_GUID(),'p_bmgjkh','P_kh_xxgfx','E','taskid:'||v_taskid||'deptid:'||vdeptid ||' messageid:'||vmessageid,RESULT,NULL,
                 SYSDATE,SYSDATE,SYSDATE);
    commit;
     end P_kh_xxgfx;
     
  
  --信息准确性
  PROCEDURE P_kh_zqx(v_deptid     varchar,
                     v_domainids  varchar,
                     v_messageids varchar,
                     V_STATTIME   varchar,
                     V_ENDTIME    varchar,
                     V_taskid     varchar,
                     v_pzid       varchar,
                     v_khid       varchar) is
    RESULT      VARCHAR2(4000);
    V_SQL       VARCHAR2(4000);
    V_SQL1      VARCHAR2(4000);
    v_tgfstypes varchar2(50);
    type record_cur_type is ref cursor;
    record_cur     record_cur_type;
    record_cur_mes record_cur_type;
    vdeptid        t_meta_table.deptid%type;
    vmessageid     t_meta_table.messageid%type;
    v_zqxid        t_kh_jg_zqx.zqxid%type;
    v_weight       t_kh_jg_zqx.weight%type;
    v_inccounts    t_kh_jg_zqx.inccounts%type;
    v_validcounts  t_kh_jg_zqx.validcounts%type;
    v_zqx_verid    t_kh_jg_zqx.zqx_verid%type;
    v_tzq_zql      t_kh_jg_zqx.tzq_zql%type;
    v_total_score  t_kh_jg_zqx.total_score%type;
    v_dfvalue      t_ks_message_dfpz.dfvalue%type;
    v_bmzqx_verid  T_KH_JG_KHZF.Zqx_Verid%type;
    v_count        integer := 0;
    v_exit         integer := 0;
  begin
    select COUNT(*)
      into v_exit
      from t_ks_message t, t_ks_message_dfpz tkmd
     where t.khid = tkmd.khid
       and t.messageid = v_deptid
       and t.isuse = 'Y'
       AND T.PZLX = '8';
    if (v_exit > 0) then
      select tkmd.dfvalue,t.khid
        into v_dfvalue,v_bmzqx_verid
        from t_ks_message t, t_ks_message_dfpz tkmd
       where t.khid = tkmd.khid
         and t.messageid = v_deptid
         and t.isuse = 'Y'
         AND T.PZLX = '8';
     update t_ks_message t set t.isuseed='Y'
      where t.isuse = 'Y'
        and t.pzlx = '7'
        and t.messageid=v_deptid;
      V_SQL := ' select  tt.deptid,tt.messageid from t_sys_department td, t_meta_table tt where td.deptabbr = tt.deptid and tt.deptid= ''' ||
               v_deptid || '''' || v_domainids || v_messageids ||
               ' order by td.orderid,tt.orderid ';
      OPEN record_cur FOR V_SQL;
      LOOP
        FETCH record_cur
          INTO vdeptid, vmessageid;
        EXIT WHEN record_cur%NOTFOUND;
        select COUNT(*)
          into v_exit
          from t_ks_message t
         where t.messageid = vmessageid
           and t.isuse = 'Y'
           AND T.PZLX = '3';
        if (v_exit > 0) then
          v_zqxid := sys_guid();
          V_SQL1  := 'select nvl(sum(tt.validcounts),0),nvl(sum(tt.inccounts_one),0) from v_rpt_filestatnew tt
                                        where tt.messageid=''' ||
                     vmessageid || '''';
          if v_stattime is not null or v_stattime <> ' ' then
            V_SQL1 := V_SQL1 ||
                      ' and to_date(to_char(tt.createtime, ''yyyy-mm-dd''),''yyyy-mm-dd'') >=to_date(''' ||
                      v_stattime || ''', ''yyyy-mm-dd'')';
          end if;
          if v_endtime is not null or v_endtime <> ' ' then
            V_SQL1 := V_SQL1 ||
                      ' and to_date(to_char(tt.createtime, ''yyyy-mm-dd''), ''yyyy-mm-dd'') <=to_date(''' ||
                      v_endtime || ''', ''yyyy-mm-dd'')';
          end if;
          EXECUTE IMMEDIATE V_SQL1
            into v_validcounts, v_inccounts;
          if (v_inccounts = 0) then
            v_tzq_zql := 0;
          else
            v_tzq_zql := v_validcounts / v_inccounts;
          end if;
          select tkm.mw, tkm.khid
            into v_weight, v_zqx_verid
            from t_ks_message tkm
           where tkm.isuse = 'Y'
             and tkm.pzlx = '3'
             and tkm.messageid = vmessageid;
          v_total_score := v_tzq_zql * v_weight;
          insert into T_KH_JG_ZQX
            (ZQXID,
             KHID,
             TASKID,
             DEPTID,
             MESSAGEID,
             WEIGHT,
             PZID,
             ZQX_VERID,
             INCCOUNTS,
             VALIDCOUNTS,
             TZQ_ZQL,
             TZH_ZQL,
             TOTAL_SCORE,
             CREATETIME)
          values
            (v_zqxid,
             v_khid,
             V_taskid,
             v_deptid,
             vmessageid,
             v_weight,
             v_pzid,
             v_zqx_verid,
             v_inccounts,
             v_validcounts,
             v_tzq_zql,
             v_tzq_zql,
             v_total_score,
             sysdate);
          commit;
           ---配置设置已经使用
          update t_ks_message tkm set tkm.isuseed='Y'
                  where tkm.Messageid=vmessageid
                    and tkm.pzlx = '3'
                    and tkm.isuse ='Y';
        END IF;
      end loop;
      update T_KH_JG_KHZF t
         set t.zqx_score = nvl(P_BMGJKH.zqxgss(v_dfvalue,
                                               (select sum(TOTAL_SCORE)
                                                  from T_KH_JG_ZQX
                                                 where khid = v_khid)),
                               0),
             t.zqx_verid = v_bmzqx_verid
       where t.khid = v_khid;
    end if;
  EXCEPTION
    When others then
      RESULT := sqlerrm(SqlCode);
      INSERT INTO T_LOG_EXECUTEPROCEDURES
        (LOGID,
         PID,
         USERID,
         ERESULT,
         PARAM_IN,
         EDESC,
         EFDESC,
         STIME,
         ETIME,
         LOGTIME)
      VALUES
        (SYS_GUID(),
         'p_bmgjkh',
         'P_kh_zqx',
         'E',                  
         'taskid:' || v_taskid || ';deptid:' || vdeptid || ' messageid:' ||
         vmessageid||';v_domainids:'||v_domainids||',V_STATTIME:'||V_STATTIME||',V_ENDTIME：'||V_ENDTIME||
         'v_pzid:'||v_pzid||',v_khid:'||v_khid,
         RESULT,
         NULL,
         SYSDATE,
         SYSDATE,
         SYSDATE);
      commit;
  end P_kh_zqx;
    
     function  zqxgss (dfbalue in varchar2, zql in number ) return number is   
            RESULT varchar2(4000);
            v_zql number;
            v_total_score  number;       
            v_jshsarray ty_str_split;
            v_jshscs1 ty_str_split;
            v_jshscs2 ty_str_split;
            v_jshscs3 ty_str_split;
            v_jshs varchar2(200);
            a number;
            b number;
            x1 number;
            x2 number;
            x3 number;
       begin
             v_zql:=zql;
             if v_zql>1 then v_zql:=1; end if;
             select replace(regexp_replace(dfbalue, '(\[|\]|\(|\))', ''),
                            '=',
                            ',')into v_jshs
               from dual;
               v_jshsarray := FN_SPLIT(v_jshs, '@');
               v_jshscs1:=FN_SPLIT(v_jshsarray(1), ',');
               v_jshscs2:=FN_SPLIT(v_jshsarray(2), ',');
               v_jshscs3:=FN_SPLIT(v_jshsarray(3), ',');
               if v_zql>=v_jshscs1(1) and v_zql<=v_jshscs1(2)
                 then
                   v_total_score:=v_jshscs1(3);
               elsif v_zql>=v_jshscs2(1) and v_zql<v_jshscs2(2)
                     then 
                       a:=v_jshscs2(1);
                       b:=v_jshscs2(2);
                       x1:=v_jshscs2(3);
                       x2:=v_jshscs2(4);
                       x3:=v_jshscs2(5);
                     v_total_score:=(zql-b)*100*((x1-x2)/((a-b)*100))+x2;
               elsif v_zql>=v_jshscs3(1) and v_zql<v_jshscs3(2)
                      then 
                       a:=v_jshscs3(1);
                       b:=v_jshscs3(2);
                       x1:=v_jshscs3(3);
                       x2:=v_jshscs3(4);
                       x3:=v_jshscs3(5);
                    v_total_score:=zql*100*(x3/(b*100));   
                else
                    v_total_score:= v_jshsarray(4);  
               end if;
       return  v_total_score;
       EXCEPTION
       When others then
         RESULT := sqlerrm(SqlCode);
          return -1;      
      end;

 
 --信息完整性
 PROCEDURE P_kh_wzx(v_deptid     varchar,
                    v_domainids  varchar,
                    v_messageids varchar,
                    V_STATTIME   varchar,
                    V_ENDTIME    varchar,
                    V_taskid     varchar,
                    v_pzid       varchar,
                    v_khid       varchar) is
   RESULT      VARCHAR2(4000);
   V_SQLSTR    VARCHAR2(4000);
   V_SQL       VARCHAR2(4000);
   V_SQL1      VARCHAR2(4000);
   v_tgfstypes varchar2(50);
   type record_cur_type is ref cursor;
   record_cur     record_cur_type;
   record_cur_mes record_cur_type;
   vdeptid        t_meta_table.deptid%type;
   vmessageid     t_meta_table.messageid%type;
   v_wzxid        t_kh_jg_wzx.wzxid%type;
   v_wzx_verid    t_kh_jg_wzx.wzx_verid%type;
   v_validcounts  t_kh_jg_wzx.validcounts%type;
   v_fh_hx_count  t_kh_jg_wzx.fh_hx_counts%type;
   v_fh_hx_counts t_kh_jg_wzx.fh_hx_counts%type := 0;
   v_hx_counts    t_kh_jg_wzx.hx_counts%type;
   v_hx_weight    t_kh_jg_wzx.hx_weight%type;
   v_fh_fz_count  t_kh_jg_wzx.fh_fz_counts%type;
   v_fh_fz_counts t_kh_jg_wzx.fh_fz_counts%type := 0;
   v_fz_counts    t_kh_jg_wzx.fz_counts%type;
   v_fz_weight    t_kh_jg_wzx.fz_weight%type;
   v_fh_pt_count  t_kh_jg_wzx.fh_pt_counts%type;
   v_fh_pt_counts t_kh_jg_wzx.fh_pt_counts%type := 0;
   v_pt_counts    t_kh_jg_wzx.pt_counts%type;
   v_pt_weight    t_kh_jg_wzx.pt_weight%type;
   v_tzq_wzl      t_kh_jg_wzx.tzq_wzl%type;
   v_bmwzx_verid  T_KH_JG_KHZF.WZX_VERID%type;
   v_hxcolumns    integer:=0;
   v_fzcolumns    integer:=0;
   v_ptcolumns    integer:=0;
   v_dfvalue      t_ks_message_dfpz.dfvalue%type;
   v_count        integer := 0;
   v_exit         integer := 0;
 
   --获取所有的归集字段
   cursor curmetacolumn(varmessageid varchar2, v_attribute varchar2) is
     select tm.deptid,
            tm.tablename,
            tc.*,
            count(tc.columnid) over(PARTITION by tm.messageid) cm
       from t_meta_column tc, t_meta_table tm
      where tc.messageid = tm.messageid
        and tm.messageid = varmessageid
        and tc.isuse = 'Y'
        and tc.attribute in
            (select value from t_sys_dict t where t.mark = v_attribute);
 begin
   select COUNT(*)
     into v_exit
     from t_ks_message t, t_ks_message_dfpz tkmd
    where t.khid = tkmd.khid
      and t.messageid = v_deptid
      and t.isuse = 'Y'
      AND T.PZLX = '7';
   ----判断部门的完整性得分配置
   if (v_exit > 0) then
     select tkmd.dfvalue,t.khid
       into v_dfvalue,v_bmwzx_verid
       from t_ks_message t, t_ks_message_dfpz tkmd
      where t.khid = tkmd.khid
        and t.messageid = v_deptid
        and t.isuse = 'Y'
        AND T.PZLX = '7';
     update t_ks_message t set t.isuseed='Y'
      where t.isuse = 'Y'
        and t.pzlx = '7'
        and t.messageid=v_deptid;
        
     V_SQL := ' select  tt.deptid,tt.messageid from t_sys_department td, t_meta_table tt where td.deptabbr = tt.deptid and tt.deptid= ''' ||
              v_deptid || '''' || v_domainids || v_messageids ||
              ' order by td.orderid,tt.orderid ';
     OPEN record_cur FOR V_SQL;
     LOOP
       FETCH record_cur
         INTO vdeptid, vmessageid;
       EXIT WHEN record_cur%NOTFOUND;
       select COUNT(*)
         into v_exit
         from t_ks_message t
        where t.messageid = vmessageid
          and t.isuse = 'Y'
          AND T.PZLX = '4';
       if (v_exit > 0) then
         v_wzxid := sys_guid();
         V_SQL1  := 'select nvl(sum(tt.validcounts),0)from v_rpt_filestatnew tt
                                    where tt.messageid=''' ||
                    vmessageid || '''';
         if v_stattime is not null or v_stattime <> ' ' then
           V_SQL1 := V_SQL1 ||
                     ' and to_date(to_char(tt.createtime, ''yyyy-mm-dd''),''yyyy-mm-dd'') >=to_date(''' ||
                     v_stattime || ''', ''yyyy-mm-dd'')';
         end if;
         if v_endtime is not null or v_endtime <> ' ' then
           V_SQL1 := V_SQL1 ||
                     ' and to_date(to_char(tt.createtime, ''yyyy-mm-dd''), ''yyyy-mm-dd'') <=to_date(''' ||
                     v_endtime || ''', ''yyyy-mm-dd'')';
         end if;
         EXECUTE IMMEDIATE V_SQL1
           into v_validcounts;
       
         select TKD.Dfvalue, tkm.khid
           into v_hx_weight, v_wzx_verid
           from t_ks_message tkm, t_ks_message_dfpz tkd
          where tkm.khid = tkd.khid
            and tkm.isuse = 'Y'
            and tkm.pzlx = '4'
            and tkm.messageid = vmessageid
            and tkd.dfcode = 'HXSJX';
       
         select TKD.Dfvalue
           into v_fz_weight
           from t_ks_message tkm, t_ks_message_dfpz tkd
          where tkm.khid = tkd.khid
            and tkm.isuse = 'Y'
            and tkm.pzlx = '4'
            and tkm.messageid = vmessageid
            and tkd.dfcode = 'FZSJX';
            
          select TKD.Dfvalue
           into v_pt_weight
           from t_ks_message tkm, t_ks_message_dfpz tkd
          where tkm.khid = tkd.khid
            and tkm.isuse = 'Y'
            and tkm.pzlx = '4'
            and tkm.messageid = vmessageid  
            and tkd.dfcode = 'PTSJX';
         ----非空核心数据项
         v_fh_hx_counts:=0;
         FOR RD IN CURMETACOLUMN(vmessageid, 'HXSJX') LOOP
           v_hxcolumns := RD.Cm;
           --规则有效记录中（所有记录中）为空统计
           V_SQLSTR := 'SELECT /*+ NO_CPU_COSTING */  COUNT(*) FROM T_DATAPROCESS TP, ' ||
                       RD.TABLENAME || '_FMT T' ||
                       ' WHERE  T.RECID = TP.RECID AND  T.' ||
                       RD.COLUMNNAME ||
                       ' IS NOT NULL AND TP.isvalid=''Y'' AND  TP.FILEID in' ||
                       ' (select FILEID from v_rpt_filestatnew tt
                                    where tt.messageid=''' ||
                       vmessageid || '''';
           if v_stattime is not null or v_stattime <> ' ' then
             V_SQLSTR := V_SQLSTR ||
                         ' and to_date(to_char(tt.createtime, ''yyyy-mm-dd''),''yyyy-mm-dd'') >=to_date(''' ||
                         v_stattime || ''', ''yyyy-mm-dd'')';
           end if;
           if v_endtime is not null or v_endtime <> ' ' then
             V_SQLSTR := V_SQLSTR ||
                         ' and to_date(to_char(tt.createtime, ''yyyy-mm-dd''), ''yyyy-mm-dd'') <=to_date(''' ||
                         v_endtime || ''', ''yyyy-mm-dd'')';
           end if;
           V_SQLSTR := V_SQLSTR || ')';
           EXECUTE IMMEDIATE V_SQLSTR
             INTO v_fh_fz_count;
           v_fh_hx_counts := v_fh_hx_counts + v_fh_fz_count;
         end LOOP;
         v_hx_counts := v_validcounts * v_hxcolumns;
       
         ----非空辅助数据项
         v_fh_fz_counts:=0;
         FOR RD IN CURMETACOLUMN(vmessageid, 'FZSJX') LOOP
           v_fzcolumns := nvl(RD.Cm,0);
           --规则有效记录中（所有记录中）为空统计
           V_SQLSTR := 'SELECT /*+ NO_CPU_COSTING */  COUNT(*) FROM T_DATAPROCESS TP, ' ||
                       RD.TABLENAME || '_FMT T' ||
                       ' WHERE  T.RECID = TP.RECID AND  T.' ||
                       RD.COLUMNNAME ||
                       ' IS NOT NULL AND TP.isvalid=''Y'' AND  TP.FILEID in' ||
                       ' (select FILEID from v_rpt_filestatnew tt
                                    where tt.messageid=''' ||
                       vmessageid || '''';
           if v_stattime is not null or v_stattime <> ' ' then
             V_SQLSTR := V_SQLSTR ||
                         ' and to_date(to_char(tt.createtime, ''yyyy-mm-dd''),''yyyy-mm-dd'') >=to_date(''' ||
                         v_stattime || ''', ''yyyy-mm-dd'')';
           end if;
           if v_endtime is not null or v_endtime <> ' ' then
             V_SQLSTR := V_SQLSTR ||
                         ' and to_date(to_char(tt.createtime, ''yyyy-mm-dd''), ''yyyy-mm-dd'') <=to_date(''' ||
                         v_endtime || ''', ''yyyy-mm-dd'')';
           end if;
           V_SQLSTR := V_SQLSTR || ')';
           EXECUTE IMMEDIATE V_SQLSTR
             INTO v_fh_fz_count;
           v_fh_fz_counts := v_fh_fz_counts + v_fh_fz_count;
         end LOOP;
         v_fz_counts := v_validcounts * v_fzcolumns;
         
          ----普通数据项
         v_fh_pt_counts:=0;
         FOR RD IN CURMETACOLUMN(vmessageid, 'PTSJX') LOOP
           v_ptcolumns := nvl(RD.Cm,0);
           --规则有效记录中（所有记录中）为空统计
           V_SQLSTR := 'SELECT /*+ NO_CPU_COSTING */  COUNT(*) FROM T_DATAPROCESS TP, ' ||
                       RD.TABLENAME || '_FMT T' ||
                       ' WHERE  T.RECID = TP.RECID AND  T.' ||
                       RD.COLUMNNAME ||
                       ' IS NOT NULL AND TP.isvalid=''Y'' AND  TP.FILEID in' ||
                       ' (select FILEID from v_rpt_filestatnew tt
                                    where tt.messageid=''' ||
                       vmessageid || '''';
           if v_stattime is not null or v_stattime <> ' ' then
             V_SQLSTR := V_SQLSTR ||
                         ' and to_date(to_char(tt.createtime, ''yyyy-mm-dd''),''yyyy-mm-dd'') >=to_date(''' ||
                         v_stattime || ''', ''yyyy-mm-dd'')';
           end if;
           if v_endtime is not null or v_endtime <> ' ' then
             V_SQLSTR := V_SQLSTR ||
                         ' and to_date(to_char(tt.createtime, ''yyyy-mm-dd''), ''yyyy-mm-dd'') <=to_date(''' ||
                         v_endtime || ''', ''yyyy-mm-dd'')';
           end if;
           V_SQLSTR := V_SQLSTR || ')';
           EXECUTE IMMEDIATE V_SQLSTR
             INTO v_fh_pt_count;
           v_fh_pt_counts := v_fh_pt_counts + v_fh_pt_count;
         end LOOP;
         v_pt_counts := v_validcounts * v_ptcolumns;
         
         if v_hx_counts != 0 then
           v_tzq_wzl := v_fh_hx_counts / v_hx_counts;
         else
           v_tzq_wzl := 0;
         end if;
         insert into T_KH_JG_WZX
           (wzxid,
            KHID,
            TASKID,
            DEPTID,
            MESSAGEID,
            PZID,
            WZX_VERID,
            VALIDCOUNTS,
            FH_HX_COUNTS,
            HX_COUNTS,
            HX_WEIGHT,
            FH_FZ_COUNTS,
            FZ_COUNTS,
            Fz_Weight,
            FH_PT_COUNTS,
            PT_COUNTS,
            PT_Weight,
            TZQ_WZL,
            TZH_WZL,
            CREATETIME,
            TOTAL_SCORE)
         values
           (v_wzxid,
            v_khid,
            V_taskid,
            v_deptid,
            vmessageid,
            v_pzid,
            v_wzx_verid,
            v_validcounts,
            v_fh_hx_counts,
            v_hx_counts,
            v_hx_weight,
            v_fh_fz_counts,
            v_fz_counts,
            v_fz_weight,
            v_fh_pt_counts,
            v_pt_counts,
            v_pt_weight,
            v_tzq_wzl,
            v_tzq_wzl,
            sysdate,
            v_tzq_wzl * v_hx_weight);
         ---配置设置已经使用
         update t_ks_message tkm
            set tkm.isuseed = 'Y'
          where tkm.Messageid = vmessageid
            and tkm.pzlx = '4'
            and tkm.isuse = 'Y';
         commit;
       END IF;
     end loop;
     --计算部门完整性得分
     update T_KH_JG_KHZF t
        set t.wzx_score = nvl(P_BMGJKH.zqxgss(v_dfvalue,
                                              (select avg(TOTAL_SCORE)
                                                 from T_KH_JG_WZX
                                                where khid = v_khid)),
                              0),
            t.wzx_verid = v_bmwzx_verid
      where t.khid = v_khid;
     commit;
   end if;
 EXCEPTION
   When others then
     RESULT := sqlerrm(SqlCode);
     INSERT INTO T_LOG_EXECUTEPROCEDURES
       (LOGID,
        PID,
        USERID,
        ERESULT,
        PARAM_IN,
        EDESC,
        EFDESC,
        STIME,
        ETIME,
        LOGTIME)
     VALUES
       (SYS_GUID(),
        'p_bmgjkh',
        'P_kh_wzx',
        'E',
        'taskid:' || v_taskid || 'deptid:' || vdeptid || ' messageid:' ||
        vmessageid,
        RESULT,
        NULL,
        SYSDATE,
        SYSDATE,
        SYSDATE);
     commit;
 end P_kh_wzx;





--信息时效性
PROCEDURE P_kh_sxx(v_deptid     varchar,
                   v_domainids  varchar,
                   v_messageids varchar,
                   V_STATTIME   varchar,
                   V_ENDTIME    varchar,
                   v_taskparams varchar,
                   V_taskid     varchar,
                   v_pzid       varchar,
                   v_khid       varchar) is
  RESULT                  VARCHAR2(4000);
  V_SQL                   VARCHAR2(4000);
  v_tzq_score             t_kh_jg_sxx.tzq_score%type;
  v_sxx_verid             t_kh_jg_sxx.sxx_verid%type;
  v_bsjl_zj               t_kh_jg_sxx.bsjl%type;
  vdeptid                 t_meta_table.deptid%type;
  vmessageid              t_meta_table.messageid%type;
  v_sxxid                 t_kh_jg_sxx.sxxid%type;
  v_weight                t_kh_jg_sxx.weight%type;
  v_sxxdf_fhsxyq          int; ---符合时效要求
  v_sxxdf_ycytkf          int; ---延迟1天扣分
  v_sxxdf_wbs             int; ---未报送
  v_yb_counts             t_kh_jg_sxxmx.yb_counts%type;
  v_sb_counts             t_kh_jg_sxxmx.sb_counts%type;
  v_bsjl                  t_kh_jg_sxxmx.bsjl%type;
  v_js_score             t_kh_jg_sxxmx.js_score%type;
  v_taskparamsarray       ty_str_split;
  endtiime                date;
  starttime               date;
  v_STATPERIOD            varchar2(10);
  v_zqs                   varchar2(50);
  v_month                 number; --归集周期查询的哪个月
  v_year                  number; --归集周期查询的哪年
  v_period                varchar2(10); ---当月归集周期类型
  v_period1               varchar2(10); ---当月归集周期类型 下一个月周期类型
  v_gatherperiod          varchar2(10); ---归集周期类型(对应t_sys_datafileinfo)
  v_staflag               t_meta_table.staflag%type; -----是否统计
  v_newstarttime          varchar2(20); ----归集周期查询开始时间
  v_newendtime            varchar2(20); ----归集周期查询结束时间、
  v_lasttime              varchar2(20); ----归集周期查询结束时间之后最新一次提交时间
  v_newstarttime_quarter  date; ----季度年归集周期查询开始时间-16
  v_newendtime_quarter    date; ----季度年归集周期查询结束时间-09
  v_newstarttime_quarter1 date; ----季度年归集周期4.7.10.1查询开始时间-10
  v_newendtime_quarter1   date; ----季度年归集周期4.7.10.1查询结束时间-15

  v_starttime_suffix  varchar2(20) := ' 00:00:00'; ---归集周期查询月的某天开始
  v_endtime_suffix    varchar2(20) := ' 23:59:59'; ---归集周期查询月的某天结束
  v_endtime_quarter   varchar2(20) := '09'; ----09
  v_starttime_quarter varchar2(20) := '10'; ----10
  starttime_new       date;
  endtime_new         date;

  starttime_new_quarter date; ---4.7.10.1
  endtime_new_quarter   date; ---4.7.10.1

  timeset varchar2(20);
  v_param ty_str_split;
  type record_cur_type is ref cursor;
  curTable     record_cur_type;
  v_count      int;
  v_count1     int; ---上个周期有没有提供文件
  v_ytgcs      int; ----归集信息类应提供次数
  v_datecounts int;
  v_exit       integer := 0;
  v_sfcz        integer := 0;
  ---获取时间段内的月份
  cursor cur_months(P_STATTIME varchar2, P_ENDTIME varchar2) is
    SELECT TO_CHAR(ADD_MONTHS(TO_DATE(substr(P_STATTIME, 0, 7), 'YYYY-MM'),
                              ROWNUM - 1),
                   'YYYY-MM') statperiod
      FROM DUAL
    CONNECT BY ROWNUM <=
               months_between(to_date(substr(P_ENDTIME, 0, 7), 'yyyy-mm'),
                              to_date(substr(P_STATTIME, 0, 7), 'yyyy-mm'));
begin

  V_SQL := ' select tt.deptid,tt.messageid,tt.gatherperiod,tt.staflag
      from t_sys_department td,t_meta_table tt
      where td.deptabbr = tt.deptid  and tt.deptid=''' ||
           v_deptid || '''' || v_domainids || v_messageids ||
           'and tt.isuse = ''Y''     
       and (tt.messagetype = ''D'' or tt.messagetype is null) order by td.orderid,tt.orderid ';
  OPEN curTable FOR V_SQL;
  LOOP
    FETCH curTable
      INTO vdeptid, vmessageid, v_gatherperiod, v_staflag;
    EXIT WHEN curTable%NOTFOUND;
    ----判断该信息类是否配置
    select COUNT(*)
      into v_exit
      from t_ks_message t
     where t.messageid = vmessageid
       and t.isuse = 'Y'
       AND T.PZLX = '5';
    if (v_exit > 0) then
        v_sxxid:=sys_guid();
       if (v_gatherperiod != '07') then
            select TKD.Dfvalue
              into v_weight
              from t_ks_message tkm, t_ks_message_dfpz tkd
             where tkm.khid = tkd.khid
               and tkm.isuse = 'Y'
               and tkm.pzlx = '5'
               and tkm.messageid = vmessageid
               and tkd.dfcode = 'ZQQZ_' || v_gatherperiod;
        else
          select TKD.Dfvalue
            into v_weight
            from t_ks_message tkm, t_ks_message_dfpz tkd
           where tkm.khid = tkd.khid
             and tkm.isuse = 'Y'
             and tkm.pzlx = '5'
             and tkm.messageid = vmessageid
             and tkd.dfcode = 'ZQQZ_06';
        end if;
        select tkm.khid
              into v_sxx_verid
              from t_ks_message tkm
             where tkm.isuse = 'Y'
               and tkm.pzlx = '5'
               and tkm.messageid = vmessageid;
        insert into t_kh_jg_sxx
              (sxxid,
               khid,
               taskid,
               deptid,
               messageid,
               weight,
               pzid,
               sxx_verid,
               yb_counts,
               sb_counts,
               bsjl,
               tzq_score,
               tzh_score,
               total_score,
               createtime,
               zj_counts)
            values
              (v_sxxid,
               v_khid,
               v_taskid,
               vdeptid,
               vmessageid,
               v_weight,
               v_pzid,
               v_sxx_verid,
               v_yb_counts,
               v_sb_counts,
               v_bsjl,
               0,
               0,
               0,
               sysdate,
               0);
      FOR rd in cur_months(V_STATTIME, V_ENDTIME) loop
        v_STATPERIOD := replace(rd.statperiod, '-', '');
        v_zqs        := f_shd(rd.statperiod);      
        v_taskparamsarray := FN_SPLIT(v_zqs, ',');
        starttime         := to_date(v_taskparamsarray(1), 'YYYY-MM-DD HH24:MI:SS');
        endtiime          := to_date(v_taskparamsarray(2), 'YYYY-MM-DD HH24:MI:SS');      
        if(starttime>=to_date(V_STATTIME,'YYYY-MM-DD') and endtiime<=to_date(V_ENDTIME,'YYYY-MM-DD')) THEN 
        ---判断周期是否在时间段
        ----月和周的年月获取
        v_month := extract(month from to_date(v_STATPERIOD, 'YYYYMM'));
        v_year  := extract(year from to_date(v_STATPERIOD, 'YYYYMM'));
        case v_month
          when 3 then
            v_period := '04';
          when 9 then
            v_period := '04';
          when 6 then
            v_period := '05';
          when 12 then
            v_period := '06';
          else
            v_period := '03';
        end case;
      
        if mod(v_year, 2) = 0 and v_month = 12 then
          v_period := '07';
        end if;
      
        case v_month - 1
          when 3 then
            v_period1 := '04';
          when 9 then
            v_period1 := '04';
          when 6 then
            v_period1 := '05';
          when 0 then
            v_period1 := '06';
          else
            v_period1 := '03';
        end case;
        if mod(v_year - 1, 2) = 0 and v_month = 1 then
          v_period1 := '07';
        end if;
      
        endtime_new := endtiime;
        if (v_gatherperiod > '03') THEN
          ---获取季度、半年、年、两年的日期后缀
          select t.value into timeset from t_sys_param t where t.id = '33';
          v_param := FN_SPLIT(timeset, ';');
          if v_gatherperiod <= v_period1 then
            ---类似2014-04-10~2014-04-15
            v_newstarttime_quarter := add_months(to_date(v_STATPERIOD ||
                                                         v_param(1),
                                                         'YYYY-MM-DD'),
                                                 -1);
            v_newendtime_quarter   := to_date(v_STATPERIOD ||
                                              v_endtime_quarter,
                                              'YYYY-MM-DD');
          
            starttime_new := to_date(v_STATPERIOD || v_starttime_quarter,
                                     'YYYY-MM-DD');
            endtime_new   := to_date(v_STATPERIOD || v_param(2),
                                     'YYYY-MM-DD');
          else
            ---类似2014-01-16~2014-04-09
            v_newstarttime_quarter := to_date(v_STATPERIOD || v_param(1),
                                              'YYYY-MM-DD');
            v_newendtime_quarter   := add_months(to_date(v_STATPERIOD ||
                                                         v_endtime_quarter,
                                                         'YYYY-MM-DD'),
                                                 1);
          end if;
        end if;
      
        case
          when v_gatherperiod = '04' ---按季度
           then
            if mod(v_month, 3) = 0 then
              starttime_new := add_months(v_newstarttime_quarter, -2);
              endtime_new   := v_newendtime_quarter;
            elsif mod(v_month - 1, 3) = 0 then
              v_newstarttime_quarter := add_months(v_newstarttime_quarter,
                                                   -2);
            else
              starttime_new := starttime;
            end if;
          when v_gatherperiod = '05' ----按半年
           then
            if mod(v_month, 6) = 0 then
              starttime_new := add_months(v_newstarttime_quarter, -5);
              endtime_new   := v_newendtime_quarter;
            elsif mod(v_month - 1, 6) = 0 then
              v_newstarttime_quarter := add_months(v_newstarttime_quarter,
                                                   -5);
            else
              starttime_new := starttime;
            end if;
          when v_gatherperiod = '06' ----按一年
           then
            if mod(v_month, 12) = 0 then
              starttime_new := add_months(v_newstarttime_quarter, -11);
              endtime_new   := v_newendtime_quarter;
            elsif mod(v_month - 1, 12) = 0 then
              v_newstarttime_quarter := add_months(v_newstarttime_quarter,
                                                   -11);
            else
              starttime_new := starttime;
            end if;
          when v_gatherperiod = '07' ------按两年
           then
            if mod(v_month, 12) = 0 and mod(v_year, 2) = 0 then
              starttime_new := add_months(v_newstarttime_quarter, -23);
              endtime_new   := v_newendtime_quarter;
            elsif mod(v_month - 1, 12) = 0 and mod(v_year - 1, 2) = 0 then
              v_newstarttime_quarter := add_months(v_newstarttime_quarter,
                                                   -11);
            else
              starttime_new := starttime;
            end if;
          else
            starttime_new := starttime;
        end case;
        v_newstarttime := to_char(starttime_new, 'yyyy-mm-dd') ||
                          v_starttime_suffix;
        v_newendtime   := to_char(endtime_new, 'yyyy-mm-dd') ||
                          v_endtime_suffix;
        if (v_gatherperiod > '03' and v_gatherperiod <= v_period1) then
          v_newstarttime_quarter := to_date(to_char(v_newstarttime_quarter,
                                                    'yyyy-mm-dd') ||
                                            v_starttime_suffix,
                                            'yyyy-mm-dd hh24:mi:ss');
          v_newendtime_quarter   := to_date(to_char(v_newendtime_quarter,
                                                    'yyyy-mm-dd') ||
                                            v_endtime_suffix,
                                            'yyyy-mm-dd hh24:mi:ss');
        end if;
        -----归集统计-提供信息类详细情况表
        -----归集信息类在时间段提供的次数
        select nvl(count(messageid), 0)
          into v_count
          from (select td.*,
                       tf.statperiod,
                       case
                         when tf.statperiod is null then
                          td.recordfilecreatetime
                         else
                          tf.statperiod
                       end as recordfilecreatetime1
                  from t_sys_datafileinfo td, T_STAT_FILETIMECONFIG tf
                 where tf.fileid(+) = td.fileid)
         where recordfilecreatetime1 >=
               to_date(v_newstarttime, 'yyyy-mm-dd hh24:mi:ss')
           and recordfilecreatetime1 <=
               to_date(v_newendtime, 'yyyy-mm-dd hh24:mi:ss')
           and messageid = vmessageid;
      
        -----计算本期应该提供的信息类个数
      
        if v_gatherperiod <= v_period or v_gatherperiod <= v_period1 then
          if (v_staflag = 'N' OR v_staflag IS NULL) then
            v_ytgcs := 0;
          else
            if v_gatherperiod = '01' then
              v_ytgcs := credit_center.getWeekPeriodCounts(v_STATPERIOD);
            else
              if (v_gatherperiod <= '03' and v_gatherperiod <= v_period) then
                v_ytgcs := 1; ---月度一下情况
              elsif (v_gatherperiod > '03' and v_gatherperiod <= v_period1) then
                -----4.7.10.1这种情况
                select nvl(count(messageid), 0)
                  into v_count1
                  from (select td.*,
                               tf.statperiod,
                               case
                                 when tf.statperiod is null then
                                  td.recordfilecreatetime
                                 else
                                  tf.statperiod
                               end as recordfilecreatetime1
                          from t_sys_datafileinfo    td,
                               T_STAT_FILETIMECONFIG tf
                         where tf.fileid(+) = td.fileid
                        ---and td.associated='Y'
                        )
                 where recordfilecreatetime1 >= v_newstarttime_quarter
                   and recordfilecreatetime1 <= v_newendtime_quarter
                   and messageid = vmessageid;
                if v_count1 = 0 then
                  v_ytgcs := 1;
                else
                  v_ytgcs := 0;
                end if;
              else
                ----3，6，9，12这种情况
                v_ytgcs := 0;
              end if;
            end if;
          
            if (v_count > 0 and v_gatherperiod > '03' and
               v_gatherperiod <= v_period) then
              -----3，6，9，12这种情况
              v_ytgcs := 1;
            end if;
          end if;
          if (v_ytgcs > 0) then           
            select TKD.Dfvalue
              into v_sxxdf_fhsxyq
              from t_ks_message tkm, t_ks_message_dfpz tkd
             where tkm.khid = tkd.khid
               and tkm.isuse = 'Y'
               and tkm.pzlx = '5'
               and tkm.messageid = vmessageid
               and tkd.dfcode = 'SXXDF_FHSXYQ';
            select TKD.Dfvalue
              into v_sxxdf_ycytkf
              from t_ks_message tkm, t_ks_message_dfpz tkd
             where tkm.khid = tkd.khid
               and tkm.isuse = 'Y'
               and tkm.pzlx = '5'
               and tkm.messageid = vmessageid
               and tkd.dfcode = 'SXXDF_YCYTKF';
            select TKD.Dfvalue
              into v_sxxdf_wbs
              from t_ks_message tkm, t_ks_message_dfpz tkd
             where tkm.khid = tkd.khid
               and tkm.isuse = 'Y'
               and tkm.pzlx = '5'
               and tkm.messageid = vmessageid
               and tkd.dfcode = 'SXXDF_WBS';
            /* if v_count=0 then 
            ---没有提供数据
            v_tzq_score:=v_sxxdf_wbs;*/
            if v_count < v_ytgcs then
              select to_char(min(recordfilecreatetime1), 'YYYY-MM-DD')
                into v_lasttime
                from (select td.*,
                             tf.statperiod,
                             case
                               when tf.statperiod is null then
                                td.recordfilecreatetime
                               else
                                tf.statperiod
                             end as recordfilecreatetime1
                        from t_sys_datafileinfo td, T_STAT_FILETIMECONFIG tf
                       where tf.fileid(+) = td.fileid)
               where recordfilecreatetime1 >
                     to_date(v_newendtime, 'yyyy-mm-dd hh24:mi:ss')
                 and messageid = vmessageid;
              if v_lasttime is null or v_lasttime = '' then
                v_lasttime := to_char(sysdate, 'YYYY-MM-DD');
              end if;
              if(to_date(v_lasttime,'YYYY-MM-DD')<to_date(v_newendtime,'YYYY-MM-DD hh24:mi:ss'))then 
                   ---截止日期之后没有提供数据   
                    v_js_score := 0;                                    
              else
                v_datecounts := P_BMGJKH.f_sjc(to_char(to_date(v_newendtime,
                                                               'YYYY-MM-DD hh24:mi:ss') + 1,
                                                       'YYYY-MM-DD'),
                                               v_lasttime);
                if v_sxxdf_ycytkf * v_datecounts > v_sxxdf_fhsxyq then
                  v_js_score := 0;
                else
                  v_js_score := v_sxxdf_fhsxyq -
                                 v_sxxdf_ycytkf * v_datecounts;
                end if;
              end if;
            
            else
              ---上报数据
              v_js_score := v_sxxdf_fhsxyq;
            end if;           
            v_yb_counts := v_ytgcs;
            v_sb_counts := v_count;
            select wm_concat(to_char(recordfilecreatetime1, 'YYYY-MM-DD'))
              INTO v_bsjl
              from (select * from(select td.*,
                           tf.statperiod,
                           case
                             when tf.statperiod is null then
                              td.recordfilecreatetime
                             else
                              tf.statperiod
                           end as recordfilecreatetime1
                      from t_sys_datafileinfo td, T_STAT_FILETIMECONFIG tf
                     where tf.fileid(+) = td.fileid)
             where recordfilecreatetime1 >=
                   to_date(v_newstarttime, 'yyyy-mm-dd hh24:mi:ss')
               and recordfilecreatetime1 <=
                   to_date(v_newendtime, 'yyyy-mm-dd hh24:mi:ss')
               and messageid = vmessageid
              order by recordfilecreatetime1 asc);
            insert into T_KH_JG_SXXMX
              (mxid,
               sxxid,
               khid,
               taskid,
               deptid,
               messageid,
               js_score,
               createtime,
               tjzq,
               tjbegintime,
               tjendtime,
               yb_counts,
               sb_counts,
               bsjl
               )
            values
              (sys_guid(),
               v_sxxid,
               v_khid,
               v_taskid,
               vdeptid,
               vmessageid,
               v_js_score,
               sysdate,
               v_STATPERIOD,
               v_newstarttime,
               v_newendtime,
               v_yb_counts,
               v_sb_counts,               
               v_bsjl
              );
          end if;
        end if;
       end if;
      end loop;
      ----
      select nvl(sum(t.js_score),0) into v_TZQ_SCORE from t_kh_jg_sxxmx t where t.sxxid=v_sxxid;
      select count(*) into v_sfcz from t_kh_jg_sxxmx t where t.sxxid=v_sxxid;
      if(v_sfcz>0) then 
         select wm_concat(t.bsjl) into v_bsjl_zj from t_kh_jg_sxxmx t where t.sxxid=v_sxxid order by tjzq asc;       
      end if;
      update t_kh_jg_sxx t
        set t.tzq_score   = v_TZQ_SCORE,
            t.tzh_score   = v_TZQ_SCORE,
            t.total_score =  v_TZQ_SCORE*t.weight,
            t.yb_counts= (select nvl(sum(tm.yb_counts),0) from t_kh_jg_sxxmx tm where tm.sxxid=t.sxxid),
            t.sb_counts= (select nvl(sum(tm.sb_counts),0) from t_kh_jg_sxxmx tm where tm.sxxid=t.sxxid),
            t.bsjl=v_bsjl_zj
      where t.sxxid = v_sxxid;
      ---配置设置已经使用
      update t_ks_message tkm
         set tkm.isuseed = 'Y'
       where tkm.Messageid = vmessageid
         and tkm.pzlx = '5'
         and tkm.isuse = 'Y';
      commit;
    end if;
  end loop;
  --计算部门时效性得分
  update T_KH_JG_KHZF t
     set t.sxx_score = nvl((select avg(total_score)
                             from T_KH_JG_SXX
                            where khid = v_khid),
                           0)
   where t.khid = v_khid;
  commit;
EXCEPTION
  When others then
    RESULT := sqlerrm(SqlCode);
    INSERT INTO T_LOG_EXECUTEPROCEDURES
      (LOGID,
       PID,
       USERID,
       ERESULT,
       PARAM_IN,
       EDESC,
       EFDESC,
       STIME,
       ETIME,
       LOGTIME)
    VALUES
      (SYS_GUID(),
       'p_bmgjkh',
       'P_kh_sxx',
       'E',
       'taskid:' || v_taskid || 'deptid:' || vdeptid || ' messageid:' ||
       vmessageid,
       RESULT,
       NULL,
       SYSDATE,
       SYSDATE,
       SYSDATE);
    commit;
end;


--异议考核
PROCEDURE P_kh_yy(v_deptid     varchar,
                  v_domainids  varchar,
                  v_messageids varchar,
                  V_STATTIME   varchar,
                  V_ENDTIME    varchar,
                  V_taskid     varchar,
                  v_pzid       varchar,
                  v_khid       varchar) is
  RESULT VARCHAR2(4000);
  V_SQL1 VARCHAR2(4000);
  V_SQL  VARCHAR2(4000);
  type record_cur_type is ref cursor;
  record_cur    record_cur_type;
  record_cerno  record_cur_type;
  vdeptid       t_meta_table.deptid%type;
  vmessageid    t_meta_table.messageid%type;
  v_yyid        T_KH_JG_YY.yyid%type;
  v_yy_verid    T_KH_JG_YY.yy_verid%type;
  v_recid       T_KH_JG_YY.recid%type;
  v_tcsj        DATE;
  v_clwcsj      DATE;
  v_cqts        T_KH_JG_YY.cqts%type;
  vtcsj         varchar(20);
  vclwcsj       varchar(20);
  v_tzq_score   T_KH_JG_YY.tzq_score%type;
  v_total_score T_KH_JG_YY.total_score%type;
  v_ycytkf      t_ks_message_dfpz.dfvalue%type;
  v_agdjscl     t_ks_message_dfpz.dfvalue%type;
  v_exit        integer;
  v_exisyy      integer := 0; ---部门是否有异议
begin
  select COUNT(*)
    into v_exit
    from t_ks_message t
   where t.messageid = v_deptid
     and t.isuse = 'Y'
     AND T.PZLX = '6';
  ---判断信息类是否有配置
  if (v_exit > 0) then
   ---配置设置已经使用
   update t_ks_message tkm
      set tkm.isuseed = 'Y'
    where tkm.Messageid = v_deptid
      and tkm.pzlx = '6'
      and tkm.isuse = 'Y';
    select TKD.Dfvalue
      into v_agdjscl
      from t_ks_message tkm, t_ks_message_dfpz tkd
     where tkm.khid = tkd.khid
       and tkm.isuse = 'Y'
       and tkm.pzlx = '6'
       and tkm.messageid = v_deptid
       and tkd.dfcode = 'AGDJSCL';
    select TKD.Dfvalue
      into v_ycytkf
      from t_ks_message tkm, t_ks_message_dfpz tkd
     where tkm.khid = tkd.khid
       and tkm.isuse = 'Y'
       and tkm.pzlx = '6'
       and tkm.messageid = v_deptid
       and tkd.dfcode = 'YCYTKF';
    V_SQL := '  select td.deptabbr,tcdi.messageid,tcdi.demurralrecid,tcdi.createtime,tcdf.deptdealtime, to_char(tcdi.createtime,''YYYY-MM-DD''), to_char(tcdf.deptdealtime,''YYYY-MM-DD'')
        from t_Cms_Demurral_Info  tcdi,
             t_Cms_Demurral_Bodys tcdb,
             t_Cms_Demurral_Flow  tcdf,
             t_sys_department td,
             t_meta_table tt
       where tcdi.cretno = tcdb.cretno
         and tcdi.cretno = tcdf.cretno
         and tcdi.providedeptid=td.deptid
         and tt.deptid=td.deptabbr
         and tcdi.messageid=tt.messageid
         and tcdb.body_acceptstate = ''1''
         and tcdf.dealmethod = ''1'' and tt.deptid= ''' ||
             v_deptid || '''' || v_domainids || v_messageids;
     if v_stattime is not null or v_stattime <> ' ' then
       V_SQL := V_SQL ||
                   ' and to_date(to_char(tcdi.createtime, ''yyyy-mm-dd''),''yyyy-mm-dd'') >=to_date(''' ||
                   v_stattime || ''', ''yyyy-mm-dd'')';
     end if;
     if v_endtime is not null or v_endtime <> ' ' then
       V_SQL := V_SQL ||
                   ' and to_date(to_char(tcdi.createtime, ''yyyy-mm-dd''), ''yyyy-mm-dd'') <=to_date(''' ||
                   v_endtime || ''', ''yyyy-mm-dd'')';
     end if;
    OPEN record_cerno FOR V_SQL;
    LOOP
      FETCH record_cerno
        INTO vdeptid, vmessageid, v_recid, v_tcsj, v_clwcsj, vtcsj, vclwcsj;
      EXIT WHEN record_cerno%NOTFOUND;
      v_exisyy := v_exisyy + 1;
      if vclwcsj is null and vclwcsj = '' then
        vclwcsj := to_char(sysdate, 'YYYY-MM-DD');
      end if;
      v_cqts := f_sjc(vtcsj, vclwcsj);
      if v_cqts <= 10 then
        v_tzq_score := v_agdjscl;
      else
        v_tzq_score := v_agdjscl - v_cqts * v_ycytkf;
        if v_tzq_score < 0 then
          v_tzq_score := 0;
        end if;
      end if;
      select tkm.khid
        into v_yy_verid
        from t_ks_message tkm
       where tkm.isuse = 'Y'
         and tkm.pzlx = '6'
         and tkm.messageid = v_deptid;
      insert into T_KH_JG_YY
        (yyid,
         KHID,
         TASKID,
         DEPTID,
         MESSAGEID,
         PZID,
         YY_VERID,
         RECID,
         TCSJ,
         CLWCSJ,
         CQTS,
         TZQ_SCORE,
         TZH_SCORE,
         TOTAL_SCORE,
         CREATETIME)
      values
        (sys_guid(),
         v_khid,
         V_taskid,
         vdeptid,
         vmessageid,
         v_pzid,
         v_yy_verid,
         v_recid,
         v_tcsj,
         v_clwcsj,
         v_cqts,
         v_tzq_score,
         v_tzq_score,
         v_tzq_score,
         sysdate);        
    end loop;
    if v_exisyy = 0 then
      update T_KH_JG_KHZF t
         set t.yy_score = v_agdjscl
       where t.khid = v_khid;
    else
      update T_KH_JG_KHZF t
         set t.yy_score =
             (select avg(total_score) from T_KH_JG_YY where khid = v_khid)
       where t.khid = v_khid;
    end if;
  end if;
  commit;
EXCEPTION
  When others then
    RESULT := sqlerrm(SqlCode);
    INSERT INTO T_LOG_EXECUTEPROCEDURES
      (LOGID,
       PID,
       USERID,
       ERESULT,
       PARAM_IN,
       EDESC,
       EFDESC,
       STIME,
       ETIME,
       LOGTIME)
    VALUES
      (SYS_GUID(),
       'p_bmgjkh',
       'P_kh_yy',
       'E',
       'taskid:' || v_taskid || 'deptid:' || vdeptid || ' messageid:' ||
       vmessageid,
       RESULT,
       NULL,
       SYSDATE,
       SYSDATE,
       SYSDATE);
    commit;
end;

--判断时间差                        
function f_sjc(V_STATTIME in varchar2, V_ENDTIME in varchar2) return number is
  RESULT       varchar2(4000);
  v_sql        VARCHAR2(4000); 
  v_stime      date;
  v_etime      date;
  v_sbyear     int; ---开始年
  v_eyear      int; ---结束年
  v_xtjjr      t_sys_dict.value%type;
  v_xtjjrs     ty_str_split;
  v_datecounts number;
  v_gzr        int;
  v_jjr        int;
  i            int;
  j            int := 1;
  k            int := 1;
begin
  v_stime  := to_date(V_STATTIME, 'YYYY-MM-DD');
  v_etime  := to_date(V_ENDTIME, 'YYYY-MM-DD');
  v_sbyear := extract(year from v_stime);
  v_eyear  := extract(year from v_etime);
  select t.value into v_xtjjr from t_sys_dict t where t.key = 'JJR';
  v_xtjjrs := FN_SPLIT(v_xtjjr, ',');
  v_sql    := ' select count(*)from (select to_date('''|| V_STATTIME ||''',''YYYY-MM-DD'') + rownum  as tdate '||
              ' from all_objects '|| 
              ' where rownum < to_date(''' || V_ENDTIME ||''', ''YYYY-mm-dd'') - to_date(''' || V_STATTIME ||''', ''YYYY-MM-DD'')'|| 
              ')  t where (to_char(tdate,''day'') != ''saturday ''   and to_char(tdate,''day'') != ''sunday   '') ';
  if v_xtjjrs.count > 0 then
    v_sql := v_sql || ' and tdate not in (';
    while j <= v_xtjjrs.count loop
      i := v_sbyear;
      while i <= v_eyear loop
        if (k != 1) then
          v_sql := v_sql || ',';
        end if;
        v_sql := v_sql || ' to_date(''' || i || '.' || v_xtjjrs(j) ||''',''YYYY-mm-dd'')';
        i     := i + 1;
        k     :=k+1;
      end loop;
      i := v_sbyear;
      j := j + 1;
    end loop;
    v_sql := v_sql || ' )';
  end if;
  execute immediate v_sql into v_datecounts;
  
  ---工作日
   select count(*) into v_gzr
     from T_KS_JJRPZ t
    where t.hdate > v_stime
      and t.hdate < v_etime
      and t.pztype='W';
                 
    ---节假日日
   select count(*) into v_jjr
     from T_KS_JJRPZ t
    where t.hdate >  v_stime
      and t.hdate <  v_etime
      and t.pztype='H';
  v_datecounts:=v_datecounts+v_gzr-v_jjr;  
  return v_datecounts;
EXCEPTION
   When others then
     RESULT := sqlerrm(SqlCode);
      return -1;
end;

---获取时间段 提供方式
function f_shd(v_statperiod in varchar2) return varchar2 is
  RESULT             varchar2(4000);
  timeset            varchar2(20);
  v_param            ty_str_split;
  v_starttime        varchar2(20);
  v_endtime          varchar2(20);
  v_starttime_suffix varchar2(20) := ' 00:00:00'; ---归集周期查询月的某天开始
  v_endtime_suffix   varchar2(20) := ' 23:59:59'; ---归集周期查询月的某天结束
begin
  ---获取季度、半年、年、两年的日期后缀
  select t.value into timeset from t_sys_param t where t.id = '33';
  v_param     := FN_SPLIT(timeset, ';');
  v_starttime := v_STATPERIOD || '-'||v_param(1) || v_starttime_suffix;
  v_endtime   := to_char(add_months(to_date(v_STATPERIOD ||'-'||v_param(2),'YYYY-MM-DD'), 1),'YYYY-MM-DD') || v_endtime_suffix;
  return v_starttime || ',' ||v_endtime;
EXCEPTION
  When others then
    RESULT := sqlerrm(SqlCode);
    return - 1;
end;


end P_BMGJKH;
/
