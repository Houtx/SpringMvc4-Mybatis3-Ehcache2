CREATE package body PKG_ADMIN_REMOVE is

  --记录日志任务
  procedure log_remove_table_begin(LogID     in varchar2,
                                   messageid in varchar2,
                                   tablename in varchar2,
                                   content   in varchar2) is
  begin
    insert into T_SYS_REMOVELOG
      (LOG_ID,
       REMOVE_TYPE,
       OBJECT_NAME,
       OBJECT_ID,
       OBJECT_CONTENT,
       REMOVE_TIME)
    values
      (LogID, '采集表', tablename, messageid, content, Sysdate);
    commit;
  end;

  --更新记录日志任务结果
  procedure log_remove_table_end(LogID in varchar2, errNum in Number) is
  begin
    update T_SYS_REMOVELOG set OPERATE_ERR = errnum where LOG_ID = logID;
    commit;
  end;

  --记录详细日志
  procedure log_detail(LogID  in varchar2,
                       sqlstr in varchar2,
                       err    in varchar2) is
  begin
    insert into T_SYS_REMOVELOG_DETAIL
      (LOG_ID, LOG_SQL, LOG_ERR)
    values
      (LogID, sqlstr, err);
    commit;
  end;

  --执行SQL语句
  function exec_sql(LogID in varchar2, sqlstr in varchar2) return Number is
    v_error VARCHAR2(4000);
  begin
    execute immediate sqlstr;
    commit;
    log_detail(LogID, sqlstr, '');
    return 0;
  exception
    when others then
      v_error := 'SQLCODE: ' || SQLCODE || ', SQLERRM: ' || SQLERRM;
      log_detail(LogID, sqlstr, v_error);
      return 1;
  end;

  function remove_table_record(LogID in varchar2, messageid in varchar2)
    return number is
    v_errNum    Number;
    v_sql       varchar2(4000);
    v_LogID     varchar2(32);
    v_messageid varchar2(50);
  begin
    v_errNum    := 0;
    v_LogID     := LogID;
    v_messageid := messageid;
    v_sql       := 'delete from CREDIT_ADMIN.T_CMS_BASEDATADEPLOY_PURVIEW where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_CMS_DEMURRAL where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_CMS_DEMURRALUPDATESAVELOG where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_CMS_DEMURRAL_CORRELATION where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_CMS_DEMURRAL_INFO where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_CMS_DEMURRAL_UPDATELOG where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_CMS_DEPTBASEDATADEPLOY where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_CMS_MESSAGESUBSCIBE where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_CMS_SERVICEPLATFORM_CONFIG where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_CREDITINFO_TEMPLATE_CLM where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_CREDITINFO_TEMPLATE_TLB where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_DATAEXPORT_CTR where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_DATA_TFXFSJHZ where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_DICT_MESSAGECOMPARE where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_LOG_SYNRECORD where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_LOG_SYSAUTH where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_LOG_SYSAUTH_DEPT where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_APP_COLUMN where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_APP_TABLE where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_ASSOPARA where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_COLUMN where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_COLUMNRULE where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_CREDITMESSAGECONFIG where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_CREDITMESSAGECONFIGLOGS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_DOCCOLUMNRULEHIS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_MESSAGERCONFIG where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_MESSAGERCONFIGHIS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_RULEDOCUMENTHIS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_RULEVERSION where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_TABLE where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_TABLERCONFIG where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_TABLERCONFIGLOGS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_TABLE_FLOWCONFIG where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_RPT_EXPORTRPTFILETASK where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_RPT_TFXFSJHZ where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_STAT_FILETIMECONFIG where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_STAT_FILETIMECONFIGHIS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_STAT_XDWWCQQKTJ where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_DATAPROCESS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_DATA_MANUALCANCELCONNECTS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_DATA_MANUALCONNECTS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_DATA_MANUALCREDITS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_DATA_MANUALREPEAT where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_DATA_RGXG where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_DATA_UPDATES where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_LOGS_AUDITLOGS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_LOGS_MANUALCANCELCONNECTLOGS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_LOGS_MANUALCONNECTLOGS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_LOGS_MANUALCREDITS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_LOGS_MANUALREPEATLOGS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_LOGS_RGXGLOGS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_LOGS_UPDATELOGS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_LOG_CREDITVALIDDATEPROCESSES where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_ASSOCIATEQRECORD where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_ASSOCIATESTATISTICS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_ASSOCIATESTATISTICSHIS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_CDATACHECK where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_CDATACHECKHIS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_CDATACHECKQRECORD where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_CINCREMENTDATACHECK where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_CINCREMENTDATACHECKQ where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_FILEPROCESSTIMESTAT where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_FRONTDISSENT where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_FRONTOTHERTYPE where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_FRONTPROCESS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_MANUALCACNCELCONNECT where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_MANUALCONNECT where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_MANUALCREDIT where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_MANUALREPEAT where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_MESSAGEDUPLICATE where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_MESSAGEDUPLICATEHIS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_MODIFYRECORDS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_REDOCDATACHECK where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_REDOCDATACHECKHIS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_RULEDATACHECKSTATICS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_STATICSQFILESENDRECORDS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_RPT_SYNCHRON where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STAT_FILEDATAITEMS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STAT_FILEDATAITEMSHIS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STAT_GJZQTJ where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STAT_GJZQTJHIS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STAT_GLQKTJ where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STAT_GLQKTJHIS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STAT_RGCLXXLTJ where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STAT_RGCLXXLTJHIS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STAT_XXLDYGJQKTJB where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STAT_XXLDYGJQKTJBHIS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STAT_XXXFQKTJB where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STAT_XXXFQKTJBHIS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STAT_YYXXCLQKTJB where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STAT_YYXXCLQKTJBHIS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STAT_ZTQKTJ where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STAT_ZTQKTJHIS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STA_TGXXLXXQK where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_STA_TGXXLXXQKHIS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_SYS_DATAFILEGROUPS where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_CENTER.T_SYS_DATAFILEINFO where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_PRODUCT.T_DATAPAUSE where MESSAGEID=''' ||
                   v_messageid || '''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    return v_errNum;
  end;

  --删除采集表
  procedure remove_table(messageid in varchar2) is
    v_errNum    Number;
    v_messageid varchar2(32);
    v_LogID     varchar2(32);
    v_rec       t_meta_table%rowtype;
    v_sql       varchar2(4000);
  begin
    v_errNum    := 0;
    v_messageid := messageid;
  
    select *
      into v_rec
      from t_meta_table t
     where t.messageid = v_messageid;
  
    select SYS_GUID() into v_LogID from dual;
  
    --开始记录日志
    log_remove_table_begin(v_LogID,
                           v_messageid,
                           v_rec.tablename,
                           v_rec.deptid || v_rec.messagename);
  
    --1.删除表       
    v_sql    := 'drop table CREDIT_GATHER.' || v_rec.tablename;
    v_errNum := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql    := 'drop table CREDIT_CENTER.' || v_rec.tablename || '_FMT';
    v_errNum := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql    := 'drop table CREDIT_PRODUCT.' || v_rec.tablename;
    v_errNum := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql    := 'drop table CREDIT_PRODUCT.' || v_rec.tablename || '_HIS';
    v_errNum := v_errNum + exec_sql(v_LogID, v_sql);
    
    
    delmessages_gather('table '||v_rec.tablename);
    delmessages_center('table '||v_rec.tablename || '_FMT');
    delmessages_product('table '||v_rec.tablename);
    delmessages_product('table '||v_rec.tablename || '_HIS');
    --2.删除同义词
    v_sql    := 'drop synonym CREDIT_ADMIN.' || v_rec.tablename;
    v_errNum := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql    := 'drop synonym CREDIT_ADMIN.' || v_rec.tablename || '_RAW';
    v_errNum := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql    := 'drop synonym CREDIT_ADMIN.' || v_rec.tablename || '_FMT';
    v_errNum := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql    := 'drop synonym CREDIT_ADMIN.' || v_rec.tablename || '_HIS';
    v_errNum := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql    := 'drop synonym CREDIT_CENTER.' || v_rec.tablename;
    v_errNum := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql    := 'drop synonym CREDIT_CENTER.' || v_rec.tablename || '_RAW';
    v_errNum := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql    := 'drop synonym CREDIT_CENTER.' || v_rec.tablename || '_HIS';
    v_errNum := v_errNum + exec_sql(v_LogID, v_sql);
  
    delmessages_center('synonym '||v_rec.tablename );
    delmessages_center('synonym '||v_rec.tablename || '_RAW');
    delmessages_center('synonym '||v_rec.tablename || '_HIS');

    --3.删除带有MESSAGEID的表的记录
    v_errNum := v_errNum + remove_table_record(v_LogID, v_messageid);
  
    --更新日志结果
    log_remove_table_end(v_LogID, v_errNum);
  
  end remove_table;
  
  procedure remove_table_column(messageid in varchar2,columnid in varchar2) is
   v_errNum    Number;
    v_messageid varchar2(100);
    v_columnid  varchar2(100);
    v_LogID     varchar2(32);
    v_rec_table       t_meta_table%rowtype;
    v_rec_column       t_meta_column%rowtype;
    v_sql       varchar2(4000);
  begin
    v_errNum    := 0;
    v_messageid := messageid;
    v_columnid := columnid;
    select *
      into v_rec_table
      from t_meta_table t
     where t.messageid = v_messageid;
    select *
      into v_rec_column
      from t_meta_column t
     where t.messageid = v_messageid and t.columnid=v_columnid;
    select SYS_GUID() into v_LogID from dual;
     --开始记录日志
    log_remove_table_begin(v_LogID,
                           v_messageid,
                           v_rec_table.tablename,
                           v_rec_table.deptid || v_rec_table.messagename||v_rec_column.columnname);
    
     --1.删除表相关字段 CREDIT_GATHER ,CREDIT_CENTER,CREDIT_PRODUCT
    v_sql    := 'alter table CREDIT_GATHER.' || v_rec_table.tablename||' drop column '||v_rec_column.columnname;
    v_errNum := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql    := 'alter table CREDIT_CENTER.' || v_rec_table.tablename||'_FMT drop column '||v_rec_column.columnname;
    v_errNum := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql    := 'alter table CREDIT_PRODUCT.' || v_rec_table.tablename||' drop column '||v_rec_column.columnname;
    v_errNum := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql    := 'alter table CREDIT_PRODUCT.' || v_rec_table.tablename||'_HIS drop column '||v_rec_column.columnname;
    v_errNum := v_errNum + exec_sql(v_LogID, v_sql);
     v_sql       := 'delete from CREDIT_ADMIN.T_META_COLUMN where MESSAGEID=''' ||
                   v_messageid || ''' AND COLUMNID='''||v_columnid||'''';
                   
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_COLUMNRULE where MESSAGEID=''' ||
                   v_messageid || ''' AND (COLUMNID='''||v_columnid||''') OR (COLUMNIDS like ''%'||v_columnid||'%'')';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    v_sql       := 'delete from CREDIT_ADMIN.T_META_CREDITMESSAGECONFIG where MESSAGEID=''' ||
                   v_messageid || ''' AND COLUMNID='''||v_columnid||'''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
   
     v_sql       := 'delete from CREDIT_ADMIN.T_META_MESSAGERCONFIG where MESSAGEID=''' ||
                   v_messageid || ''' AND COLUMNID='''||v_columnid||'''';
    v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    
     v_sql       := 'delete from CREDIT_ADMIN.T_META_MESSAGERCONFIGHIS where MESSAGEID=''' ||
                   v_messageid || ''' AND COLUMNID='''||v_columnid||'''';
     v_errNum    := v_errNum + exec_sql(v_LogID, v_sql);
    
  --更新日志结果
    log_remove_table_end(v_LogID, v_errNum);
    
  end remove_table_column;
  
  
  

end PKG_ADMIN_REMOVE;
/
